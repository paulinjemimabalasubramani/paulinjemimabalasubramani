USE ROLE PROD_CLIENTACCOUNT_DBO;
USE WAREHOUSE PROD_CLIENTACCOUNT_RAW_WH;
USE DATABASE PROD_CLIENTACCOUNT;
USE SCHEMA RPAG_RAW;

CREATE OR REPLACE TRANSIENT TABLE RPAG_RAW.CRM_CLIENT_PLAN_VARIANT
(
  SRC VARIANT
);

CREATE OR REPLACE STREAM RPAG_RAW.CRM_CLIENT_PLAN_VARIANT_STREAM
ON TABLE RPAG_RAW.CRM_CLIENT_PLAN_VARIANT APPEND_ONLY = TRUE;

CREATE OR REPLACE VIEW RPAG_RAW.VW_CRM_CLIENT_PLAN_VARIANT_STREAM
AS
SELECT
   SRC:"client_id"::string AS client_id
  ,SRC:"client_plan"::string AS client_plan
  ,SRC:"elt_primary_key"::string AS elt_primary_key
  ,SRC:"firm_name"::string AS firm_name
  ,SRC:"run_date"::string AS run_date
  ,SRC:"elt_execution_date"::string AS elt_execution_date
  ,SRC:"elt_source"::string AS elt_source
  ,SRC:"elt_load_type"::string AS elt_load_type
  ,SRC:"elt_delete_ind"::string AS elt_delete_ind
  ,SRC:"elt_dml_type"::string AS elt_dml_type
  ,SRC:"elt_reception_date"::string AS elt_reception_date
  ,SRC:"elt_process_id"::string AS elt_process_id
  ,SRC:"elt_firm"::string AS elt_firm
  ,SRC:"elt_pipelinekey"::string AS elt_pipelinekey
  ,METADATA$ACTION AS elt_stream_action
FROM RPAG_RAW.CRM_CLIENT_PLAN_VARIANT_STREAM;

CREATE OR REPLACE VIEW RPAG_RAW.VW_CRM_CLIENT_PLAN
AS
SELECT
   elt_integration_id
  ,client_id
  ,client_plan
  ,elt_primary_key
  ,firm_name
  ,run_date
  ,elt_execution_date
  ,elt_source
  ,elt_load_type
  ,elt_delete_ind
  ,elt_dml_type
  ,elt_reception_date
  ,elt_process_id
  ,elt_firm
  ,elt_pipelinekey
  ,elt_columns_hash
  ,elt_stream_action
FROM
(
SELECT
   TRIM(CONCAT(COALESCE(src.elt_primary_key,'N/A'))) as elt_integration_id
  ,src.client_id
  ,src.client_plan
  ,src.elt_primary_key
  ,src.firm_name
  ,src.run_date
  ,src.elt_execution_date
  ,src.elt_source
  ,src.elt_load_type
  ,src.elt_delete_ind
  ,src.elt_dml_type
  ,src.elt_reception_date
  ,src.elt_process_id
  ,src.elt_firm
  ,src.elt_pipelinekey
  ,SHA2(CONCAT(
       COALESCE(src.client_id,'N/A')
      ,COALESCE(src.client_plan,'N/A')
      ,COALESCE(src.firm_name,'N/A')
      ,COALESCE(src.run_date,'N/A')
      )) AS elt_columns_hash
  ,src.elt_stream_action
  ,ROW_NUMBER() OVER (PARTITION BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action ORDER BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action, src.elt_execution_date DESC) AS top_slice
FROM RPAG_RAW.VW_CRM_CLIENT_PLAN_VARIANT_STREAM src
)
WHERE top_slice = 1;


USE SCHEMA RPAG;


CREATE OR REPLACE TABLE RPAG.CRM_CLIENT_PLAN
(
   elt_integration_id VARCHAR NOT NULL
  ,client_id VARCHAR
  ,client_plan VARCHAR
  ,elt_primary_key VARCHAR
  ,firm_name VARCHAR
  ,run_date VARCHAR
  ,elt_execution_date VARCHAR
  ,elt_source VARCHAR
  ,elt_load_type VARCHAR
  ,elt_delete_ind VARCHAR
  ,elt_dml_type VARCHAR
  ,elt_reception_date VARCHAR
  ,elt_process_id VARCHAR
  ,elt_firm VARCHAR
  ,elt_pipelinekey VARCHAR
  ,elt_columns_hash VARCHAR
  ,CONSTRAINT PK_RPAG_CRM_CLIENT_PLAN PRIMARY KEY (elt_integration_id) NOT ENFORCED
);

CREATE OR REPLACE PROCEDURE RPAG.USP_CRM_CLIENT_PLAN_MERGE()
RETURNS STRING
LANGUAGE JAVASCRIPT
EXECUTE AS CALLER
AS 
$$

function fixQuote(sql) { return sql.replace(/'/g, "''") }
//'


var sql_command = 
`
MERGE INTO RPAG.CRM_CLIENT_PLAN tgt
USING (
    SELECT * 
    FROM RPAG_RAW.VW_CRM_CLIENT_PLAN
) src
ON (
TRIM(COALESCE(src.elt_integration_id,'N/A')) = TRIM(COALESCE(tgt.elt_integration_id,'N/A'))
)
WHEN MATCHED
AND (TRIM(COALESCE(src.elt_columns_hash,'N/A')) != TRIM(COALESCE(tgt.elt_columns_hash,'N/A')) OR tgt.elt_delete_ind=1)
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  UPDATE
  SET
     tgt.client_id = COALESCE(src.client_id, '')
    ,tgt.client_plan = COALESCE(src.client_plan, '')
    ,tgt.elt_primary_key = COALESCE(src.elt_primary_key, '')
    ,tgt.firm_name = COALESCE(src.firm_name, '')
    ,tgt.run_date = COALESCE(src.run_date, '')
    ,tgt.elt_execution_date = src.elt_execution_date
    ,tgt.elt_source = src.elt_source
    ,tgt.elt_load_type = src.elt_load_type
    ,tgt.elt_delete_ind = src.elt_delete_ind
    ,tgt.elt_dml_type = src.elt_dml_type
    ,tgt.elt_reception_date = src.elt_reception_date
    ,tgt.elt_process_id = src.elt_process_id
    ,tgt.elt_firm = src.elt_firm
    ,tgt.elt_pipelinekey = src.elt_pipelinekey
    ,tgt.elt_columns_hash = src.elt_columns_hash

WHEN NOT MATCHED
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  INSERT
  (
     elt_integration_id
    ,client_id
    ,client_plan
    ,elt_primary_key
    ,firm_name
    ,run_date
    ,elt_execution_date
    ,elt_source
    ,elt_load_type
    ,elt_delete_ind
    ,elt_dml_type
    ,elt_reception_date
    ,elt_process_id
    ,elt_firm
    ,elt_pipelinekey
    ,elt_columns_hash
  )
  VALUES
  (
     src.elt_integration_id
    ,COALESCE(src.client_id, '')
    ,COALESCE(src.client_plan, '')
    ,COALESCE(src.elt_primary_key, '')
    ,COALESCE(src.firm_name, '')
    ,COALESCE(src.run_date, '')
    ,src.elt_execution_date
    ,src.elt_source
    ,src.elt_load_type
    ,src.elt_delete_ind
    ,src.elt_dml_type
    ,src.elt_reception_date
    ,src.elt_process_id
    ,src.elt_firm
    ,src.elt_pipelinekey
    ,src.elt_columns_hash
  );
`;

var soft_delete_command = "CALL ELT_STAGE.USP_SOFT_DELETE_RAW('RPAG_RAW.CRM_CLIENT_PLAN_VARIANT', 'RPAG.CRM_CLIENT_PLAN');";

var usp_ingestion_command = "CALL ELT_STAGE.USP_INGESTION_RESULT('RPAG.USP_CRM_CLIENT_PLAN_MERGE', ARRAY_CONSTRUCT('"+fixQuote(sql_command)+"', '"+fixQuote(soft_delete_command)+"'));";


try {
    execObj = snowflake.execute({sqlText: usp_ingestion_command});
    if (execObj.getRowCount()>0) {
        execObj.next();
        return execObj.getColumnValueAsString(1);
        }
    return "Succeeded.";
    }
catch (err)  {
    return "Failed: " + err;
    }
$$;

CREATE OR REPLACE TASK RPAG.CRM_CLIENT_PLAN_MERGE_TASK
WAREHOUSE = PROD_CLIENTACCOUNT_RAW_WH
SCHEDULE = '1 minute'
WHEN
SYSTEM$STREAM_HAS_DATA('RPAG_RAW.CRM_CLIENT_PLAN_VARIANT_STREAM')
AS
    CALL RPAG.USP_CRM_CLIENT_PLAN_MERGE();

ALTER TASK CRM_CLIENT_PLAN_MERGE_TASK RESUME;
