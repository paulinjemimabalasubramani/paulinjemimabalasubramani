USE ROLE DBA_DATA_LOAD;
USE WAREHOUSE DATA_LOAD_WH;
USE DATABASE QA_COMM;
USE SCHEMA CLIENT_REVENUE_RAW;

CREATE OR REPLACE TRANSIENT TABLE CLIENT_REVENUE_RAW.SABOS_12B1REBATE_VARIANT
(
  SRC VARIANT
);

CREATE OR REPLACE STREAM CLIENT_REVENUE_RAW.SABOS_12B1REBATE_VARIANT_STREAM
ON TABLE CLIENT_REVENUE_RAW.SABOS_12B1REBATE_VARIANT APPEND_ONLY = TRUE;

CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_12B1REBATE_VARIANT_STREAM
AS
SELECT
   SRC:"bdid"::string AS bdid
  ,SRC:"bonusgroup"::string AS bonusgroup
  ,SRC:"branchcode"::string AS branchcode
  ,SRC:"clearinghouse"::string AS clearinghouse
  ,SRC:"clientaccountnumber"::string AS clientaccountnumber
  ,SRC:"cusip"::string AS cusip
  ,SRC:"dcpaid"::string AS dcpaid
  ,SRC:"description"::string AS description
  ,SRC:"elt_primary_key"::string AS elt_primary_key
  ,SRC:"file_date"::string AS file_date
  ,SRC:"houseretention"::string AS houseretention
  ,SRC:"line_number"::string AS line_number
  ,SRC:"orig12b1amount"::string AS orig12b1amount
  ,SRC:"originalrepcode"::string AS originalrepcode
  ,SRC:"productid"::string AS productid
  ,SRC:"rebaterate"::string AS rebaterate
  ,SRC:"repayment"::string AS repayment
  ,SRC:"repcode"::string AS repcode
  ,SRC:"statementdate"::string AS statementdate
  ,SRC:"transactiondate"::string AS transactiondate
  ,SRC:"transactionid"::string AS transactionid
  ,SRC:"elt_execution_date"::string AS elt_execution_date
  ,SRC:"elt_source"::string AS elt_source
  ,SRC:"elt_load_type"::string AS elt_load_type
  ,SRC:"elt_delete_ind"::string AS elt_delete_ind
  ,SRC:"elt_dml_type"::string AS elt_dml_type
  ,SRC:"elt_reception_date"::string AS elt_reception_date
  ,SRC:"elt_process_id"::string AS elt_process_id
  ,SRC:"elt_firm"::string AS elt_firm
  ,SRC:"elt_pipelinekey"::string AS elt_pipelinekey
  ,METADATA$ACTION AS elt_stream_action
FROM CLIENT_REVENUE_RAW.SABOS_12B1REBATE_VARIANT_STREAM;

CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_12B1REBATE
AS
SELECT
   elt_integration_id
  ,bdid
  ,bonusgroup
  ,branchcode
  ,clearinghouse
  ,clientaccountnumber
  ,cusip
  ,dcpaid
  ,description
  ,elt_primary_key
  ,file_date
  ,houseretention
  ,line_number
  ,orig12b1amount
  ,originalrepcode
  ,productid
  ,rebaterate
  ,repayment
  ,repcode
  ,statementdate
  ,transactiondate
  ,transactionid
  ,elt_execution_date
  ,elt_source
  ,elt_load_type
  ,elt_delete_ind
  ,elt_dml_type
  ,elt_reception_date
  ,elt_process_id
  ,elt_firm
  ,elt_pipelinekey
  ,elt_columns_hash
  ,elt_stream_action
FROM
(
SELECT
   TRIM(CONCAT(COALESCE(src.elt_primary_key,'N/A'))) as elt_integration_id
  ,src.bdid
  ,src.bonusgroup
  ,src.branchcode
  ,src.clearinghouse
  ,src.clientaccountnumber
  ,src.cusip
  ,src.dcpaid
  ,src.description
  ,src.elt_primary_key
  ,src.file_date
  ,src.houseretention
  ,src.line_number
  ,src.orig12b1amount
  ,src.originalrepcode
  ,src.productid
  ,src.rebaterate
  ,src.repayment
  ,src.repcode
  ,src.statementdate
  ,src.transactiondate
  ,src.transactionid
  ,src.elt_execution_date
  ,src.elt_source
  ,src.elt_load_type
  ,src.elt_delete_ind
  ,src.elt_dml_type
  ,src.elt_reception_date
  ,src.elt_process_id
  ,src.elt_firm
  ,src.elt_pipelinekey
  ,SHA2(CONCAT(
       COALESCE(src.bdid,'N/A')
      ,COALESCE(src.bonusgroup,'N/A')
      ,COALESCE(src.branchcode,'N/A')
      ,COALESCE(src.clearinghouse,'N/A')
      ,COALESCE(src.clientaccountnumber,'N/A')
      ,COALESCE(src.cusip,'N/A')
      ,COALESCE(src.dcpaid,'N/A')
      ,COALESCE(src.description,'N/A')
      ,COALESCE(src.file_date,'N/A')
      ,COALESCE(src.houseretention,'N/A')
      ,COALESCE(src.line_number,'N/A')
      ,COALESCE(src.orig12b1amount,'N/A')
      ,COALESCE(src.originalrepcode,'N/A')
      ,COALESCE(src.productid,'N/A')
      ,COALESCE(src.rebaterate,'N/A')
      ,COALESCE(src.repayment,'N/A')
      ,COALESCE(src.repcode,'N/A')
      ,COALESCE(src.statementdate,'N/A')
      ,COALESCE(src.transactiondate,'N/A')
      ,COALESCE(src.transactionid,'N/A')
      )) AS elt_columns_hash
  ,src.elt_stream_action
  ,ROW_NUMBER() OVER (PARTITION BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action ORDER BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action, src.elt_execution_date DESC) AS top_slice
FROM CLIENT_REVENUE_RAW.VW_SABOS_12B1REBATE_VARIANT_STREAM src
)
WHERE top_slice = 1;


USE SCHEMA CLIENT_REVENUE;


CREATE OR REPLACE TABLE CLIENT_REVENUE.REBATE_12B1
(
   elt_integration_id VARCHAR NOT NULL
  ,bdid VARCHAR
  ,bonusgroup VARCHAR
  ,branchcode VARCHAR
  ,clearinghouse VARCHAR
  ,clientaccountnumber VARCHAR
  ,cusip VARCHAR
  ,dcpaid VARCHAR
  ,description VARCHAR
  ,elt_primary_key VARCHAR
  ,file_date VARCHAR
  ,houseretention VARCHAR
  ,line_number VARCHAR
  ,orig12b1amount VARCHAR
  ,originalrepcode VARCHAR
  ,productid VARCHAR
  ,rebaterate VARCHAR
  ,repayment VARCHAR
  ,repcode VARCHAR
  ,statementdate VARCHAR
  ,transactiondate VARCHAR
  ,transactionid VARCHAR
  ,elt_execution_date VARCHAR
  ,elt_source VARCHAR
  ,elt_load_type VARCHAR
  ,elt_delete_ind VARCHAR
  ,elt_dml_type VARCHAR
  ,elt_reception_date VARCHAR
  ,elt_process_id VARCHAR
  ,elt_firm VARCHAR
  ,elt_pipelinekey VARCHAR
  ,elt_columns_hash VARCHAR
  ,CONSTRAINT PK_CLIENT_REVENUE_SABOS_12B1REBATE PRIMARY KEY (elt_integration_id) NOT ENFORCED
);

CREATE OR REPLACE PROCEDURE CLIENT_REVENUE.USP_SABOS_12B1REBATE_MERGE()
RETURNS STRING
LANGUAGE JAVASCRIPT
EXECUTE AS CALLER
AS 
$$

function fixQuote(sql) { return sql.replace(/'/g, "''") }
//'


var sql_command = 
`
MERGE INTO CLIENT_REVENUE.REBATE_12B1 tgt
USING (
    SELECT * 
    FROM CLIENT_REVENUE_RAW.VW_SABOS_12B1REBATE
) src
ON (
TRIM(COALESCE(src.elt_integration_id,'N/A')) = TRIM(COALESCE(tgt.elt_integration_id,'N/A'))
)
WHEN MATCHED
AND (TRIM(COALESCE(src.elt_columns_hash,'N/A')) != TRIM(COALESCE(tgt.elt_columns_hash,'N/A')) OR tgt.elt_delete_ind=1)
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  UPDATE
  SET
     tgt.bdid = COALESCE(src.bdid, '')
    ,tgt.bonusgroup = COALESCE(src.bonusgroup, '')
    ,tgt.branchcode = COALESCE(src.branchcode, '')
    ,tgt.clearinghouse = COALESCE(src.clearinghouse, '')
    ,tgt.clientaccountnumber = COALESCE(src.clientaccountnumber, '')
    ,tgt.cusip = COALESCE(src.cusip, '')
    ,tgt.dcpaid = COALESCE(src.dcpaid, '')
    ,tgt.description = COALESCE(src.description, '')
    ,tgt.elt_primary_key = COALESCE(src.elt_primary_key, '')
    ,tgt.file_date = COALESCE(src.file_date, '')
    ,tgt.houseretention = COALESCE(src.houseretention, '')
    ,tgt.line_number = COALESCE(src.line_number, '')
    ,tgt.orig12b1amount = COALESCE(src.orig12b1amount, '')
    ,tgt.originalrepcode = COALESCE(src.originalrepcode, '')
    ,tgt.productid = COALESCE(src.productid, '')
    ,tgt.rebaterate = COALESCE(src.rebaterate, '')
    ,tgt.repayment = COALESCE(src.repayment, '')
    ,tgt.repcode = COALESCE(src.repcode, '')
    ,tgt.statementdate = COALESCE(src.statementdate, '')
    ,tgt.transactiondate = COALESCE(src.transactiondate, '')
    ,tgt.transactionid = COALESCE(src.transactionid, '')
    ,tgt.elt_execution_date = src.elt_execution_date
    ,tgt.elt_source = src.elt_source
    ,tgt.elt_load_type = src.elt_load_type
    ,tgt.elt_delete_ind = src.elt_delete_ind
    ,tgt.elt_dml_type = src.elt_dml_type
    ,tgt.elt_reception_date = src.elt_reception_date
    ,tgt.elt_process_id = src.elt_process_id
    ,tgt.elt_firm = src.elt_firm
    ,tgt.elt_pipelinekey = src.elt_pipelinekey
    ,tgt.elt_columns_hash = src.elt_columns_hash

WHEN NOT MATCHED
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  INSERT
  (
     elt_integration_id
    ,bdid
    ,bonusgroup
    ,branchcode
    ,clearinghouse
    ,clientaccountnumber
    ,cusip
    ,dcpaid
    ,description
    ,elt_primary_key
    ,file_date
    ,houseretention
    ,line_number
    ,orig12b1amount
    ,originalrepcode
    ,productid
    ,rebaterate
    ,repayment
    ,repcode
    ,statementdate
    ,transactiondate
    ,transactionid
    ,elt_execution_date
    ,elt_source
    ,elt_load_type
    ,elt_delete_ind
    ,elt_dml_type
    ,elt_reception_date
    ,elt_process_id
    ,elt_firm
    ,elt_pipelinekey
    ,elt_columns_hash
  )
  VALUES
  (
     src.elt_integration_id
    ,COALESCE(src.bdid, '')
    ,COALESCE(src.bonusgroup, '')
    ,COALESCE(src.branchcode, '')
    ,COALESCE(src.clearinghouse, '')
    ,COALESCE(src.clientaccountnumber, '')
    ,COALESCE(src.cusip, '')
    ,COALESCE(src.dcpaid, '')
    ,COALESCE(src.description, '')
    ,COALESCE(src.elt_primary_key, '')
    ,COALESCE(src.file_date, '')
    ,COALESCE(src.houseretention, '')
    ,COALESCE(src.line_number, '')
    ,COALESCE(src.orig12b1amount, '')
    ,COALESCE(src.originalrepcode, '')
    ,COALESCE(src.productid, '')
    ,COALESCE(src.rebaterate, '')
    ,COALESCE(src.repayment, '')
    ,COALESCE(src.repcode, '')
    ,COALESCE(src.statementdate, '')
    ,COALESCE(src.transactiondate, '')
    ,COALESCE(src.transactionid, '')
    ,src.elt_execution_date
    ,src.elt_source
    ,src.elt_load_type
    ,src.elt_delete_ind
    ,src.elt_dml_type
    ,src.elt_reception_date
    ,src.elt_process_id
    ,src.elt_firm
    ,src.elt_pipelinekey
    ,src.elt_columns_hash
  );
`;

var soft_delete_command = "CALL ELT_STAGE.USP_SOFT_DELETE_RAW('CLIENT_REVENUE_RAW.SABOS_12B1REBATE_VARIANT', 'CLIENT_REVENUE.REBATE_12B1');";

var usp_ingestion_command = "CALL ELT_STAGE.USP_INGESTION_RESULT('CLIENT_REVENUE.USP_SABOS_12B1REBATE_MERGE', ARRAY_CONSTRUCT('"+fixQuote(sql_command)+"', '"+fixQuote(soft_delete_command)+"'));";


try {
    execObj = snowflake.execute({sqlText: usp_ingestion_command});
    if (execObj.getRowCount()>0) {
        execObj.next();
        return execObj.getColumnValueAsString(1);
        }
    return "Succeeded.";
    }
catch (err)  {
    return "Failed: " + err;
    }
$$;

CREATE OR REPLACE TASK CLIENT_REVENUE.SABOS_12B1REBATE_MERGE_TASK
WAREHOUSE = DATA_LOAD_WH
SCHEDULE = '1 minute'
WHEN
SYSTEM$STREAM_HAS_DATA('CLIENT_REVENUE_RAW.SABOS_12B1REBATE_VARIANT_STREAM')
AS
    CALL CLIENT_REVENUE.USP_SABOS_12B1REBATE_MERGE();

ALTER TASK SABOS_12B1REBATE_MERGE_TASK RESUME;
