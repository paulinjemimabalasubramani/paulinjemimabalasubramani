USE SCHEMA CLIENT_REVENUE;



CREATE OR REPLACE TABLE CLIENT_REVENUE.ADJUSTMENT_DETAIL
(
   elt_integration_id VARCHAR NOT NULL
  ,adjustmentdetailtype VARCHAR
  ,adjustmentid VARCHAR
  ,amount VARCHAR
  ,bdid VARCHAR
  ,bonusgroup VARCHAR
  ,branchcode VARCHAR
  ,elt_primary_key VARCHAR
  ,file_date VARCHAR
  ,line_number VARCHAR
  ,rate VARCHAR
  ,repcode VARCHAR
  ,elt_execution_date VARCHAR
  ,elt_source VARCHAR
  ,elt_load_type VARCHAR
  ,elt_delete_ind VARCHAR
  ,elt_dml_type VARCHAR
  ,elt_reception_date VARCHAR
  ,elt_process_id VARCHAR
  ,elt_firm VARCHAR
  ,elt_pipelinekey VARCHAR
  ,elt_columns_hash VARCHAR
  ,CONSTRAINT PK_CLIENT_REVENUE_SABOS_ADJUSTMENT_DETAIL PRIMARY KEY (elt_integration_id) NOT ENFORCED
);




CREATE OR REPLACE PROCEDURE CLIENT_REVENUE.USP_SABOS_ADJUSTMENT_DETAIL_MERGE()
RETURNS STRING
LANGUAGE JAVASCRIPT
EXECUTE AS CALLER
AS 
$$

function fixQuote(sql) { return sql.replace(/'/g, "''") }
//'


var sql_command = 
`
MERGE INTO CLIENT_REVENUE.ADJUSTMENT_DETAIL tgt
USING (
    SELECT * 
    FROM CLIENT_REVENUE_RAW.VW_SABOS_ADJUSTMENT_DETAIL
) src
ON (
TRIM(COALESCE(src.elt_integration_id,'N/A')) = TRIM(COALESCE(tgt.elt_integration_id,'N/A'))
)
WHEN MATCHED
AND (TRIM(COALESCE(src.elt_columns_hash,'N/A')) != TRIM(COALESCE(tgt.elt_columns_hash,'N/A')) OR tgt.elt_delete_ind=1)
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  UPDATE
  SET
     tgt.adjustmentdetailtype = COALESCE(src.adjustmentdetailtype, '')
    ,tgt.adjustmentid = COALESCE(src.adjustmentid, '')
    ,tgt.amount = COALESCE(src.amount, '')
    ,tgt.bdid = COALESCE(src.bdid, '')
    ,tgt.bonusgroup = COALESCE(src.bonusgroup, '')
    ,tgt.branchcode = COALESCE(src.branchcode, '')
    ,tgt.elt_primary_key = COALESCE(src.elt_primary_key, '')
    ,tgt.file_date = COALESCE(src.file_date, '')
    ,tgt.line_number = COALESCE(src.line_number, '')
    ,tgt.rate = COALESCE(src.rate, '')
    ,tgt.repcode = COALESCE(src.repcode, '')
    ,tgt.elt_execution_date = src.elt_execution_date
    ,tgt.elt_source = src.elt_source
    ,tgt.elt_load_type = src.elt_load_type
    ,tgt.elt_delete_ind = src.elt_delete_ind
    ,tgt.elt_dml_type = src.elt_dml_type
    ,tgt.elt_reception_date = src.elt_reception_date
    ,tgt.elt_process_id = src.elt_process_id
    ,tgt.elt_firm = src.elt_firm
    ,tgt.elt_pipelinekey = src.elt_pipelinekey
    ,tgt.elt_columns_hash = src.elt_columns_hash

WHEN NOT MATCHED
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  INSERT
  (
     elt_integration_id
    ,adjustmentdetailtype
    ,adjustmentid
    ,amount
    ,bdid
    ,bonusgroup
    ,branchcode
    ,elt_primary_key
    ,file_date
    ,line_number
    ,rate
    ,repcode
    ,elt_execution_date
    ,elt_source
    ,elt_load_type
    ,elt_delete_ind
    ,elt_dml_type
    ,elt_reception_date
    ,elt_process_id
    ,elt_firm
    ,elt_pipelinekey
    ,elt_columns_hash
  )
  VALUES
  (
     src.elt_integration_id
    ,COALESCE(src.adjustmentdetailtype, '')
    ,COALESCE(src.adjustmentid, '')
    ,COALESCE(src.amount, '')
    ,COALESCE(src.bdid, '')
    ,COALESCE(src.bonusgroup, '')
    ,COALESCE(src.branchcode, '')
    ,COALESCE(src.elt_primary_key, '')
    ,COALESCE(src.file_date, '')
    ,COALESCE(src.line_number, '')
    ,COALESCE(src.rate, '')
    ,COALESCE(src.repcode, '')
    ,src.elt_execution_date
    ,src.elt_source
    ,src.elt_load_type
    ,src.elt_delete_ind
    ,src.elt_dml_type
    ,src.elt_reception_date
    ,src.elt_process_id
    ,src.elt_firm
    ,src.elt_pipelinekey
    ,src.elt_columns_hash
  );
`;

var soft_delete_command = "CALL ELT_STAGE.USP_SOFT_DELETE_RAW('CLIENT_REVENUE_RAW.SABOS_ADJUSTMENT_DETAIL_VARIANT', 'CLIENT_REVENUE.ADJUSTMENT_DETAIL');";

var usp_ingestion_command = "CALL ELT_STAGE.USP_INGESTION_RESULT('CLIENT_REVENUE.USP_SABOS_ADJUSTMENT_DETAIL_MERGE', ARRAY_CONSTRUCT('"+fixQuote(sql_command)+"', '"+fixQuote(soft_delete_command)+"'));";


try {
    execObj = snowflake.execute({sqlText: usp_ingestion_command});
    if (execObj.getRowCount()>0) {
        execObj.next();
        return execObj.getColumnValueAsString(1);
        }
    return "Succeeded.";
    }
catch (err)  {
    return "Failed: " + err;
    }
$$;




CREATE OR REPLACE TASK CLIENT_REVENUE.SABOS_ADJUSTMENT_DETAIL_MERGE_TASK
WAREHOUSE = DATA_LOAD_WH
SCHEDULE = '1 minute'
WHEN
SYSTEM$STREAM_HAS_DATA('CLIENT_REVENUE_RAW.SABOS_ADJUSTMENT_DETAIL_VARIANT_STREAM')
AS
    CALL CLIENT_REVENUE.USP_SABOS_ADJUSTMENT_DETAIL_MERGE();




CREATE OR REPLACE TABLE CLIENT_REVENUE.ADJUSTMENT_REASONCODE
(
   elt_integration_id VARCHAR NOT NULL
  ,bdid VARCHAR
  ,description VARCHAR
  ,elt_primary_key VARCHAR
  ,file_date VARCHAR
  ,isdeferredcomp VARCHAR
  ,istaxable VARCHAR
  ,line_number VARCHAR
  ,reasoncode VARCHAR
  ,elt_execution_date VARCHAR
  ,elt_source VARCHAR
  ,elt_load_type VARCHAR
  ,elt_delete_ind VARCHAR
  ,elt_dml_type VARCHAR
  ,elt_reception_date VARCHAR
  ,elt_process_id VARCHAR
  ,elt_firm VARCHAR
  ,elt_pipelinekey VARCHAR
  ,elt_columns_hash VARCHAR
  ,CONSTRAINT PK_CLIENT_REVENUE_SABOS_ADJUSTMENT_REASONCODE PRIMARY KEY (elt_integration_id) NOT ENFORCED
);




CREATE OR REPLACE PROCEDURE CLIENT_REVENUE.USP_SABOS_ADJUSTMENT_REASONCODE_MERGE()
RETURNS STRING
LANGUAGE JAVASCRIPT
EXECUTE AS CALLER
AS 
$$

function fixQuote(sql) { return sql.replace(/'/g, "''") }
//'


var sql_command = 
`
MERGE INTO CLIENT_REVENUE.ADJUSTMENT_REASONCODE tgt
USING (
    SELECT * 
    FROM CLIENT_REVENUE_RAW.VW_SABOS_ADJUSTMENT_REASONCODE
) src
ON (
TRIM(COALESCE(src.elt_integration_id,'N/A')) = TRIM(COALESCE(tgt.elt_integration_id,'N/A'))
)
WHEN MATCHED
AND (TRIM(COALESCE(src.elt_columns_hash,'N/A')) != TRIM(COALESCE(tgt.elt_columns_hash,'N/A')) OR tgt.elt_delete_ind=1)
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  UPDATE
  SET
     tgt.bdid = COALESCE(src.bdid, '')
    ,tgt.description = COALESCE(src.description, '')
    ,tgt.elt_primary_key = COALESCE(src.elt_primary_key, '')
    ,tgt.file_date = COALESCE(src.file_date, '')
    ,tgt.isdeferredcomp = COALESCE(src.isdeferredcomp, '')
    ,tgt.istaxable = COALESCE(src.istaxable, '')
    ,tgt.line_number = COALESCE(src.line_number, '')
    ,tgt.reasoncode = COALESCE(src.reasoncode, '')
    ,tgt.elt_execution_date = src.elt_execution_date
    ,tgt.elt_source = src.elt_source
    ,tgt.elt_load_type = src.elt_load_type
    ,tgt.elt_delete_ind = src.elt_delete_ind
    ,tgt.elt_dml_type = src.elt_dml_type
    ,tgt.elt_reception_date = src.elt_reception_date
    ,tgt.elt_process_id = src.elt_process_id
    ,tgt.elt_firm = src.elt_firm
    ,tgt.elt_pipelinekey = src.elt_pipelinekey
    ,tgt.elt_columns_hash = src.elt_columns_hash

WHEN NOT MATCHED
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  INSERT
  (
     elt_integration_id
    ,bdid
    ,description
    ,elt_primary_key
    ,file_date
    ,isdeferredcomp
    ,istaxable
    ,line_number
    ,reasoncode
    ,elt_execution_date
    ,elt_source
    ,elt_load_type
    ,elt_delete_ind
    ,elt_dml_type
    ,elt_reception_date
    ,elt_process_id
    ,elt_firm
    ,elt_pipelinekey
    ,elt_columns_hash
  )
  VALUES
  (
     src.elt_integration_id
    ,COALESCE(src.bdid, '')
    ,COALESCE(src.description, '')
    ,COALESCE(src.elt_primary_key, '')
    ,COALESCE(src.file_date, '')
    ,COALESCE(src.isdeferredcomp, '')
    ,COALESCE(src.istaxable, '')
    ,COALESCE(src.line_number, '')
    ,COALESCE(src.reasoncode, '')
    ,src.elt_execution_date
    ,src.elt_source
    ,src.elt_load_type
    ,src.elt_delete_ind
    ,src.elt_dml_type
    ,src.elt_reception_date
    ,src.elt_process_id
    ,src.elt_firm
    ,src.elt_pipelinekey
    ,src.elt_columns_hash
  );
`;

var soft_delete_command = "CALL ELT_STAGE.USP_SOFT_DELETE_RAW('CLIENT_REVENUE_RAW.SABOS_ADJUSTMENT_REASONCODE_VARIANT', 'CLIENT_REVENUE.ADJUSTMENT_REASONCODE');";

var usp_ingestion_command = "CALL ELT_STAGE.USP_INGESTION_RESULT('CLIENT_REVENUE.USP_SABOS_ADJUSTMENT_REASONCODE_MERGE', ARRAY_CONSTRUCT('"+fixQuote(sql_command)+"', '"+fixQuote(soft_delete_command)+"'));";


try {
    execObj = snowflake.execute({sqlText: usp_ingestion_command});
    if (execObj.getRowCount()>0) {
        execObj.next();
        return execObj.getColumnValueAsString(1);
        }
    return "Succeeded.";
    }
catch (err)  {
    return "Failed: " + err;
    }
$$;




CREATE OR REPLACE TASK CLIENT_REVENUE.SABOS_ADJUSTMENT_REASONCODE_MERGE_TASK
WAREHOUSE = DATA_LOAD_WH
SCHEDULE = '1 minute'
WHEN
SYSTEM$STREAM_HAS_DATA('CLIENT_REVENUE_RAW.SABOS_ADJUSTMENT_REASONCODE_VARIANT_STREAM')
AS
    CALL CLIENT_REVENUE.USP_SABOS_ADJUSTMENT_REASONCODE_MERGE();




CREATE OR REPLACE TABLE CLIENT_REVENUE.ADJUSTMENT
(
   elt_integration_id VARCHAR NOT NULL
  ,accountnumber VARCHAR
  ,adjustmentamount VARCHAR
  ,adjustmentid VARCHAR
  ,adjustmenttype VARCHAR
  ,bdid VARCHAR
  ,bonusgroup VARCHAR
  ,branchcode VARCHAR
  ,businessdevcode VARCHAR
  ,buysellindicator VARCHAR
  ,cancelcorrectcode VARCHAR
  ,cancellationdate VARCHAR
  ,cancellationreason VARCHAR
  ,cancelledbyadjustmentid VARCHAR
  ,clearinghouse VARCHAR
  ,clientssn VARCHAR
  ,company VARCHAR
  ,cycledate VARCHAR
  ,description VARCHAR
  ,elt_primary_key VARCHAR
  ,file_date VARCHAR
  ,line_number VARCHAR
  ,originaladjustmentid VARCHAR
  ,originalrepcode VARCHAR
  ,reasoncode VARCHAR
  ,repcode VARCHAR
  ,splittransactionnumber VARCHAR
  ,tradenumber VARCHAR
  ,transactiondate VARCHAR
  ,transactionid VARCHAR
  ,elt_execution_date VARCHAR
  ,elt_source VARCHAR
  ,elt_load_type VARCHAR
  ,elt_delete_ind VARCHAR
  ,elt_dml_type VARCHAR
  ,elt_reception_date VARCHAR
  ,elt_process_id VARCHAR
  ,elt_firm VARCHAR
  ,elt_pipelinekey VARCHAR
  ,elt_columns_hash VARCHAR
  ,CONSTRAINT PK_CLIENT_REVENUE_SABOS_ADJUSTMENT PRIMARY KEY (elt_integration_id) NOT ENFORCED
);




CREATE OR REPLACE PROCEDURE CLIENT_REVENUE.USP_SABOS_ADJUSTMENT_MERGE()
RETURNS STRING
LANGUAGE JAVASCRIPT
EXECUTE AS CALLER
AS 
$$

function fixQuote(sql) { return sql.replace(/'/g, "''") }
//'


var sql_command = 
`
MERGE INTO CLIENT_REVENUE.ADJUSTMENT tgt
USING (
    SELECT * 
    FROM CLIENT_REVENUE_RAW.VW_SABOS_ADJUSTMENT
) src
ON (
TRIM(COALESCE(src.elt_integration_id,'N/A')) = TRIM(COALESCE(tgt.elt_integration_id,'N/A'))
)
WHEN MATCHED
AND (TRIM(COALESCE(src.elt_columns_hash,'N/A')) != TRIM(COALESCE(tgt.elt_columns_hash,'N/A')) OR tgt.elt_delete_ind=1)
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  UPDATE
  SET
     tgt.accountnumber = COALESCE(src.accountnumber, '')
    ,tgt.adjustmentamount = COALESCE(src.adjustmentamount, '')
    ,tgt.adjustmentid = COALESCE(src.adjustmentid, '')
    ,tgt.adjustmenttype = COALESCE(src.adjustmenttype, '')
    ,tgt.bdid = COALESCE(src.bdid, '')
    ,tgt.bonusgroup = COALESCE(src.bonusgroup, '')
    ,tgt.branchcode = COALESCE(src.branchcode, '')
    ,tgt.businessdevcode = COALESCE(src.businessdevcode, '')
    ,tgt.buysellindicator = COALESCE(src.buysellindicator, '')
    ,tgt.cancelcorrectcode = COALESCE(src.cancelcorrectcode, '')
    ,tgt.cancellationdate = COALESCE(src.cancellationdate, '')
    ,tgt.cancellationreason = COALESCE(src.cancellationreason, '')
    ,tgt.cancelledbyadjustmentid = COALESCE(src.cancelledbyadjustmentid, '')
    ,tgt.clearinghouse = COALESCE(src.clearinghouse, '')
    ,tgt.clientssn = COALESCE(src.clientssn, '')
    ,tgt.company = COALESCE(src.company, '')
    ,tgt.cycledate = COALESCE(src.cycledate, '')
    ,tgt.description = COALESCE(src.description, '')
    ,tgt.elt_primary_key = COALESCE(src.elt_primary_key, '')
    ,tgt.file_date = COALESCE(src.file_date, '')
    ,tgt.line_number = COALESCE(src.line_number, '')
    ,tgt.originaladjustmentid = COALESCE(src.originaladjustmentid, '')
    ,tgt.originalrepcode = COALESCE(src.originalrepcode, '')
    ,tgt.reasoncode = COALESCE(src.reasoncode, '')
    ,tgt.repcode = COALESCE(src.repcode, '')
    ,tgt.splittransactionnumber = COALESCE(src.splittransactionnumber, '')
    ,tgt.tradenumber = COALESCE(src.tradenumber, '')
    ,tgt.transactiondate = COALESCE(src.transactiondate, '')
    ,tgt.transactionid = COALESCE(src.transactionid, '')
    ,tgt.elt_execution_date = src.elt_execution_date
    ,tgt.elt_source = src.elt_source
    ,tgt.elt_load_type = src.elt_load_type
    ,tgt.elt_delete_ind = src.elt_delete_ind
    ,tgt.elt_dml_type = src.elt_dml_type
    ,tgt.elt_reception_date = src.elt_reception_date
    ,tgt.elt_process_id = src.elt_process_id
    ,tgt.elt_firm = src.elt_firm
    ,tgt.elt_pipelinekey = src.elt_pipelinekey
    ,tgt.elt_columns_hash = src.elt_columns_hash

WHEN NOT MATCHED
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  INSERT
  (
     elt_integration_id
    ,accountnumber
    ,adjustmentamount
    ,adjustmentid
    ,adjustmenttype
    ,bdid
    ,bonusgroup
    ,branchcode
    ,businessdevcode
    ,buysellindicator
    ,cancelcorrectcode
    ,cancellationdate
    ,cancellationreason
    ,cancelledbyadjustmentid
    ,clearinghouse
    ,clientssn
    ,company
    ,cycledate
    ,description
    ,elt_primary_key
    ,file_date
    ,line_number
    ,originaladjustmentid
    ,originalrepcode
    ,reasoncode
    ,repcode
    ,splittransactionnumber
    ,tradenumber
    ,transactiondate
    ,transactionid
    ,elt_execution_date
    ,elt_source
    ,elt_load_type
    ,elt_delete_ind
    ,elt_dml_type
    ,elt_reception_date
    ,elt_process_id
    ,elt_firm
    ,elt_pipelinekey
    ,elt_columns_hash
  )
  VALUES
  (
     src.elt_integration_id
    ,COALESCE(src.accountnumber, '')
    ,COALESCE(src.adjustmentamount, '')
    ,COALESCE(src.adjustmentid, '')
    ,COALESCE(src.adjustmenttype, '')
    ,COALESCE(src.bdid, '')
    ,COALESCE(src.bonusgroup, '')
    ,COALESCE(src.branchcode, '')
    ,COALESCE(src.businessdevcode, '')
    ,COALESCE(src.buysellindicator, '')
    ,COALESCE(src.cancelcorrectcode, '')
    ,COALESCE(src.cancellationdate, '')
    ,COALESCE(src.cancellationreason, '')
    ,COALESCE(src.cancelledbyadjustmentid, '')
    ,COALESCE(src.clearinghouse, '')
    ,COALESCE(src.clientssn, '')
    ,COALESCE(src.company, '')
    ,COALESCE(src.cycledate, '')
    ,COALESCE(src.description, '')
    ,COALESCE(src.elt_primary_key, '')
    ,COALESCE(src.file_date, '')
    ,COALESCE(src.line_number, '')
    ,COALESCE(src.originaladjustmentid, '')
    ,COALESCE(src.originalrepcode, '')
    ,COALESCE(src.reasoncode, '')
    ,COALESCE(src.repcode, '')
    ,COALESCE(src.splittransactionnumber, '')
    ,COALESCE(src.tradenumber, '')
    ,COALESCE(src.transactiondate, '')
    ,COALESCE(src.transactionid, '')
    ,src.elt_execution_date
    ,src.elt_source
    ,src.elt_load_type
    ,src.elt_delete_ind
    ,src.elt_dml_type
    ,src.elt_reception_date
    ,src.elt_process_id
    ,src.elt_firm
    ,src.elt_pipelinekey
    ,src.elt_columns_hash
  );
`;

var soft_delete_command = "CALL ELT_STAGE.USP_SOFT_DELETE_RAW('CLIENT_REVENUE_RAW.SABOS_ADJUSTMENT_VARIANT', 'CLIENT_REVENUE.ADJUSTMENT');";

var usp_ingestion_command = "CALL ELT_STAGE.USP_INGESTION_RESULT('CLIENT_REVENUE.USP_SABOS_ADJUSTMENT_MERGE', ARRAY_CONSTRUCT('"+fixQuote(sql_command)+"', '"+fixQuote(soft_delete_command)+"'));";


try {
    execObj = snowflake.execute({sqlText: usp_ingestion_command});
    if (execObj.getRowCount()>0) {
        execObj.next();
        return execObj.getColumnValueAsString(1);
        }
    return "Succeeded.";
    }
catch (err)  {
    return "Failed: " + err;
    }
$$;




CREATE OR REPLACE TASK CLIENT_REVENUE.SABOS_ADJUSTMENT_MERGE_TASK
WAREHOUSE = DATA_LOAD_WH
SCHEDULE = '1 minute'
WHEN
SYSTEM$STREAM_HAS_DATA('CLIENT_REVENUE_RAW.SABOS_ADJUSTMENT_VARIANT_STREAM')
AS
    CALL CLIENT_REVENUE.USP_SABOS_ADJUSTMENT_MERGE();




CREATE OR REPLACE TABLE CLIENT_REVENUE.TRAILS_12B1
(
   elt_integration_id VARCHAR NOT NULL
  ,amount VARCHAR
  ,bdid VARCHAR
  ,bonusgroup VARCHAR
  ,branchcode VARCHAR
  ,clientaccountnumber VARCHAR
  ,clientname VARCHAR
  ,cusip VARCHAR
  ,dcpaid VARCHAR
  ,elt_primary_key VARCHAR
  ,file_date VARCHAR
  ,isbrokerage VARCHAR
  ,line_number VARCHAR
  ,productsponsorcode VARCHAR
  ,repcode VARCHAR
  ,sourcetransactionnumber VARCHAR
  ,statementdate VARCHAR
  ,transactiondate VARCHAR
  ,transactiontype VARCHAR
  ,elt_execution_date VARCHAR
  ,elt_source VARCHAR
  ,elt_load_type VARCHAR
  ,elt_delete_ind VARCHAR
  ,elt_dml_type VARCHAR
  ,elt_reception_date VARCHAR
  ,elt_process_id VARCHAR
  ,elt_firm VARCHAR
  ,elt_pipelinekey VARCHAR
  ,elt_columns_hash VARCHAR
  ,CONSTRAINT PK_CLIENT_REVENUE_SABOS_12B1TRAILS PRIMARY KEY (elt_integration_id) NOT ENFORCED
);




CREATE OR REPLACE PROCEDURE CLIENT_REVENUE.USP_SABOS_12B1TRAILS_MERGE()
RETURNS STRING
LANGUAGE JAVASCRIPT
EXECUTE AS CALLER
AS 
$$

function fixQuote(sql) { return sql.replace(/'/g, "''") }
//'


var sql_command = 
`
MERGE INTO CLIENT_REVENUE.TRAILS_12B1 tgt
USING (
    SELECT * 
    FROM CLIENT_REVENUE_RAW.VW_SABOS_12B1TRAILS
) src
ON (
TRIM(COALESCE(src.elt_integration_id,'N/A')) = TRIM(COALESCE(tgt.elt_integration_id,'N/A'))
)
WHEN MATCHED
AND (TRIM(COALESCE(src.elt_columns_hash,'N/A')) != TRIM(COALESCE(tgt.elt_columns_hash,'N/A')) OR tgt.elt_delete_ind=1)
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  UPDATE
  SET
     tgt.amount = COALESCE(src.amount, '')
    ,tgt.bdid = COALESCE(src.bdid, '')
    ,tgt.bonusgroup = COALESCE(src.bonusgroup, '')
    ,tgt.branchcode = COALESCE(src.branchcode, '')
    ,tgt.clientaccountnumber = COALESCE(src.clientaccountnumber, '')
    ,tgt.clientname = COALESCE(src.clientname, '')
    ,tgt.cusip = COALESCE(src.cusip, '')
    ,tgt.dcpaid = COALESCE(src.dcpaid, '')
    ,tgt.elt_primary_key = COALESCE(src.elt_primary_key, '')
    ,tgt.file_date = COALESCE(src.file_date, '')
    ,tgt.isbrokerage = COALESCE(src.isbrokerage, '')
    ,tgt.line_number = COALESCE(src.line_number, '')
    ,tgt.productsponsorcode = COALESCE(src.productsponsorcode, '')
    ,tgt.repcode = COALESCE(src.repcode, '')
    ,tgt.sourcetransactionnumber = COALESCE(src.sourcetransactionnumber, '')
    ,tgt.statementdate = COALESCE(src.statementdate, '')
    ,tgt.transactiondate = COALESCE(src.transactiondate, '')
    ,tgt.transactiontype = COALESCE(src.transactiontype, '')
    ,tgt.elt_execution_date = src.elt_execution_date
    ,tgt.elt_source = src.elt_source
    ,tgt.elt_load_type = src.elt_load_type
    ,tgt.elt_delete_ind = src.elt_delete_ind
    ,tgt.elt_dml_type = src.elt_dml_type
    ,tgt.elt_reception_date = src.elt_reception_date
    ,tgt.elt_process_id = src.elt_process_id
    ,tgt.elt_firm = src.elt_firm
    ,tgt.elt_pipelinekey = src.elt_pipelinekey
    ,tgt.elt_columns_hash = src.elt_columns_hash

WHEN NOT MATCHED
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  INSERT
  (
     elt_integration_id
    ,amount
    ,bdid
    ,bonusgroup
    ,branchcode
    ,clientaccountnumber
    ,clientname
    ,cusip
    ,dcpaid
    ,elt_primary_key
    ,file_date
    ,isbrokerage
    ,line_number
    ,productsponsorcode
    ,repcode
    ,sourcetransactionnumber
    ,statementdate
    ,transactiondate
    ,transactiontype
    ,elt_execution_date
    ,elt_source
    ,elt_load_type
    ,elt_delete_ind
    ,elt_dml_type
    ,elt_reception_date
    ,elt_process_id
    ,elt_firm
    ,elt_pipelinekey
    ,elt_columns_hash
  )
  VALUES
  (
     src.elt_integration_id
    ,COALESCE(src.amount, '')
    ,COALESCE(src.bdid, '')
    ,COALESCE(src.bonusgroup, '')
    ,COALESCE(src.branchcode, '')
    ,COALESCE(src.clientaccountnumber, '')
    ,COALESCE(src.clientname, '')
    ,COALESCE(src.cusip, '')
    ,COALESCE(src.dcpaid, '')
    ,COALESCE(src.elt_primary_key, '')
    ,COALESCE(src.file_date, '')
    ,COALESCE(src.isbrokerage, '')
    ,COALESCE(src.line_number, '')
    ,COALESCE(src.productsponsorcode, '')
    ,COALESCE(src.repcode, '')
    ,COALESCE(src.sourcetransactionnumber, '')
    ,COALESCE(src.statementdate, '')
    ,COALESCE(src.transactiondate, '')
    ,COALESCE(src.transactiontype, '')
    ,src.elt_execution_date
    ,src.elt_source
    ,src.elt_load_type
    ,src.elt_delete_ind
    ,src.elt_dml_type
    ,src.elt_reception_date
    ,src.elt_process_id
    ,src.elt_firm
    ,src.elt_pipelinekey
    ,src.elt_columns_hash
  );
`;

var soft_delete_command = "CALL ELT_STAGE.USP_SOFT_DELETE_RAW('CLIENT_REVENUE_RAW.SABOS_12B1TRAILS_VARIANT', 'CLIENT_REVENUE.TRAILS_12B1');";

var usp_ingestion_command = "CALL ELT_STAGE.USP_INGESTION_RESULT('CLIENT_REVENUE.USP_SABOS_12B1TRAILS_MERGE', ARRAY_CONSTRUCT('"+fixQuote(sql_command)+"', '"+fixQuote(soft_delete_command)+"'));";


try {
    execObj = snowflake.execute({sqlText: usp_ingestion_command});
    if (execObj.getRowCount()>0) {
        execObj.next();
        return execObj.getColumnValueAsString(1);
        }
    return "Succeeded.";
    }
catch (err)  {
    return "Failed: " + err;
    }
$$;




CREATE OR REPLACE TASK CLIENT_REVENUE.SABOS_12B1TRAILS_MERGE_TASK
WAREHOUSE = DATA_LOAD_WH
SCHEDULE = '1 minute'
WHEN
SYSTEM$STREAM_HAS_DATA('CLIENT_REVENUE_RAW.SABOS_12B1TRAILS_VARIANT_STREAM')
AS
    CALL CLIENT_REVENUE.USP_SABOS_12B1TRAILS_MERGE();




CREATE OR REPLACE TABLE CLIENT_REVENUE.GROUPREPCODE
(
   elt_integration_id VARCHAR NOT NULL
  ,bdid VARCHAR
  ,elt_primary_key VARCHAR
  ,file_date VARCHAR
  ,groupid VARCHAR
  ,groupname VARCHAR
  ,line_number VARCHAR
  ,productcategory VARCHAR
  ,repcode VARCHAR
  ,splitpercent VARCHAR
  ,elt_execution_date VARCHAR
  ,elt_source VARCHAR
  ,elt_load_type VARCHAR
  ,elt_delete_ind VARCHAR
  ,elt_dml_type VARCHAR
  ,elt_reception_date VARCHAR
  ,elt_process_id VARCHAR
  ,elt_firm VARCHAR
  ,elt_pipelinekey VARCHAR
  ,elt_columns_hash VARCHAR
  ,CONSTRAINT PK_CLIENT_REVENUE_SABOS_GROUPREPCODE PRIMARY KEY (elt_integration_id) NOT ENFORCED
);




CREATE OR REPLACE PROCEDURE CLIENT_REVENUE.USP_SABOS_GROUPREPCODE_MERGE()
RETURNS STRING
LANGUAGE JAVASCRIPT
EXECUTE AS CALLER
AS 
$$

function fixQuote(sql) { return sql.replace(/'/g, "''") }
//'


var sql_command = 
`
MERGE INTO CLIENT_REVENUE.GROUPREPCODE tgt
USING (
    SELECT * 
    FROM CLIENT_REVENUE_RAW.VW_SABOS_GROUPREPCODE
) src
ON (
TRIM(COALESCE(src.elt_integration_id,'N/A')) = TRIM(COALESCE(tgt.elt_integration_id,'N/A'))
)
WHEN MATCHED
AND (TRIM(COALESCE(src.elt_columns_hash,'N/A')) != TRIM(COALESCE(tgt.elt_columns_hash,'N/A')) OR tgt.elt_delete_ind=1)
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  UPDATE
  SET
     tgt.bdid = COALESCE(src.bdid, '')
    ,tgt.elt_primary_key = COALESCE(src.elt_primary_key, '')
    ,tgt.file_date = COALESCE(src.file_date, '')
    ,tgt.groupid = COALESCE(src.groupid, '')
    ,tgt.groupname = COALESCE(src.groupname, '')
    ,tgt.line_number = COALESCE(src.line_number, '')
    ,tgt.productcategory = COALESCE(src.productcategory, '')
    ,tgt.repcode = COALESCE(src.repcode, '')
    ,tgt.splitpercent = COALESCE(src.splitpercent, '')
    ,tgt.elt_execution_date = src.elt_execution_date
    ,tgt.elt_source = src.elt_source
    ,tgt.elt_load_type = src.elt_load_type
    ,tgt.elt_delete_ind = src.elt_delete_ind
    ,tgt.elt_dml_type = src.elt_dml_type
    ,tgt.elt_reception_date = src.elt_reception_date
    ,tgt.elt_process_id = src.elt_process_id
    ,tgt.elt_firm = src.elt_firm
    ,tgt.elt_pipelinekey = src.elt_pipelinekey
    ,tgt.elt_columns_hash = src.elt_columns_hash

WHEN NOT MATCHED
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  INSERT
  (
     elt_integration_id
    ,bdid
    ,elt_primary_key
    ,file_date
    ,groupid
    ,groupname
    ,line_number
    ,productcategory
    ,repcode
    ,splitpercent
    ,elt_execution_date
    ,elt_source
    ,elt_load_type
    ,elt_delete_ind
    ,elt_dml_type
    ,elt_reception_date
    ,elt_process_id
    ,elt_firm
    ,elt_pipelinekey
    ,elt_columns_hash
  )
  VALUES
  (
     src.elt_integration_id
    ,COALESCE(src.bdid, '')
    ,COALESCE(src.elt_primary_key, '')
    ,COALESCE(src.file_date, '')
    ,COALESCE(src.groupid, '')
    ,COALESCE(src.groupname, '')
    ,COALESCE(src.line_number, '')
    ,COALESCE(src.productcategory, '')
    ,COALESCE(src.repcode, '')
    ,COALESCE(src.splitpercent, '')
    ,src.elt_execution_date
    ,src.elt_source
    ,src.elt_load_type
    ,src.elt_delete_ind
    ,src.elt_dml_type
    ,src.elt_reception_date
    ,src.elt_process_id
    ,src.elt_firm
    ,src.elt_pipelinekey
    ,src.elt_columns_hash
  );
`;

var soft_delete_command = "CALL ELT_STAGE.USP_SOFT_DELETE_RAW('CLIENT_REVENUE_RAW.SABOS_GROUPREPCODE_VARIANT', 'CLIENT_REVENUE.GROUPREPCODE');";

var usp_ingestion_command = "CALL ELT_STAGE.USP_INGESTION_RESULT('CLIENT_REVENUE.USP_SABOS_GROUPREPCODE_MERGE', ARRAY_CONSTRUCT('"+fixQuote(sql_command)+"', '"+fixQuote(soft_delete_command)+"'));";


try {
    execObj = snowflake.execute({sqlText: usp_ingestion_command});
    if (execObj.getRowCount()>0) {
        execObj.next();
        return execObj.getColumnValueAsString(1);
        }
    return "Succeeded.";
    }
catch (err)  {
    return "Failed: " + err;
    }
$$;




CREATE OR REPLACE TASK CLIENT_REVENUE.SABOS_GROUPREPCODE_MERGE_TASK
WAREHOUSE = DATA_LOAD_WH
SCHEDULE = '1 minute'
WHEN
SYSTEM$STREAM_HAS_DATA('CLIENT_REVENUE_RAW.SABOS_GROUPREPCODE_VARIANT_STREAM')
AS
    CALL CLIENT_REVENUE.USP_SABOS_GROUPREPCODE_MERGE();




CREATE OR REPLACE TABLE CLIENT_REVENUE.REPHIERARCHYTREE
(
   elt_integration_id VARCHAR NOT NULL
  ,bdid VARCHAR
  ,elt_primary_key VARCHAR
  ,file_date VARCHAR
  ,level1brachid VARCHAR
  ,level1rep VARCHAR
  ,level2branchid VARCHAR
  ,level2rep VARCHAR
  ,level3branchid VARCHAR
  ,level3rep VARCHAR
  ,line_number VARCHAR
  ,repbranchid VARCHAR
  ,repcode VARCHAR
  ,statementdate VARCHAR
  ,elt_execution_date VARCHAR
  ,elt_source VARCHAR
  ,elt_load_type VARCHAR
  ,elt_delete_ind VARCHAR
  ,elt_dml_type VARCHAR
  ,elt_reception_date VARCHAR
  ,elt_process_id VARCHAR
  ,elt_firm VARCHAR
  ,elt_pipelinekey VARCHAR
  ,elt_columns_hash VARCHAR
  ,CONSTRAINT PK_CLIENT_REVENUE_SABOS_REPHIERARCHYTREE PRIMARY KEY (elt_integration_id) NOT ENFORCED
);




CREATE OR REPLACE PROCEDURE CLIENT_REVENUE.USP_SABOS_REPHIERARCHYTREE_MERGE()
RETURNS STRING
LANGUAGE JAVASCRIPT
EXECUTE AS CALLER
AS 
$$

function fixQuote(sql) { return sql.replace(/'/g, "''") }
//'


var sql_command = 
`
MERGE INTO CLIENT_REVENUE.REPHIERARCHYTREE tgt
USING (
    SELECT * 
    FROM CLIENT_REVENUE_RAW.VW_SABOS_REPHIERARCHYTREE
) src
ON (
TRIM(COALESCE(src.elt_integration_id,'N/A')) = TRIM(COALESCE(tgt.elt_integration_id,'N/A'))
)
WHEN MATCHED
AND (TRIM(COALESCE(src.elt_columns_hash,'N/A')) != TRIM(COALESCE(tgt.elt_columns_hash,'N/A')) OR tgt.elt_delete_ind=1)
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  UPDATE
  SET
     tgt.bdid = COALESCE(src.bdid, '')
    ,tgt.elt_primary_key = COALESCE(src.elt_primary_key, '')
    ,tgt.file_date = COALESCE(src.file_date, '')
    ,tgt.level1brachid = COALESCE(src.level1brachid, '')
    ,tgt.level1rep = COALESCE(src.level1rep, '')
    ,tgt.level2branchid = COALESCE(src.level2branchid, '')
    ,tgt.level2rep = COALESCE(src.level2rep, '')
    ,tgt.level3branchid = COALESCE(src.level3branchid, '')
    ,tgt.level3rep = COALESCE(src.level3rep, '')
    ,tgt.line_number = COALESCE(src.line_number, '')
    ,tgt.repbranchid = COALESCE(src.repbranchid, '')
    ,tgt.repcode = COALESCE(src.repcode, '')
    ,tgt.statementdate = COALESCE(src.statementdate, '')
    ,tgt.elt_execution_date = src.elt_execution_date
    ,tgt.elt_source = src.elt_source
    ,tgt.elt_load_type = src.elt_load_type
    ,tgt.elt_delete_ind = src.elt_delete_ind
    ,tgt.elt_dml_type = src.elt_dml_type
    ,tgt.elt_reception_date = src.elt_reception_date
    ,tgt.elt_process_id = src.elt_process_id
    ,tgt.elt_firm = src.elt_firm
    ,tgt.elt_pipelinekey = src.elt_pipelinekey
    ,tgt.elt_columns_hash = src.elt_columns_hash

WHEN NOT MATCHED
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  INSERT
  (
     elt_integration_id
    ,bdid
    ,elt_primary_key
    ,file_date
    ,level1brachid
    ,level1rep
    ,level2branchid
    ,level2rep
    ,level3branchid
    ,level3rep
    ,line_number
    ,repbranchid
    ,repcode
    ,statementdate
    ,elt_execution_date
    ,elt_source
    ,elt_load_type
    ,elt_delete_ind
    ,elt_dml_type
    ,elt_reception_date
    ,elt_process_id
    ,elt_firm
    ,elt_pipelinekey
    ,elt_columns_hash
  )
  VALUES
  (
     src.elt_integration_id
    ,COALESCE(src.bdid, '')
    ,COALESCE(src.elt_primary_key, '')
    ,COALESCE(src.file_date, '')
    ,COALESCE(src.level1brachid, '')
    ,COALESCE(src.level1rep, '')
    ,COALESCE(src.level2branchid, '')
    ,COALESCE(src.level2rep, '')
    ,COALESCE(src.level3branchid, '')
    ,COALESCE(src.level3rep, '')
    ,COALESCE(src.line_number, '')
    ,COALESCE(src.repbranchid, '')
    ,COALESCE(src.repcode, '')
    ,COALESCE(src.statementdate, '')
    ,src.elt_execution_date
    ,src.elt_source
    ,src.elt_load_type
    ,src.elt_delete_ind
    ,src.elt_dml_type
    ,src.elt_reception_date
    ,src.elt_process_id
    ,src.elt_firm
    ,src.elt_pipelinekey
    ,src.elt_columns_hash
  );
`;

var soft_delete_command = "CALL ELT_STAGE.USP_SOFT_DELETE_RAW('CLIENT_REVENUE_RAW.SABOS_REPHIERARCHYTREE_VARIANT', 'CLIENT_REVENUE.REPHIERARCHYTREE');";

var usp_ingestion_command = "CALL ELT_STAGE.USP_INGESTION_RESULT('CLIENT_REVENUE.USP_SABOS_REPHIERARCHYTREE_MERGE', ARRAY_CONSTRUCT('"+fixQuote(sql_command)+"', '"+fixQuote(soft_delete_command)+"'));";


try {
    execObj = snowflake.execute({sqlText: usp_ingestion_command});
    if (execObj.getRowCount()>0) {
        execObj.next();
        return execObj.getColumnValueAsString(1);
        }
    return "Succeeded.";
    }
catch (err)  {
    return "Failed: " + err;
    }
$$;




CREATE OR REPLACE TASK CLIENT_REVENUE.SABOS_REPHIERARCHYTREE_MERGE_TASK
WAREHOUSE = DATA_LOAD_WH
SCHEDULE = '1 minute'
WHEN
SYSTEM$STREAM_HAS_DATA('CLIENT_REVENUE_RAW.SABOS_REPHIERARCHYTREE_VARIANT_STREAM')
AS
    CALL CLIENT_REVENUE.USP_SABOS_REPHIERARCHYTREE_MERGE();




CREATE OR REPLACE TABLE CLIENT_REVENUE.PRODUCTCATEGORY
(
   elt_integration_id VARCHAR NOT NULL
  ,bdid VARCHAR
  ,category VARCHAR
  ,description VARCHAR
  ,elt_primary_key VARCHAR
  ,file_date VARCHAR
  ,"group" VARCHAR
  ,line_number VARCHAR
  ,elt_execution_date VARCHAR
  ,elt_source VARCHAR
  ,elt_load_type VARCHAR
  ,elt_delete_ind VARCHAR
  ,elt_dml_type VARCHAR
  ,elt_reception_date VARCHAR
  ,elt_process_id VARCHAR
  ,elt_firm VARCHAR
  ,elt_pipelinekey VARCHAR
  ,elt_columns_hash VARCHAR
  ,CONSTRAINT PK_CLIENT_REVENUE_SABOS_PRODUCTCATEGORY PRIMARY KEY (elt_integration_id) NOT ENFORCED
);




CREATE OR REPLACE PROCEDURE CLIENT_REVENUE.USP_SABOS_PRODUCTCATEGORY_MERGE()
RETURNS STRING
LANGUAGE JAVASCRIPT
EXECUTE AS CALLER
AS 
$$

function fixQuote(sql) { return sql.replace(/'/g, "''") }
//'


var sql_command = 
`
MERGE INTO CLIENT_REVENUE.PRODUCTCATEGORY tgt
USING (
    SELECT * 
    FROM CLIENT_REVENUE_RAW.VW_SABOS_PRODUCTCATEGORY
) src
ON (
TRIM(COALESCE(src.elt_integration_id,'N/A')) = TRIM(COALESCE(tgt.elt_integration_id,'N/A'))
)
WHEN MATCHED
AND (TRIM(COALESCE(src.elt_columns_hash,'N/A')) != TRIM(COALESCE(tgt.elt_columns_hash,'N/A')) OR tgt.elt_delete_ind=1)
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  UPDATE
  SET
     tgt.bdid = COALESCE(src.bdid, '')
    ,tgt.category = COALESCE(src.category, '')
    ,tgt.description = COALESCE(src.description, '')
    ,tgt.elt_primary_key = COALESCE(src.elt_primary_key, '')
    ,tgt.file_date = COALESCE(src.file_date, '')
    ,tgt."group" = COALESCE(src."group", '')
    ,tgt.line_number = COALESCE(src.line_number, '')
    ,tgt.elt_execution_date = src.elt_execution_date
    ,tgt.elt_source = src.elt_source
    ,tgt.elt_load_type = src.elt_load_type
    ,tgt.elt_delete_ind = src.elt_delete_ind
    ,tgt.elt_dml_type = src.elt_dml_type
    ,tgt.elt_reception_date = src.elt_reception_date
    ,tgt.elt_process_id = src.elt_process_id
    ,tgt.elt_firm = src.elt_firm
    ,tgt.elt_pipelinekey = src.elt_pipelinekey
    ,tgt.elt_columns_hash = src.elt_columns_hash

WHEN NOT MATCHED
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  INSERT
  (
     elt_integration_id
    ,bdid
    ,category
    ,description
    ,elt_primary_key
    ,file_date
    ,"group"
    ,line_number
    ,elt_execution_date
    ,elt_source
    ,elt_load_type
    ,elt_delete_ind
    ,elt_dml_type
    ,elt_reception_date
    ,elt_process_id
    ,elt_firm
    ,elt_pipelinekey
    ,elt_columns_hash
  )
  VALUES
  (
     src.elt_integration_id
    ,COALESCE(src.bdid, '')
    ,COALESCE(src.category, '')
    ,COALESCE(src.description, '')
    ,COALESCE(src.elt_primary_key, '')
    ,COALESCE(src.file_date, '')
    ,COALESCE(src."group", '')
    ,COALESCE(src.line_number, '')
    ,src.elt_execution_date
    ,src.elt_source
    ,src.elt_load_type
    ,src.elt_delete_ind
    ,src.elt_dml_type
    ,src.elt_reception_date
    ,src.elt_process_id
    ,src.elt_firm
    ,src.elt_pipelinekey
    ,src.elt_columns_hash
  );
`;

var soft_delete_command = "CALL ELT_STAGE.USP_SOFT_DELETE_RAW('CLIENT_REVENUE_RAW.SABOS_PRODUCTCATEGORY_VARIANT', 'CLIENT_REVENUE.PRODUCTCATEGORY');";

var usp_ingestion_command = "CALL ELT_STAGE.USP_INGESTION_RESULT('CLIENT_REVENUE.USP_SABOS_PRODUCTCATEGORY_MERGE', ARRAY_CONSTRUCT('"+fixQuote(sql_command)+"', '"+fixQuote(soft_delete_command)+"'));";


try {
    execObj = snowflake.execute({sqlText: usp_ingestion_command});
    if (execObj.getRowCount()>0) {
        execObj.next();
        return execObj.getColumnValueAsString(1);
        }
    return "Succeeded.";
    }
catch (err)  {
    return "Failed: " + err;
    }
$$;




CREATE OR REPLACE TASK CLIENT_REVENUE.SABOS_PRODUCTCATEGORY_MERGE_TASK
WAREHOUSE = DATA_LOAD_WH
SCHEDULE = '1 minute'
WHEN
SYSTEM$STREAM_HAS_DATA('CLIENT_REVENUE_RAW.SABOS_PRODUCTCATEGORY_VARIANT_STREAM')
AS
    CALL CLIENT_REVENUE.USP_SABOS_PRODUCTCATEGORY_MERGE();




CREATE OR REPLACE TABLE CLIENT_REVENUE.PRODUCTGROUP
(
   elt_integration_id VARCHAR NOT NULL
  ,bdid VARCHAR
  ,description VARCHAR
  ,elt_primary_key VARCHAR
  ,file_date VARCHAR
  ,"group" VARCHAR
  ,line_number VARCHAR
  ,elt_execution_date VARCHAR
  ,elt_source VARCHAR
  ,elt_load_type VARCHAR
  ,elt_delete_ind VARCHAR
  ,elt_dml_type VARCHAR
  ,elt_reception_date VARCHAR
  ,elt_process_id VARCHAR
  ,elt_firm VARCHAR
  ,elt_pipelinekey VARCHAR
  ,elt_columns_hash VARCHAR
  ,CONSTRAINT PK_CLIENT_REVENUE_SABOS_PRODUCTGROUP PRIMARY KEY (elt_integration_id) NOT ENFORCED
);




CREATE OR REPLACE PROCEDURE CLIENT_REVENUE.USP_SABOS_PRODUCTGROUP_MERGE()
RETURNS STRING
LANGUAGE JAVASCRIPT
EXECUTE AS CALLER
AS 
$$

function fixQuote(sql) { return sql.replace(/'/g, "''") }
//'


var sql_command = 
`
MERGE INTO CLIENT_REVENUE.PRODUCTGROUP tgt
USING (
    SELECT * 
    FROM CLIENT_REVENUE_RAW.VW_SABOS_PRODUCTGROUP
) src
ON (
TRIM(COALESCE(src.elt_integration_id,'N/A')) = TRIM(COALESCE(tgt.elt_integration_id,'N/A'))
)
WHEN MATCHED
AND (TRIM(COALESCE(src.elt_columns_hash,'N/A')) != TRIM(COALESCE(tgt.elt_columns_hash,'N/A')) OR tgt.elt_delete_ind=1)
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  UPDATE
  SET
     tgt.bdid = COALESCE(src.bdid, '')
    ,tgt.description = COALESCE(src.description, '')
    ,tgt.elt_primary_key = COALESCE(src.elt_primary_key, '')
    ,tgt.file_date = COALESCE(src.file_date, '')
    ,tgt."group" = COALESCE(src."group", '')
    ,tgt.line_number = COALESCE(src.line_number, '')
    ,tgt.elt_execution_date = src.elt_execution_date
    ,tgt.elt_source = src.elt_source
    ,tgt.elt_load_type = src.elt_load_type
    ,tgt.elt_delete_ind = src.elt_delete_ind
    ,tgt.elt_dml_type = src.elt_dml_type
    ,tgt.elt_reception_date = src.elt_reception_date
    ,tgt.elt_process_id = src.elt_process_id
    ,tgt.elt_firm = src.elt_firm
    ,tgt.elt_pipelinekey = src.elt_pipelinekey
    ,tgt.elt_columns_hash = src.elt_columns_hash

WHEN NOT MATCHED
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  INSERT
  (
     elt_integration_id
    ,bdid
    ,description
    ,elt_primary_key
    ,file_date
    ,"group"
    ,line_number
    ,elt_execution_date
    ,elt_source
    ,elt_load_type
    ,elt_delete_ind
    ,elt_dml_type
    ,elt_reception_date
    ,elt_process_id
    ,elt_firm
    ,elt_pipelinekey
    ,elt_columns_hash
  )
  VALUES
  (
     src.elt_integration_id
    ,COALESCE(src.bdid, '')
    ,COALESCE(src.description, '')
    ,COALESCE(src.elt_primary_key, '')
    ,COALESCE(src.file_date, '')
    ,COALESCE(src."group", '')
    ,COALESCE(src.line_number, '')
    ,src.elt_execution_date
    ,src.elt_source
    ,src.elt_load_type
    ,src.elt_delete_ind
    ,src.elt_dml_type
    ,src.elt_reception_date
    ,src.elt_process_id
    ,src.elt_firm
    ,src.elt_pipelinekey
    ,src.elt_columns_hash
  );
`;

var soft_delete_command = "CALL ELT_STAGE.USP_SOFT_DELETE_RAW('CLIENT_REVENUE_RAW.SABOS_PRODUCTGROUP_VARIANT', 'CLIENT_REVENUE.PRODUCTGROUP');";

var usp_ingestion_command = "CALL ELT_STAGE.USP_INGESTION_RESULT('CLIENT_REVENUE.USP_SABOS_PRODUCTGROUP_MERGE', ARRAY_CONSTRUCT('"+fixQuote(sql_command)+"', '"+fixQuote(soft_delete_command)+"'));";


try {
    execObj = snowflake.execute({sqlText: usp_ingestion_command});
    if (execObj.getRowCount()>0) {
        execObj.next();
        return execObj.getColumnValueAsString(1);
        }
    return "Succeeded.";
    }
catch (err)  {
    return "Failed: " + err;
    }
$$;




CREATE OR REPLACE TASK CLIENT_REVENUE.SABOS_PRODUCTGROUP_MERGE_TASK
WAREHOUSE = DATA_LOAD_WH
SCHEDULE = '1 minute'
WHEN
SYSTEM$STREAM_HAS_DATA('CLIENT_REVENUE_RAW.SABOS_PRODUCTGROUP_VARIANT_STREAM')
AS
    CALL CLIENT_REVENUE.USP_SABOS_PRODUCTGROUP_MERGE();




CREATE OR REPLACE TABLE CLIENT_REVENUE.PRODUCTLICENSE
(
   elt_integration_id VARCHAR NOT NULL
  ,bdid VARCHAR
  ,elt_primary_key VARCHAR
  ,file_date VARCHAR
  ,license VARCHAR
  ,line_number VARCHAR
  ,productid VARCHAR
  ,elt_execution_date VARCHAR
  ,elt_source VARCHAR
  ,elt_load_type VARCHAR
  ,elt_delete_ind VARCHAR
  ,elt_dml_type VARCHAR
  ,elt_reception_date VARCHAR
  ,elt_process_id VARCHAR
  ,elt_firm VARCHAR
  ,elt_pipelinekey VARCHAR
  ,elt_columns_hash VARCHAR
  ,CONSTRAINT PK_CLIENT_REVENUE_SABOS_PRODUCTLICENSE PRIMARY KEY (elt_integration_id) NOT ENFORCED
);




CREATE OR REPLACE PROCEDURE CLIENT_REVENUE.USP_SABOS_PRODUCTLICENSE_MERGE()
RETURNS STRING
LANGUAGE JAVASCRIPT
EXECUTE AS CALLER
AS 
$$

function fixQuote(sql) { return sql.replace(/'/g, "''") }
//'


var sql_command = 
`
MERGE INTO CLIENT_REVENUE.PRODUCTLICENSE tgt
USING (
    SELECT * 
    FROM CLIENT_REVENUE_RAW.VW_SABOS_PRODUCTLICENSE
) src
ON (
TRIM(COALESCE(src.elt_integration_id,'N/A')) = TRIM(COALESCE(tgt.elt_integration_id,'N/A'))
)
WHEN MATCHED
AND (TRIM(COALESCE(src.elt_columns_hash,'N/A')) != TRIM(COALESCE(tgt.elt_columns_hash,'N/A')) OR tgt.elt_delete_ind=1)
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  UPDATE
  SET
     tgt.bdid = COALESCE(src.bdid, '')
    ,tgt.elt_primary_key = COALESCE(src.elt_primary_key, '')
    ,tgt.file_date = COALESCE(src.file_date, '')
    ,tgt.license = COALESCE(src.license, '')
    ,tgt.line_number = COALESCE(src.line_number, '')
    ,tgt.productid = COALESCE(src.productid, '')
    ,tgt.elt_execution_date = src.elt_execution_date
    ,tgt.elt_source = src.elt_source
    ,tgt.elt_load_type = src.elt_load_type
    ,tgt.elt_delete_ind = src.elt_delete_ind
    ,tgt.elt_dml_type = src.elt_dml_type
    ,tgt.elt_reception_date = src.elt_reception_date
    ,tgt.elt_process_id = src.elt_process_id
    ,tgt.elt_firm = src.elt_firm
    ,tgt.elt_pipelinekey = src.elt_pipelinekey
    ,tgt.elt_columns_hash = src.elt_columns_hash

WHEN NOT MATCHED
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  INSERT
  (
     elt_integration_id
    ,bdid
    ,elt_primary_key
    ,file_date
    ,license
    ,line_number
    ,productid
    ,elt_execution_date
    ,elt_source
    ,elt_load_type
    ,elt_delete_ind
    ,elt_dml_type
    ,elt_reception_date
    ,elt_process_id
    ,elt_firm
    ,elt_pipelinekey
    ,elt_columns_hash
  )
  VALUES
  (
     src.elt_integration_id
    ,COALESCE(src.bdid, '')
    ,COALESCE(src.elt_primary_key, '')
    ,COALESCE(src.file_date, '')
    ,COALESCE(src.license, '')
    ,COALESCE(src.line_number, '')
    ,COALESCE(src.productid, '')
    ,src.elt_execution_date
    ,src.elt_source
    ,src.elt_load_type
    ,src.elt_delete_ind
    ,src.elt_dml_type
    ,src.elt_reception_date
    ,src.elt_process_id
    ,src.elt_firm
    ,src.elt_pipelinekey
    ,src.elt_columns_hash
  );
`;

var soft_delete_command = "CALL ELT_STAGE.USP_SOFT_DELETE_RAW('CLIENT_REVENUE_RAW.SABOS_PRODUCTLICENSE_VARIANT', 'CLIENT_REVENUE.PRODUCTLICENSE');";

var usp_ingestion_command = "CALL ELT_STAGE.USP_INGESTION_RESULT('CLIENT_REVENUE.USP_SABOS_PRODUCTLICENSE_MERGE', ARRAY_CONSTRUCT('"+fixQuote(sql_command)+"', '"+fixQuote(soft_delete_command)+"'));";


try {
    execObj = snowflake.execute({sqlText: usp_ingestion_command});
    if (execObj.getRowCount()>0) {
        execObj.next();
        return execObj.getColumnValueAsString(1);
        }
    return "Succeeded.";
    }
catch (err)  {
    return "Failed: " + err;
    }
$$;




CREATE OR REPLACE TASK CLIENT_REVENUE.SABOS_PRODUCTLICENSE_MERGE_TASK
WAREHOUSE = DATA_LOAD_WH
SCHEDULE = '1 minute'
WHEN
SYSTEM$STREAM_HAS_DATA('CLIENT_REVENUE_RAW.SABOS_PRODUCTLICENSE_VARIANT_STREAM')
AS
    CALL CLIENT_REVENUE.USP_SABOS_PRODUCTLICENSE_MERGE();




CREATE OR REPLACE TABLE CLIENT_REVENUE.PRODUCT
(
   elt_integration_id VARCHAR NOT NULL
  ,bdid VARCHAR
  ,classcode VARCHAR
  ,closedate VARCHAR
  ,cusip VARCHAR
  ,elt_primary_key VARCHAR
  ,file_date VARCHAR
  ,isoffshore VARCHAR
  ,isproprietary VARCHAR
  ,isrestricted VARCHAR
  ,line_number VARCHAR
  ,opendate VARCHAR
  ,productcategory VARCHAR
  ,productcode VARCHAR
  ,productid VARCHAR
  ,productname VARCHAR
  ,ratingcode VARCHAR
  ,sponsorcode VARCHAR
  ,status VARCHAR
  ,symbol VARCHAR
  ,elt_execution_date VARCHAR
  ,elt_source VARCHAR
  ,elt_load_type VARCHAR
  ,elt_delete_ind VARCHAR
  ,elt_dml_type VARCHAR
  ,elt_reception_date VARCHAR
  ,elt_process_id VARCHAR
  ,elt_firm VARCHAR
  ,elt_pipelinekey VARCHAR
  ,elt_columns_hash VARCHAR
  ,CONSTRAINT PK_CLIENT_REVENUE_SABOS_PRODUCT PRIMARY KEY (elt_integration_id) NOT ENFORCED
);




CREATE OR REPLACE PROCEDURE CLIENT_REVENUE.USP_SABOS_PRODUCT_MERGE()
RETURNS STRING
LANGUAGE JAVASCRIPT
EXECUTE AS CALLER
AS 
$$

function fixQuote(sql) { return sql.replace(/'/g, "''") }
//'


var sql_command = 
`
MERGE INTO CLIENT_REVENUE.PRODUCT tgt
USING (
    SELECT * 
    FROM CLIENT_REVENUE_RAW.VW_SABOS_PRODUCT
) src
ON (
TRIM(COALESCE(src.elt_integration_id,'N/A')) = TRIM(COALESCE(tgt.elt_integration_id,'N/A'))
)
WHEN MATCHED
AND (TRIM(COALESCE(src.elt_columns_hash,'N/A')) != TRIM(COALESCE(tgt.elt_columns_hash,'N/A')) OR tgt.elt_delete_ind=1)
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  UPDATE
  SET
     tgt.bdid = COALESCE(src.bdid, '')
    ,tgt.classcode = COALESCE(src.classcode, '')
    ,tgt.closedate = COALESCE(src.closedate, '')
    ,tgt.cusip = COALESCE(src.cusip, '')
    ,tgt.elt_primary_key = COALESCE(src.elt_primary_key, '')
    ,tgt.file_date = COALESCE(src.file_date, '')
    ,tgt.isoffshore = COALESCE(src.isoffshore, '')
    ,tgt.isproprietary = COALESCE(src.isproprietary, '')
    ,tgt.isrestricted = COALESCE(src.isrestricted, '')
    ,tgt.line_number = COALESCE(src.line_number, '')
    ,tgt.opendate = COALESCE(src.opendate, '')
    ,tgt.productcategory = COALESCE(src.productcategory, '')
    ,tgt.productcode = COALESCE(src.productcode, '')
    ,tgt.productid = COALESCE(src.productid, '')
    ,tgt.productname = COALESCE(src.productname, '')
    ,tgt.ratingcode = COALESCE(src.ratingcode, '')
    ,tgt.sponsorcode = COALESCE(src.sponsorcode, '')
    ,tgt.status = COALESCE(src.status, '')
    ,tgt.symbol = COALESCE(src.symbol, '')
    ,tgt.elt_execution_date = src.elt_execution_date
    ,tgt.elt_source = src.elt_source
    ,tgt.elt_load_type = src.elt_load_type
    ,tgt.elt_delete_ind = src.elt_delete_ind
    ,tgt.elt_dml_type = src.elt_dml_type
    ,tgt.elt_reception_date = src.elt_reception_date
    ,tgt.elt_process_id = src.elt_process_id
    ,tgt.elt_firm = src.elt_firm
    ,tgt.elt_pipelinekey = src.elt_pipelinekey
    ,tgt.elt_columns_hash = src.elt_columns_hash

WHEN NOT MATCHED
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  INSERT
  (
     elt_integration_id
    ,bdid
    ,classcode
    ,closedate
    ,cusip
    ,elt_primary_key
    ,file_date
    ,isoffshore
    ,isproprietary
    ,isrestricted
    ,line_number
    ,opendate
    ,productcategory
    ,productcode
    ,productid
    ,productname
    ,ratingcode
    ,sponsorcode
    ,status
    ,symbol
    ,elt_execution_date
    ,elt_source
    ,elt_load_type
    ,elt_delete_ind
    ,elt_dml_type
    ,elt_reception_date
    ,elt_process_id
    ,elt_firm
    ,elt_pipelinekey
    ,elt_columns_hash
  )
  VALUES
  (
     src.elt_integration_id
    ,COALESCE(src.bdid, '')
    ,COALESCE(src.classcode, '')
    ,COALESCE(src.closedate, '')
    ,COALESCE(src.cusip, '')
    ,COALESCE(src.elt_primary_key, '')
    ,COALESCE(src.file_date, '')
    ,COALESCE(src.isoffshore, '')
    ,COALESCE(src.isproprietary, '')
    ,COALESCE(src.isrestricted, '')
    ,COALESCE(src.line_number, '')
    ,COALESCE(src.opendate, '')
    ,COALESCE(src.productcategory, '')
    ,COALESCE(src.productcode, '')
    ,COALESCE(src.productid, '')
    ,COALESCE(src.productname, '')
    ,COALESCE(src.ratingcode, '')
    ,COALESCE(src.sponsorcode, '')
    ,COALESCE(src.status, '')
    ,COALESCE(src.symbol, '')
    ,src.elt_execution_date
    ,src.elt_source
    ,src.elt_load_type
    ,src.elt_delete_ind
    ,src.elt_dml_type
    ,src.elt_reception_date
    ,src.elt_process_id
    ,src.elt_firm
    ,src.elt_pipelinekey
    ,src.elt_columns_hash
  );
`;

var soft_delete_command = "CALL ELT_STAGE.USP_SOFT_DELETE_RAW('CLIENT_REVENUE_RAW.SABOS_PRODUCT_VARIANT', 'CLIENT_REVENUE.PRODUCT');";

var usp_ingestion_command = "CALL ELT_STAGE.USP_INGESTION_RESULT('CLIENT_REVENUE.USP_SABOS_PRODUCT_MERGE', ARRAY_CONSTRUCT('"+fixQuote(sql_command)+"', '"+fixQuote(soft_delete_command)+"'));";


try {
    execObj = snowflake.execute({sqlText: usp_ingestion_command});
    if (execObj.getRowCount()>0) {
        execObj.next();
        return execObj.getColumnValueAsString(1);
        }
    return "Succeeded.";
    }
catch (err)  {
    return "Failed: " + err;
    }
$$;




CREATE OR REPLACE TASK CLIENT_REVENUE.SABOS_PRODUCT_MERGE_TASK
WAREHOUSE = DATA_LOAD_WH
SCHEDULE = '1 minute'
WHEN
SYSTEM$STREAM_HAS_DATA('CLIENT_REVENUE_RAW.SABOS_PRODUCT_VARIANT_STREAM')
AS
    CALL CLIENT_REVENUE.USP_SABOS_PRODUCT_MERGE();




CREATE OR REPLACE TABLE CLIENT_REVENUE.RATINGCODE
(
   elt_integration_id VARCHAR NOT NULL
  ,bdid VARCHAR
  ,code VARCHAR
  ,description VARCHAR
  ,elt_primary_key VARCHAR
  ,file_date VARCHAR
  ,line_number VARCHAR
  ,elt_execution_date VARCHAR
  ,elt_source VARCHAR
  ,elt_load_type VARCHAR
  ,elt_delete_ind VARCHAR
  ,elt_dml_type VARCHAR
  ,elt_reception_date VARCHAR
  ,elt_process_id VARCHAR
  ,elt_firm VARCHAR
  ,elt_pipelinekey VARCHAR
  ,elt_columns_hash VARCHAR
  ,CONSTRAINT PK_CLIENT_REVENUE_SABOS_RATINGCODE PRIMARY KEY (elt_integration_id) NOT ENFORCED
);




CREATE OR REPLACE PROCEDURE CLIENT_REVENUE.USP_SABOS_RATINGCODE_MERGE()
RETURNS STRING
LANGUAGE JAVASCRIPT
EXECUTE AS CALLER
AS 
$$

function fixQuote(sql) { return sql.replace(/'/g, "''") }
//'


var sql_command = 
`
MERGE INTO CLIENT_REVENUE.RATINGCODE tgt
USING (
    SELECT * 
    FROM CLIENT_REVENUE_RAW.VW_SABOS_RATINGCODE
) src
ON (
TRIM(COALESCE(src.elt_integration_id,'N/A')) = TRIM(COALESCE(tgt.elt_integration_id,'N/A'))
)
WHEN MATCHED
AND (TRIM(COALESCE(src.elt_columns_hash,'N/A')) != TRIM(COALESCE(tgt.elt_columns_hash,'N/A')) OR tgt.elt_delete_ind=1)
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  UPDATE
  SET
     tgt.bdid = COALESCE(src.bdid, '')
    ,tgt.code = COALESCE(src.code, '')
    ,tgt.description = COALESCE(src.description, '')
    ,tgt.elt_primary_key = COALESCE(src.elt_primary_key, '')
    ,tgt.file_date = COALESCE(src.file_date, '')
    ,tgt.line_number = COALESCE(src.line_number, '')
    ,tgt.elt_execution_date = src.elt_execution_date
    ,tgt.elt_source = src.elt_source
    ,tgt.elt_load_type = src.elt_load_type
    ,tgt.elt_delete_ind = src.elt_delete_ind
    ,tgt.elt_dml_type = src.elt_dml_type
    ,tgt.elt_reception_date = src.elt_reception_date
    ,tgt.elt_process_id = src.elt_process_id
    ,tgt.elt_firm = src.elt_firm
    ,tgt.elt_pipelinekey = src.elt_pipelinekey
    ,tgt.elt_columns_hash = src.elt_columns_hash

WHEN NOT MATCHED
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  INSERT
  (
     elt_integration_id
    ,bdid
    ,code
    ,description
    ,elt_primary_key
    ,file_date
    ,line_number
    ,elt_execution_date
    ,elt_source
    ,elt_load_type
    ,elt_delete_ind
    ,elt_dml_type
    ,elt_reception_date
    ,elt_process_id
    ,elt_firm
    ,elt_pipelinekey
    ,elt_columns_hash
  )
  VALUES
  (
     src.elt_integration_id
    ,COALESCE(src.bdid, '')
    ,COALESCE(src.code, '')
    ,COALESCE(src.description, '')
    ,COALESCE(src.elt_primary_key, '')
    ,COALESCE(src.file_date, '')
    ,COALESCE(src.line_number, '')
    ,src.elt_execution_date
    ,src.elt_source
    ,src.elt_load_type
    ,src.elt_delete_ind
    ,src.elt_dml_type
    ,src.elt_reception_date
    ,src.elt_process_id
    ,src.elt_firm
    ,src.elt_pipelinekey
    ,src.elt_columns_hash
  );
`;

var soft_delete_command = "CALL ELT_STAGE.USP_SOFT_DELETE_RAW('CLIENT_REVENUE_RAW.SABOS_RATINGCODE_VARIANT', 'CLIENT_REVENUE.RATINGCODE');";

var usp_ingestion_command = "CALL ELT_STAGE.USP_INGESTION_RESULT('CLIENT_REVENUE.USP_SABOS_RATINGCODE_MERGE', ARRAY_CONSTRUCT('"+fixQuote(sql_command)+"', '"+fixQuote(soft_delete_command)+"'));";


try {
    execObj = snowflake.execute({sqlText: usp_ingestion_command});
    if (execObj.getRowCount()>0) {
        execObj.next();
        return execObj.getColumnValueAsString(1);
        }
    return "Succeeded.";
    }
catch (err)  {
    return "Failed: " + err;
    }
$$;




CREATE OR REPLACE TASK CLIENT_REVENUE.SABOS_RATINGCODE_MERGE_TASK
WAREHOUSE = DATA_LOAD_WH
SCHEDULE = '1 minute'
WHEN
SYSTEM$STREAM_HAS_DATA('CLIENT_REVENUE_RAW.SABOS_RATINGCODE_VARIANT_STREAM')
AS
    CALL CLIENT_REVENUE.USP_SABOS_RATINGCODE_MERGE();




CREATE OR REPLACE TABLE CLIENT_REVENUE.REPHIERARCHY
(
   elt_integration_id VARCHAR NOT NULL
  ,agency VARCHAR
  ,bdid VARCHAR
  ,branchid VARCHAR
  ,cycledate VARCHAR
  ,elt_primary_key VARCHAR
  ,file_date VARCHAR
  ,hierachyrep VARCHAR
  ,line_number VARCHAR
  ,repcode VARCHAR
  ,rephierachylevl VARCHAR
  ,elt_execution_date VARCHAR
  ,elt_source VARCHAR
  ,elt_load_type VARCHAR
  ,elt_delete_ind VARCHAR
  ,elt_dml_type VARCHAR
  ,elt_reception_date VARCHAR
  ,elt_process_id VARCHAR
  ,elt_firm VARCHAR
  ,elt_pipelinekey VARCHAR
  ,elt_columns_hash VARCHAR
  ,CONSTRAINT PK_CLIENT_REVENUE_SABOS_REPHIERARCHY PRIMARY KEY (elt_integration_id) NOT ENFORCED
);




CREATE OR REPLACE PROCEDURE CLIENT_REVENUE.USP_SABOS_REPHIERARCHY_MERGE()
RETURNS STRING
LANGUAGE JAVASCRIPT
EXECUTE AS CALLER
AS 
$$

function fixQuote(sql) { return sql.replace(/'/g, "''") }
//'


var sql_command = 
`
MERGE INTO CLIENT_REVENUE.REPHIERARCHY tgt
USING (
    SELECT * 
    FROM CLIENT_REVENUE_RAW.VW_SABOS_REPHIERARCHY
) src
ON (
TRIM(COALESCE(src.elt_integration_id,'N/A')) = TRIM(COALESCE(tgt.elt_integration_id,'N/A'))
)
WHEN MATCHED
AND (TRIM(COALESCE(src.elt_columns_hash,'N/A')) != TRIM(COALESCE(tgt.elt_columns_hash,'N/A')) OR tgt.elt_delete_ind=1)
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  UPDATE
  SET
     tgt.agency = COALESCE(src.agency, '')
    ,tgt.bdid = COALESCE(src.bdid, '')
    ,tgt.branchid = COALESCE(src.branchid, '')
    ,tgt.cycledate = COALESCE(src.cycledate, '')
    ,tgt.elt_primary_key = COALESCE(src.elt_primary_key, '')
    ,tgt.file_date = COALESCE(src.file_date, '')
    ,tgt.hierachyrep = COALESCE(src.hierachyrep, '')
    ,tgt.line_number = COALESCE(src.line_number, '')
    ,tgt.repcode = COALESCE(src.repcode, '')
    ,tgt.rephierachylevl = COALESCE(src.rephierachylevl, '')
    ,tgt.elt_execution_date = src.elt_execution_date
    ,tgt.elt_source = src.elt_source
    ,tgt.elt_load_type = src.elt_load_type
    ,tgt.elt_delete_ind = src.elt_delete_ind
    ,tgt.elt_dml_type = src.elt_dml_type
    ,tgt.elt_reception_date = src.elt_reception_date
    ,tgt.elt_process_id = src.elt_process_id
    ,tgt.elt_firm = src.elt_firm
    ,tgt.elt_pipelinekey = src.elt_pipelinekey
    ,tgt.elt_columns_hash = src.elt_columns_hash

WHEN NOT MATCHED
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  INSERT
  (
     elt_integration_id
    ,agency
    ,bdid
    ,branchid
    ,cycledate
    ,elt_primary_key
    ,file_date
    ,hierachyrep
    ,line_number
    ,repcode
    ,rephierachylevl
    ,elt_execution_date
    ,elt_source
    ,elt_load_type
    ,elt_delete_ind
    ,elt_dml_type
    ,elt_reception_date
    ,elt_process_id
    ,elt_firm
    ,elt_pipelinekey
    ,elt_columns_hash
  )
  VALUES
  (
     src.elt_integration_id
    ,COALESCE(src.agency, '')
    ,COALESCE(src.bdid, '')
    ,COALESCE(src.branchid, '')
    ,COALESCE(src.cycledate, '')
    ,COALESCE(src.elt_primary_key, '')
    ,COALESCE(src.file_date, '')
    ,COALESCE(src.hierachyrep, '')
    ,COALESCE(src.line_number, '')
    ,COALESCE(src.repcode, '')
    ,COALESCE(src.rephierachylevl, '')
    ,src.elt_execution_date
    ,src.elt_source
    ,src.elt_load_type
    ,src.elt_delete_ind
    ,src.elt_dml_type
    ,src.elt_reception_date
    ,src.elt_process_id
    ,src.elt_firm
    ,src.elt_pipelinekey
    ,src.elt_columns_hash
  );
`;

var soft_delete_command = "CALL ELT_STAGE.USP_SOFT_DELETE_RAW('CLIENT_REVENUE_RAW.SABOS_REPHIERARCHY_VARIANT', 'CLIENT_REVENUE.REPHIERARCHY');";

var usp_ingestion_command = "CALL ELT_STAGE.USP_INGESTION_RESULT('CLIENT_REVENUE.USP_SABOS_REPHIERARCHY_MERGE', ARRAY_CONSTRUCT('"+fixQuote(sql_command)+"', '"+fixQuote(soft_delete_command)+"'));";


try {
    execObj = snowflake.execute({sqlText: usp_ingestion_command});
    if (execObj.getRowCount()>0) {
        execObj.next();
        return execObj.getColumnValueAsString(1);
        }
    return "Succeeded.";
    }
catch (err)  {
    return "Failed: " + err;
    }
$$;




CREATE OR REPLACE TASK CLIENT_REVENUE.SABOS_REPHIERARCHY_MERGE_TASK
WAREHOUSE = DATA_LOAD_WH
SCHEDULE = '1 minute'
WHEN
SYSTEM$STREAM_HAS_DATA('CLIENT_REVENUE_RAW.SABOS_REPHIERARCHY_VARIANT_STREAM')
AS
    CALL CLIENT_REVENUE.USP_SABOS_REPHIERARCHY_MERGE();




CREATE OR REPLACE TABLE CLIENT_REVENUE.REPHISTORY
(
   elt_integration_id VARCHAR NOT NULL
  ,"1099earnings" VARCHAR
  ,"1099flag" VARCHAR
  ,bankaccountnumber VARCHAR
  ,bankaccounttype VARCHAR
  ,bdid VARCHAR
  ,branchid VARCHAR
  ,closingbalance VARCHAR
  ,companyid VARCHAR
  ,debitamount VARCHAR
  ,debitdate VARCHAR
  ,deferredcompensation VARCHAR
  ,elt_primary_key VARCHAR
  ,file_date VARCHAR
  ,holdindicator VARCHAR
  ,holdreason VARCHAR
  ,lastamountinsurance VARCHAR
  ,lastamountsecurity VARCHAR
  ,lastchecknumber VARCHAR
  ,lastpaiddate VARCHAR
  ,level1ytdproduction VARCHAR
  ,level2ytdproduction VARCHAR
  ,level3ytdproduction VARCHAR
  ,line_number VARCHAR
  ,openingbalance VARCHAR
  ,paymenttype VARCHAR
  ,recognitionprogram VARCHAR
  ,recognitionstatus VARCHAR
  ,repcode VARCHAR
  ,repstatus VARCHAR
  ,statementdate VARCHAR
  ,elt_execution_date VARCHAR
  ,elt_source VARCHAR
  ,elt_load_type VARCHAR
  ,elt_delete_ind VARCHAR
  ,elt_dml_type VARCHAR
  ,elt_reception_date VARCHAR
  ,elt_process_id VARCHAR
  ,elt_firm VARCHAR
  ,elt_pipelinekey VARCHAR
  ,elt_columns_hash VARCHAR
  ,CONSTRAINT PK_CLIENT_REVENUE_SABOS_REPHISTORY PRIMARY KEY (elt_integration_id) NOT ENFORCED
);




CREATE OR REPLACE PROCEDURE CLIENT_REVENUE.USP_SABOS_REPHISTORY_MERGE()
RETURNS STRING
LANGUAGE JAVASCRIPT
EXECUTE AS CALLER
AS 
$$

function fixQuote(sql) { return sql.replace(/'/g, "''") }
//'


var sql_command = 
`
MERGE INTO CLIENT_REVENUE.REPHISTORY tgt
USING (
    SELECT * 
    FROM CLIENT_REVENUE_RAW.VW_SABOS_REPHISTORY
) src
ON (
TRIM(COALESCE(src.elt_integration_id,'N/A')) = TRIM(COALESCE(tgt.elt_integration_id,'N/A'))
)
WHEN MATCHED
AND (TRIM(COALESCE(src.elt_columns_hash,'N/A')) != TRIM(COALESCE(tgt.elt_columns_hash,'N/A')) OR tgt.elt_delete_ind=1)
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  UPDATE
  SET
     tgt."1099earnings" = COALESCE(src."1099earnings", '')
    ,tgt."1099flag" = COALESCE(src."1099flag", '')
    ,tgt.bankaccountnumber = COALESCE(src.bankaccountnumber, '')
    ,tgt.bankaccounttype = COALESCE(src.bankaccounttype, '')
    ,tgt.bdid = COALESCE(src.bdid, '')
    ,tgt.branchid = COALESCE(src.branchid, '')
    ,tgt.closingbalance = COALESCE(src.closingbalance, '')
    ,tgt.companyid = COALESCE(src.companyid, '')
    ,tgt.debitamount = COALESCE(src.debitamount, '')
    ,tgt.debitdate = COALESCE(src.debitdate, '')
    ,tgt.deferredcompensation = COALESCE(src.deferredcompensation, '')
    ,tgt.elt_primary_key = COALESCE(src.elt_primary_key, '')
    ,tgt.file_date = COALESCE(src.file_date, '')
    ,tgt.holdindicator = COALESCE(src.holdindicator, '')
    ,tgt.holdreason = COALESCE(src.holdreason, '')
    ,tgt.lastamountinsurance = COALESCE(src.lastamountinsurance, '')
    ,tgt.lastamountsecurity = COALESCE(src.lastamountsecurity, '')
    ,tgt.lastchecknumber = COALESCE(src.lastchecknumber, '')
    ,tgt.lastpaiddate = COALESCE(src.lastpaiddate, '')
    ,tgt.level1ytdproduction = COALESCE(src.level1ytdproduction, '')
    ,tgt.level2ytdproduction = COALESCE(src.level2ytdproduction, '')
    ,tgt.level3ytdproduction = COALESCE(src.level3ytdproduction, '')
    ,tgt.line_number = COALESCE(src.line_number, '')
    ,tgt.openingbalance = COALESCE(src.openingbalance, '')
    ,tgt.paymenttype = COALESCE(src.paymenttype, '')
    ,tgt.recognitionprogram = COALESCE(src.recognitionprogram, '')
    ,tgt.recognitionstatus = COALESCE(src.recognitionstatus, '')
    ,tgt.repcode = COALESCE(src.repcode, '')
    ,tgt.repstatus = COALESCE(src.repstatus, '')
    ,tgt.statementdate = COALESCE(src.statementdate, '')
    ,tgt.elt_execution_date = src.elt_execution_date
    ,tgt.elt_source = src.elt_source
    ,tgt.elt_load_type = src.elt_load_type
    ,tgt.elt_delete_ind = src.elt_delete_ind
    ,tgt.elt_dml_type = src.elt_dml_type
    ,tgt.elt_reception_date = src.elt_reception_date
    ,tgt.elt_process_id = src.elt_process_id
    ,tgt.elt_firm = src.elt_firm
    ,tgt.elt_pipelinekey = src.elt_pipelinekey
    ,tgt.elt_columns_hash = src.elt_columns_hash

WHEN NOT MATCHED
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  INSERT
  (
     elt_integration_id
    ,"1099earnings"
    ,"1099flag"
    ,bankaccountnumber
    ,bankaccounttype
    ,bdid
    ,branchid
    ,closingbalance
    ,companyid
    ,debitamount
    ,debitdate
    ,deferredcompensation
    ,elt_primary_key
    ,file_date
    ,holdindicator
    ,holdreason
    ,lastamountinsurance
    ,lastamountsecurity
    ,lastchecknumber
    ,lastpaiddate
    ,level1ytdproduction
    ,level2ytdproduction
    ,level3ytdproduction
    ,line_number
    ,openingbalance
    ,paymenttype
    ,recognitionprogram
    ,recognitionstatus
    ,repcode
    ,repstatus
    ,statementdate
    ,elt_execution_date
    ,elt_source
    ,elt_load_type
    ,elt_delete_ind
    ,elt_dml_type
    ,elt_reception_date
    ,elt_process_id
    ,elt_firm
    ,elt_pipelinekey
    ,elt_columns_hash
  )
  VALUES
  (
     src.elt_integration_id
    ,COALESCE(src."1099earnings", '')
    ,COALESCE(src."1099flag", '')
    ,COALESCE(src.bankaccountnumber, '')
    ,COALESCE(src.bankaccounttype, '')
    ,COALESCE(src.bdid, '')
    ,COALESCE(src.branchid, '')
    ,COALESCE(src.closingbalance, '')
    ,COALESCE(src.companyid, '')
    ,COALESCE(src.debitamount, '')
    ,COALESCE(src.debitdate, '')
    ,COALESCE(src.deferredcompensation, '')
    ,COALESCE(src.elt_primary_key, '')
    ,COALESCE(src.file_date, '')
    ,COALESCE(src.holdindicator, '')
    ,COALESCE(src.holdreason, '')
    ,COALESCE(src.lastamountinsurance, '')
    ,COALESCE(src.lastamountsecurity, '')
    ,COALESCE(src.lastchecknumber, '')
    ,COALESCE(src.lastpaiddate, '')
    ,COALESCE(src.level1ytdproduction, '')
    ,COALESCE(src.level2ytdproduction, '')
    ,COALESCE(src.level3ytdproduction, '')
    ,COALESCE(src.line_number, '')
    ,COALESCE(src.openingbalance, '')
    ,COALESCE(src.paymenttype, '')
    ,COALESCE(src.recognitionprogram, '')
    ,COALESCE(src.recognitionstatus, '')
    ,COALESCE(src.repcode, '')
    ,COALESCE(src.repstatus, '')
    ,COALESCE(src.statementdate, '')
    ,src.elt_execution_date
    ,src.elt_source
    ,src.elt_load_type
    ,src.elt_delete_ind
    ,src.elt_dml_type
    ,src.elt_reception_date
    ,src.elt_process_id
    ,src.elt_firm
    ,src.elt_pipelinekey
    ,src.elt_columns_hash
  );
`;

var soft_delete_command = "CALL ELT_STAGE.USP_SOFT_DELETE_RAW('CLIENT_REVENUE_RAW.SABOS_REPHISTORY_VARIANT', 'CLIENT_REVENUE.REPHISTORY');";

var usp_ingestion_command = "CALL ELT_STAGE.USP_INGESTION_RESULT('CLIENT_REVENUE.USP_SABOS_REPHISTORY_MERGE', ARRAY_CONSTRUCT('"+fixQuote(sql_command)+"', '"+fixQuote(soft_delete_command)+"'));";


try {
    execObj = snowflake.execute({sqlText: usp_ingestion_command});
    if (execObj.getRowCount()>0) {
        execObj.next();
        return execObj.getColumnValueAsString(1);
        }
    return "Succeeded.";
    }
catch (err)  {
    return "Failed: " + err;
    }
$$;




CREATE OR REPLACE TASK CLIENT_REVENUE.SABOS_REPHISTORY_MERGE_TASK
WAREHOUSE = DATA_LOAD_WH
SCHEDULE = '1 minute'
WHEN
SYSTEM$STREAM_HAS_DATA('CLIENT_REVENUE_RAW.SABOS_REPHISTORY_VARIANT_STREAM')
AS
    CALL CLIENT_REVENUE.USP_SABOS_REPHISTORY_MERGE();




CREATE OR REPLACE TABLE CLIENT_REVENUE.REPNAME
(
   elt_integration_id VARCHAR NOT NULL
  ,bdid VARCHAR
  ,crdnumber VARCHAR
  ,elt_primary_key VARCHAR
  ,file_date VARCHAR
  ,firstname VARCHAR
  ,lastname VARCHAR
  ,line_number VARCHAR
  ,middlename VARCHAR
  ,repcode VARCHAR
  ,repfullname VARCHAR
  ,src_data_bdid VARCHAR
  ,ssn VARCHAR
  ,elt_execution_date VARCHAR
  ,elt_source VARCHAR
  ,elt_load_type VARCHAR
  ,elt_delete_ind VARCHAR
  ,elt_dml_type VARCHAR
  ,elt_reception_date VARCHAR
  ,elt_process_id VARCHAR
  ,elt_firm VARCHAR
  ,elt_pipelinekey VARCHAR
  ,elt_columns_hash VARCHAR
  ,CONSTRAINT PK_CLIENT_REVENUE_SABOS_REPNAME PRIMARY KEY (elt_integration_id) NOT ENFORCED
);




CREATE OR REPLACE PROCEDURE CLIENT_REVENUE.USP_SABOS_REPNAME_MERGE()
RETURNS STRING
LANGUAGE JAVASCRIPT
EXECUTE AS CALLER
AS 
$$

function fixQuote(sql) { return sql.replace(/'/g, "''") }
//'


var sql_command = 
`
MERGE INTO CLIENT_REVENUE.REPNAME tgt
USING (
    SELECT * 
    FROM CLIENT_REVENUE_RAW.VW_SABOS_REPNAME
) src
ON (
TRIM(COALESCE(src.elt_integration_id,'N/A')) = TRIM(COALESCE(tgt.elt_integration_id,'N/A'))
)
WHEN MATCHED
AND (TRIM(COALESCE(src.elt_columns_hash,'N/A')) != TRIM(COALESCE(tgt.elt_columns_hash,'N/A')) OR tgt.elt_delete_ind=1)
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  UPDATE
  SET
     tgt.bdid = COALESCE(src.bdid, '')
    ,tgt.crdnumber = COALESCE(src.crdnumber, '')
    ,tgt.elt_primary_key = COALESCE(src.elt_primary_key, '')
    ,tgt.file_date = COALESCE(src.file_date, '')
    ,tgt.firstname = COALESCE(src.firstname, '')
    ,tgt.lastname = COALESCE(src.lastname, '')
    ,tgt.line_number = COALESCE(src.line_number, '')
    ,tgt.middlename = COALESCE(src.middlename, '')
    ,tgt.repcode = COALESCE(src.repcode, '')
    ,tgt.repfullname = COALESCE(src.repfullname, '')
    ,tgt.src_data_bdid = COALESCE(src.src_data_bdid, '')
    ,tgt.ssn = COALESCE(src.ssn, '')
    ,tgt.elt_execution_date = src.elt_execution_date
    ,tgt.elt_source = src.elt_source
    ,tgt.elt_load_type = src.elt_load_type
    ,tgt.elt_delete_ind = src.elt_delete_ind
    ,tgt.elt_dml_type = src.elt_dml_type
    ,tgt.elt_reception_date = src.elt_reception_date
    ,tgt.elt_process_id = src.elt_process_id
    ,tgt.elt_firm = src.elt_firm
    ,tgt.elt_pipelinekey = src.elt_pipelinekey
    ,tgt.elt_columns_hash = src.elt_columns_hash

WHEN NOT MATCHED
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  INSERT
  (
     elt_integration_id
    ,bdid
    ,crdnumber
    ,elt_primary_key
    ,file_date
    ,firstname
    ,lastname
    ,line_number
    ,middlename
    ,repcode
    ,repfullname
    ,src_data_bdid
    ,ssn
    ,elt_execution_date
    ,elt_source
    ,elt_load_type
    ,elt_delete_ind
    ,elt_dml_type
    ,elt_reception_date
    ,elt_process_id
    ,elt_firm
    ,elt_pipelinekey
    ,elt_columns_hash
  )
  VALUES
  (
     src.elt_integration_id
    ,COALESCE(src.bdid, '')
    ,COALESCE(src.crdnumber, '')
    ,COALESCE(src.elt_primary_key, '')
    ,COALESCE(src.file_date, '')
    ,COALESCE(src.firstname, '')
    ,COALESCE(src.lastname, '')
    ,COALESCE(src.line_number, '')
    ,COALESCE(src.middlename, '')
    ,COALESCE(src.repcode, '')
    ,COALESCE(src.repfullname, '')
    ,COALESCE(src.src_data_bdid, '')
    ,COALESCE(src.ssn, '')
    ,src.elt_execution_date
    ,src.elt_source
    ,src.elt_load_type
    ,src.elt_delete_ind
    ,src.elt_dml_type
    ,src.elt_reception_date
    ,src.elt_process_id
    ,src.elt_firm
    ,src.elt_pipelinekey
    ,src.elt_columns_hash
  );
`;

var soft_delete_command = "CALL ELT_STAGE.USP_SOFT_DELETE_RAW('CLIENT_REVENUE_RAW.SABOS_REPNAME_VARIANT', 'CLIENT_REVENUE.REPNAME');";

var usp_ingestion_command = "CALL ELT_STAGE.USP_INGESTION_RESULT('CLIENT_REVENUE.USP_SABOS_REPNAME_MERGE', ARRAY_CONSTRUCT('"+fixQuote(sql_command)+"', '"+fixQuote(soft_delete_command)+"'));";


try {
    execObj = snowflake.execute({sqlText: usp_ingestion_command});
    if (execObj.getRowCount()>0) {
        execObj.next();
        return execObj.getColumnValueAsString(1);
        }
    return "Succeeded.";
    }
catch (err)  {
    return "Failed: " + err;
    }
$$;




CREATE OR REPLACE TASK CLIENT_REVENUE.SABOS_REPNAME_MERGE_TASK
WAREHOUSE = DATA_LOAD_WH
SCHEDULE = '1 minute'
WHEN
SYSTEM$STREAM_HAS_DATA('CLIENT_REVENUE_RAW.SABOS_REPNAME_VARIANT_STREAM')
AS
    CALL CLIENT_REVENUE.USP_SABOS_REPNAME_MERGE();




CREATE OR REPLACE TABLE CLIENT_REVENUE.REVENUEPERIODSTAGE
(
   elt_integration_id VARCHAR NOT NULL
  ,bdid VARCHAR
  ,cycledate VARCHAR
  ,cyclenumber VARCHAR
  ,elt_primary_key VARCHAR
  ,file_date VARCHAR
  ,line_number VARCHAR
  ,paiddate VARCHAR
  ,paidfromdate VARCHAR
  ,paidthrudate VARCHAR
  ,elt_execution_date VARCHAR
  ,elt_source VARCHAR
  ,elt_load_type VARCHAR
  ,elt_delete_ind VARCHAR
  ,elt_dml_type VARCHAR
  ,elt_reception_date VARCHAR
  ,elt_process_id VARCHAR
  ,elt_firm VARCHAR
  ,elt_pipelinekey VARCHAR
  ,elt_columns_hash VARCHAR
  ,CONSTRAINT PK_CLIENT_REVENUE_SABOS_REVENUEPERIODSTAGE PRIMARY KEY (elt_integration_id) NOT ENFORCED
);




CREATE OR REPLACE PROCEDURE CLIENT_REVENUE.USP_SABOS_REVENUEPERIODSTAGE_MERGE()
RETURNS STRING
LANGUAGE JAVASCRIPT
EXECUTE AS CALLER
AS 
$$

function fixQuote(sql) { return sql.replace(/'/g, "''") }
//'


var sql_command = 
`
MERGE INTO CLIENT_REVENUE.REVENUEPERIODSTAGE tgt
USING (
    SELECT * 
    FROM CLIENT_REVENUE_RAW.VW_SABOS_REVENUEPERIODSTAGE
) src
ON (
TRIM(COALESCE(src.elt_integration_id,'N/A')) = TRIM(COALESCE(tgt.elt_integration_id,'N/A'))
)
WHEN MATCHED
AND (TRIM(COALESCE(src.elt_columns_hash,'N/A')) != TRIM(COALESCE(tgt.elt_columns_hash,'N/A')) OR tgt.elt_delete_ind=1)
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  UPDATE
  SET
     tgt.bdid = COALESCE(src.bdid, '')
    ,tgt.cycledate = COALESCE(src.cycledate, '')
    ,tgt.cyclenumber = COALESCE(src.cyclenumber, '')
    ,tgt.elt_primary_key = COALESCE(src.elt_primary_key, '')
    ,tgt.file_date = COALESCE(src.file_date, '')
    ,tgt.line_number = COALESCE(src.line_number, '')
    ,tgt.paiddate = COALESCE(src.paiddate, '')
    ,tgt.paidfromdate = COALESCE(src.paidfromdate, '')
    ,tgt.paidthrudate = COALESCE(src.paidthrudate, '')
    ,tgt.elt_execution_date = src.elt_execution_date
    ,tgt.elt_source = src.elt_source
    ,tgt.elt_load_type = src.elt_load_type
    ,tgt.elt_delete_ind = src.elt_delete_ind
    ,tgt.elt_dml_type = src.elt_dml_type
    ,tgt.elt_reception_date = src.elt_reception_date
    ,tgt.elt_process_id = src.elt_process_id
    ,tgt.elt_firm = src.elt_firm
    ,tgt.elt_pipelinekey = src.elt_pipelinekey
    ,tgt.elt_columns_hash = src.elt_columns_hash

WHEN NOT MATCHED
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  INSERT
  (
     elt_integration_id
    ,bdid
    ,cycledate
    ,cyclenumber
    ,elt_primary_key
    ,file_date
    ,line_number
    ,paiddate
    ,paidfromdate
    ,paidthrudate
    ,elt_execution_date
    ,elt_source
    ,elt_load_type
    ,elt_delete_ind
    ,elt_dml_type
    ,elt_reception_date
    ,elt_process_id
    ,elt_firm
    ,elt_pipelinekey
    ,elt_columns_hash
  )
  VALUES
  (
     src.elt_integration_id
    ,COALESCE(src.bdid, '')
    ,COALESCE(src.cycledate, '')
    ,COALESCE(src.cyclenumber, '')
    ,COALESCE(src.elt_primary_key, '')
    ,COALESCE(src.file_date, '')
    ,COALESCE(src.line_number, '')
    ,COALESCE(src.paiddate, '')
    ,COALESCE(src.paidfromdate, '')
    ,COALESCE(src.paidthrudate, '')
    ,src.elt_execution_date
    ,src.elt_source
    ,src.elt_load_type
    ,src.elt_delete_ind
    ,src.elt_dml_type
    ,src.elt_reception_date
    ,src.elt_process_id
    ,src.elt_firm
    ,src.elt_pipelinekey
    ,src.elt_columns_hash
  );
`;

var soft_delete_command = "CALL ELT_STAGE.USP_SOFT_DELETE_RAW('CLIENT_REVENUE_RAW.SABOS_REVENUEPERIODSTAGE_VARIANT', 'CLIENT_REVENUE.REVENUEPERIODSTAGE');";

var usp_ingestion_command = "CALL ELT_STAGE.USP_INGESTION_RESULT('CLIENT_REVENUE.USP_SABOS_REVENUEPERIODSTAGE_MERGE', ARRAY_CONSTRUCT('"+fixQuote(sql_command)+"', '"+fixQuote(soft_delete_command)+"'));";


try {
    execObj = snowflake.execute({sqlText: usp_ingestion_command});
    if (execObj.getRowCount()>0) {
        execObj.next();
        return execObj.getColumnValueAsString(1);
        }
    return "Succeeded.";
    }
catch (err)  {
    return "Failed: " + err;
    }
$$;




CREATE OR REPLACE TASK CLIENT_REVENUE.SABOS_REVENUEPERIODSTAGE_MERGE_TASK
WAREHOUSE = DATA_LOAD_WH
SCHEDULE = '1 minute'
WHEN
SYSTEM$STREAM_HAS_DATA('CLIENT_REVENUE_RAW.SABOS_REVENUEPERIODSTAGE_VARIANT_STREAM')
AS
    CALL CLIENT_REVENUE.USP_SABOS_REVENUEPERIODSTAGE_MERGE();




CREATE OR REPLACE TABLE CLIENT_REVENUE.SPONSORELITE
(
   elt_integration_id VARCHAR NOT NULL
  ,bdid VARCHAR
  ,effectiveenddate VARCHAR
  ,effectivestartdate VARCHAR
  ,elitecode VARCHAR
  ,elt_primary_key VARCHAR
  ,file_date VARCHAR
  ,line_number VARCHAR
  ,sponsorcode VARCHAR
  ,elt_execution_date VARCHAR
  ,elt_source VARCHAR
  ,elt_load_type VARCHAR
  ,elt_delete_ind VARCHAR
  ,elt_dml_type VARCHAR
  ,elt_reception_date VARCHAR
  ,elt_process_id VARCHAR
  ,elt_firm VARCHAR
  ,elt_pipelinekey VARCHAR
  ,elt_columns_hash VARCHAR
  ,CONSTRAINT PK_CLIENT_REVENUE_SABOS_SPONSORELITE PRIMARY KEY (elt_integration_id) NOT ENFORCED
);




CREATE OR REPLACE PROCEDURE CLIENT_REVENUE.USP_SABOS_SPONSORELITE_MERGE()
RETURNS STRING
LANGUAGE JAVASCRIPT
EXECUTE AS CALLER
AS 
$$

function fixQuote(sql) { return sql.replace(/'/g, "''") }
//'


var sql_command = 
`
MERGE INTO CLIENT_REVENUE.SPONSORELITE tgt
USING (
    SELECT * 
    FROM CLIENT_REVENUE_RAW.VW_SABOS_SPONSORELITE
) src
ON (
TRIM(COALESCE(src.elt_integration_id,'N/A')) = TRIM(COALESCE(tgt.elt_integration_id,'N/A'))
)
WHEN MATCHED
AND (TRIM(COALESCE(src.elt_columns_hash,'N/A')) != TRIM(COALESCE(tgt.elt_columns_hash,'N/A')) OR tgt.elt_delete_ind=1)
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  UPDATE
  SET
     tgt.bdid = COALESCE(src.bdid, '')
    ,tgt.effectiveenddate = COALESCE(src.effectiveenddate, '')
    ,tgt.effectivestartdate = COALESCE(src.effectivestartdate, '')
    ,tgt.elitecode = COALESCE(src.elitecode, '')
    ,tgt.elt_primary_key = COALESCE(src.elt_primary_key, '')
    ,tgt.file_date = COALESCE(src.file_date, '')
    ,tgt.line_number = COALESCE(src.line_number, '')
    ,tgt.sponsorcode = COALESCE(src.sponsorcode, '')
    ,tgt.elt_execution_date = src.elt_execution_date
    ,tgt.elt_source = src.elt_source
    ,tgt.elt_load_type = src.elt_load_type
    ,tgt.elt_delete_ind = src.elt_delete_ind
    ,tgt.elt_dml_type = src.elt_dml_type
    ,tgt.elt_reception_date = src.elt_reception_date
    ,tgt.elt_process_id = src.elt_process_id
    ,tgt.elt_firm = src.elt_firm
    ,tgt.elt_pipelinekey = src.elt_pipelinekey
    ,tgt.elt_columns_hash = src.elt_columns_hash

WHEN NOT MATCHED
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  INSERT
  (
     elt_integration_id
    ,bdid
    ,effectiveenddate
    ,effectivestartdate
    ,elitecode
    ,elt_primary_key
    ,file_date
    ,line_number
    ,sponsorcode
    ,elt_execution_date
    ,elt_source
    ,elt_load_type
    ,elt_delete_ind
    ,elt_dml_type
    ,elt_reception_date
    ,elt_process_id
    ,elt_firm
    ,elt_pipelinekey
    ,elt_columns_hash
  )
  VALUES
  (
     src.elt_integration_id
    ,COALESCE(src.bdid, '')
    ,COALESCE(src.effectiveenddate, '')
    ,COALESCE(src.effectivestartdate, '')
    ,COALESCE(src.elitecode, '')
    ,COALESCE(src.elt_primary_key, '')
    ,COALESCE(src.file_date, '')
    ,COALESCE(src.line_number, '')
    ,COALESCE(src.sponsorcode, '')
    ,src.elt_execution_date
    ,src.elt_source
    ,src.elt_load_type
    ,src.elt_delete_ind
    ,src.elt_dml_type
    ,src.elt_reception_date
    ,src.elt_process_id
    ,src.elt_firm
    ,src.elt_pipelinekey
    ,src.elt_columns_hash
  );
`;

var soft_delete_command = "CALL ELT_STAGE.USP_SOFT_DELETE_RAW('CLIENT_REVENUE_RAW.SABOS_SPONSORELITE_VARIANT', 'CLIENT_REVENUE.SPONSORELITE');";

var usp_ingestion_command = "CALL ELT_STAGE.USP_INGESTION_RESULT('CLIENT_REVENUE.USP_SABOS_SPONSORELITE_MERGE', ARRAY_CONSTRUCT('"+fixQuote(sql_command)+"', '"+fixQuote(soft_delete_command)+"'));";


try {
    execObj = snowflake.execute({sqlText: usp_ingestion_command});
    if (execObj.getRowCount()>0) {
        execObj.next();
        return execObj.getColumnValueAsString(1);
        }
    return "Succeeded.";
    }
catch (err)  {
    return "Failed: " + err;
    }
$$;




CREATE OR REPLACE TASK CLIENT_REVENUE.SABOS_SPONSORELITE_MERGE_TASK
WAREHOUSE = DATA_LOAD_WH
SCHEDULE = '1 minute'
WHEN
SYSTEM$STREAM_HAS_DATA('CLIENT_REVENUE_RAW.SABOS_SPONSORELITE_VARIANT_STREAM')
AS
    CALL CLIENT_REVENUE.USP_SABOS_SPONSORELITE_MERGE();




CREATE OR REPLACE TABLE CLIENT_REVENUE.SPONSOR
(
   elt_integration_id VARCHAR NOT NULL
  ,address1 VARCHAR
  ,address2 VARCHAR
  ,bdid VARCHAR
  ,city VARCHAR
  ,contactname VARCHAR
  ,elt_primary_key VARCHAR
  ,email VARCHAR
  ,file_date VARCHAR
  ,line_number VARCHAR
  ,name VARCHAR
  ,phone VARCHAR
  ,sponsorcode VARCHAR
  ,state VARCHAR
  ,zip VARCHAR
  ,elt_execution_date VARCHAR
  ,elt_source VARCHAR
  ,elt_load_type VARCHAR
  ,elt_delete_ind VARCHAR
  ,elt_dml_type VARCHAR
  ,elt_reception_date VARCHAR
  ,elt_process_id VARCHAR
  ,elt_firm VARCHAR
  ,elt_pipelinekey VARCHAR
  ,elt_columns_hash VARCHAR
  ,CONSTRAINT PK_CLIENT_REVENUE_SABOS_SPONSOR PRIMARY KEY (elt_integration_id) NOT ENFORCED
);




CREATE OR REPLACE PROCEDURE CLIENT_REVENUE.USP_SABOS_SPONSOR_MERGE()
RETURNS STRING
LANGUAGE JAVASCRIPT
EXECUTE AS CALLER
AS 
$$

function fixQuote(sql) { return sql.replace(/'/g, "''") }
//'


var sql_command = 
`
MERGE INTO CLIENT_REVENUE.SPONSOR tgt
USING (
    SELECT * 
    FROM CLIENT_REVENUE_RAW.VW_SABOS_SPONSOR
) src
ON (
TRIM(COALESCE(src.elt_integration_id,'N/A')) = TRIM(COALESCE(tgt.elt_integration_id,'N/A'))
)
WHEN MATCHED
AND (TRIM(COALESCE(src.elt_columns_hash,'N/A')) != TRIM(COALESCE(tgt.elt_columns_hash,'N/A')) OR tgt.elt_delete_ind=1)
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  UPDATE
  SET
     tgt.address1 = COALESCE(src.address1, '')
    ,tgt.address2 = COALESCE(src.address2, '')
    ,tgt.bdid = COALESCE(src.bdid, '')
    ,tgt.city = COALESCE(src.city, '')
    ,tgt.contactname = COALESCE(src.contactname, '')
    ,tgt.elt_primary_key = COALESCE(src.elt_primary_key, '')
    ,tgt.email = COALESCE(src.email, '')
    ,tgt.file_date = COALESCE(src.file_date, '')
    ,tgt.line_number = COALESCE(src.line_number, '')
    ,tgt.name = COALESCE(src.name, '')
    ,tgt.phone = COALESCE(src.phone, '')
    ,tgt.sponsorcode = COALESCE(src.sponsorcode, '')
    ,tgt.state = COALESCE(src.state, '')
    ,tgt.zip = COALESCE(src.zip, '')
    ,tgt.elt_execution_date = src.elt_execution_date
    ,tgt.elt_source = src.elt_source
    ,tgt.elt_load_type = src.elt_load_type
    ,tgt.elt_delete_ind = src.elt_delete_ind
    ,tgt.elt_dml_type = src.elt_dml_type
    ,tgt.elt_reception_date = src.elt_reception_date
    ,tgt.elt_process_id = src.elt_process_id
    ,tgt.elt_firm = src.elt_firm
    ,tgt.elt_pipelinekey = src.elt_pipelinekey
    ,tgt.elt_columns_hash = src.elt_columns_hash

WHEN NOT MATCHED
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  INSERT
  (
     elt_integration_id
    ,address1
    ,address2
    ,bdid
    ,city
    ,contactname
    ,elt_primary_key
    ,email
    ,file_date
    ,line_number
    ,name
    ,phone
    ,sponsorcode
    ,state
    ,zip
    ,elt_execution_date
    ,elt_source
    ,elt_load_type
    ,elt_delete_ind
    ,elt_dml_type
    ,elt_reception_date
    ,elt_process_id
    ,elt_firm
    ,elt_pipelinekey
    ,elt_columns_hash
  )
  VALUES
  (
     src.elt_integration_id
    ,COALESCE(src.address1, '')
    ,COALESCE(src.address2, '')
    ,COALESCE(src.bdid, '')
    ,COALESCE(src.city, '')
    ,COALESCE(src.contactname, '')
    ,COALESCE(src.elt_primary_key, '')
    ,COALESCE(src.email, '')
    ,COALESCE(src.file_date, '')
    ,COALESCE(src.line_number, '')
    ,COALESCE(src.name, '')
    ,COALESCE(src.phone, '')
    ,COALESCE(src.sponsorcode, '')
    ,COALESCE(src.state, '')
    ,COALESCE(src.zip, '')
    ,src.elt_execution_date
    ,src.elt_source
    ,src.elt_load_type
    ,src.elt_delete_ind
    ,src.elt_dml_type
    ,src.elt_reception_date
    ,src.elt_process_id
    ,src.elt_firm
    ,src.elt_pipelinekey
    ,src.elt_columns_hash
  );
`;

var soft_delete_command = "CALL ELT_STAGE.USP_SOFT_DELETE_RAW('CLIENT_REVENUE_RAW.SABOS_SPONSOR_VARIANT', 'CLIENT_REVENUE.SPONSOR');";

var usp_ingestion_command = "CALL ELT_STAGE.USP_INGESTION_RESULT('CLIENT_REVENUE.USP_SABOS_SPONSOR_MERGE', ARRAY_CONSTRUCT('"+fixQuote(sql_command)+"', '"+fixQuote(soft_delete_command)+"'));";


try {
    execObj = snowflake.execute({sqlText: usp_ingestion_command});
    if (execObj.getRowCount()>0) {
        execObj.next();
        return execObj.getColumnValueAsString(1);
        }
    return "Succeeded.";
    }
catch (err)  {
    return "Failed: " + err;
    }
$$;




CREATE OR REPLACE TASK CLIENT_REVENUE.SABOS_SPONSOR_MERGE_TASK
WAREHOUSE = DATA_LOAD_WH
SCHEDULE = '1 minute'
WHEN
SYSTEM$STREAM_HAS_DATA('CLIENT_REVENUE_RAW.SABOS_SPONSOR_VARIANT_STREAM')
AS
    CALL CLIENT_REVENUE.USP_SABOS_SPONSOR_MERGE();




CREATE OR REPLACE TABLE CLIENT_REVENUE.TOTALS
(
   elt_integration_id VARCHAR NOT NULL
  ,bdid VARCHAR
  ,elt_primary_key VARCHAR
  ,file_date VARCHAR
  ,line_number VARCHAR
  ,statementdate VARCHAR
  ,totaladj VARCHAR
  ,totaladjdtl VARCHAR
  ,totaldebit VARCHAR
  ,totalinsurance VARCHAR
  ,totalrep_1099 VARCHAR
  ,totalrepbeginbal VARCHAR
  ,totalrependbal VARCHAR
  ,totalsecurity VARCHAR
  ,totaltxndtl VARCHAR
  ,totaltxngdc VARCHAR
  ,totaltxngdcratec VARCHAR
  ,totaltxninvest VARCHAR
  ,elt_execution_date VARCHAR
  ,elt_source VARCHAR
  ,elt_load_type VARCHAR
  ,elt_delete_ind VARCHAR
  ,elt_dml_type VARCHAR
  ,elt_reception_date VARCHAR
  ,elt_process_id VARCHAR
  ,elt_firm VARCHAR
  ,elt_pipelinekey VARCHAR
  ,elt_columns_hash VARCHAR
  ,CONSTRAINT PK_CLIENT_REVENUE_SABOS_TOTALS PRIMARY KEY (elt_integration_id) NOT ENFORCED
);




CREATE OR REPLACE PROCEDURE CLIENT_REVENUE.USP_SABOS_TOTALS_MERGE()
RETURNS STRING
LANGUAGE JAVASCRIPT
EXECUTE AS CALLER
AS 
$$

function fixQuote(sql) { return sql.replace(/'/g, "''") }
//'


var sql_command = 
`
MERGE INTO CLIENT_REVENUE.TOTALS tgt
USING (
    SELECT * 
    FROM CLIENT_REVENUE_RAW.VW_SABOS_TOTALS
) src
ON (
TRIM(COALESCE(src.elt_integration_id,'N/A')) = TRIM(COALESCE(tgt.elt_integration_id,'N/A'))
)
WHEN MATCHED
AND (TRIM(COALESCE(src.elt_columns_hash,'N/A')) != TRIM(COALESCE(tgt.elt_columns_hash,'N/A')) OR tgt.elt_delete_ind=1)
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  UPDATE
  SET
     tgt.bdid = COALESCE(src.bdid, '')
    ,tgt.elt_primary_key = COALESCE(src.elt_primary_key, '')
    ,tgt.file_date = COALESCE(src.file_date, '')
    ,tgt.line_number = COALESCE(src.line_number, '')
    ,tgt.statementdate = COALESCE(src.statementdate, '')
    ,tgt.totaladj = COALESCE(src.totaladj, '')
    ,tgt.totaladjdtl = COALESCE(src.totaladjdtl, '')
    ,tgt.totaldebit = COALESCE(src.totaldebit, '')
    ,tgt.totalinsurance = COALESCE(src.totalinsurance, '')
    ,tgt.totalrep_1099 = COALESCE(src.totalrep_1099, '')
    ,tgt.totalrepbeginbal = COALESCE(src.totalrepbeginbal, '')
    ,tgt.totalrependbal = COALESCE(src.totalrependbal, '')
    ,tgt.totalsecurity = COALESCE(src.totalsecurity, '')
    ,tgt.totaltxndtl = COALESCE(src.totaltxndtl, '')
    ,tgt.totaltxngdc = COALESCE(src.totaltxngdc, '')
    ,tgt.totaltxngdcratec = COALESCE(src.totaltxngdcratec, '')
    ,tgt.totaltxninvest = COALESCE(src.totaltxninvest, '')
    ,tgt.elt_execution_date = src.elt_execution_date
    ,tgt.elt_source = src.elt_source
    ,tgt.elt_load_type = src.elt_load_type
    ,tgt.elt_delete_ind = src.elt_delete_ind
    ,tgt.elt_dml_type = src.elt_dml_type
    ,tgt.elt_reception_date = src.elt_reception_date
    ,tgt.elt_process_id = src.elt_process_id
    ,tgt.elt_firm = src.elt_firm
    ,tgt.elt_pipelinekey = src.elt_pipelinekey
    ,tgt.elt_columns_hash = src.elt_columns_hash

WHEN NOT MATCHED
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  INSERT
  (
     elt_integration_id
    ,bdid
    ,elt_primary_key
    ,file_date
    ,line_number
    ,statementdate
    ,totaladj
    ,totaladjdtl
    ,totaldebit
    ,totalinsurance
    ,totalrep_1099
    ,totalrepbeginbal
    ,totalrependbal
    ,totalsecurity
    ,totaltxndtl
    ,totaltxngdc
    ,totaltxngdcratec
    ,totaltxninvest
    ,elt_execution_date
    ,elt_source
    ,elt_load_type
    ,elt_delete_ind
    ,elt_dml_type
    ,elt_reception_date
    ,elt_process_id
    ,elt_firm
    ,elt_pipelinekey
    ,elt_columns_hash
  )
  VALUES
  (
     src.elt_integration_id
    ,COALESCE(src.bdid, '')
    ,COALESCE(src.elt_primary_key, '')
    ,COALESCE(src.file_date, '')
    ,COALESCE(src.line_number, '')
    ,COALESCE(src.statementdate, '')
    ,COALESCE(src.totaladj, '')
    ,COALESCE(src.totaladjdtl, '')
    ,COALESCE(src.totaldebit, '')
    ,COALESCE(src.totalinsurance, '')
    ,COALESCE(src.totalrep_1099, '')
    ,COALESCE(src.totalrepbeginbal, '')
    ,COALESCE(src.totalrependbal, '')
    ,COALESCE(src.totalsecurity, '')
    ,COALESCE(src.totaltxndtl, '')
    ,COALESCE(src.totaltxngdc, '')
    ,COALESCE(src.totaltxngdcratec, '')
    ,COALESCE(src.totaltxninvest, '')
    ,src.elt_execution_date
    ,src.elt_source
    ,src.elt_load_type
    ,src.elt_delete_ind
    ,src.elt_dml_type
    ,src.elt_reception_date
    ,src.elt_process_id
    ,src.elt_firm
    ,src.elt_pipelinekey
    ,src.elt_columns_hash
  );
`;

var soft_delete_command = "CALL ELT_STAGE.USP_SOFT_DELETE_RAW('CLIENT_REVENUE_RAW.SABOS_TOTALS_VARIANT', 'CLIENT_REVENUE.TOTALS');";

var usp_ingestion_command = "CALL ELT_STAGE.USP_INGESTION_RESULT('CLIENT_REVENUE.USP_SABOS_TOTALS_MERGE', ARRAY_CONSTRUCT('"+fixQuote(sql_command)+"', '"+fixQuote(soft_delete_command)+"'));";


try {
    execObj = snowflake.execute({sqlText: usp_ingestion_command});
    if (execObj.getRowCount()>0) {
        execObj.next();
        return execObj.getColumnValueAsString(1);
        }
    return "Succeeded.";
    }
catch (err)  {
    return "Failed: " + err;
    }
$$;




CREATE OR REPLACE TASK CLIENT_REVENUE.SABOS_TOTALS_MERGE_TASK
WAREHOUSE = DATA_LOAD_WH
SCHEDULE = '1 minute'
WHEN
SYSTEM$STREAM_HAS_DATA('CLIENT_REVENUE_RAW.SABOS_TOTALS_VARIANT_STREAM')
AS
    CALL CLIENT_REVENUE.USP_SABOS_TOTALS_MERGE();




CREATE OR REPLACE TABLE CLIENT_REVENUE.TRANSACTION
(
   elt_integration_id VARCHAR NOT NULL
  ,accountnumber VARCHAR
  ,bdid VARCHAR
  ,bonusgroup VARCHAR
  ,branchcode VARCHAR
  ,businessdevcode VARCHAR
  ,buysellindicator VARCHAR
  ,cancelcorrectcode VARCHAR
  ,cancellationdate VARCHAR
  ,cancellationreason VARCHAR
  ,cancelledbytransactionid VARCHAR
  ,clearinghouse VARCHAR
  ,clientssn VARCHAR
  ,company VARCHAR
  ,cycledate VARCHAR
  ,description VARCHAR
  ,elt_primary_key VARCHAR
  ,file_date VARCHAR
  ,gdcreceivableamount VARCHAR
  ,investmentamount VARCHAR
  ,line_number VARCHAR
  ,originalrepcode VARCHAR
  ,originaltransactionid VARCHAR
  ,productid VARCHAR
  ,repcode VARCHAR
  ,splittransactionnumber VARCHAR
  ,tradenumber VARCHAR
  ,transactiondate VARCHAR
  ,transactionid VARCHAR
  ,transactiontype VARCHAR
  ,elt_execution_date VARCHAR
  ,elt_source VARCHAR
  ,elt_load_type VARCHAR
  ,elt_delete_ind VARCHAR
  ,elt_dml_type VARCHAR
  ,elt_reception_date VARCHAR
  ,elt_process_id VARCHAR
  ,elt_firm VARCHAR
  ,elt_pipelinekey VARCHAR
  ,elt_columns_hash VARCHAR
  ,CONSTRAINT PK_CLIENT_REVENUE_SABOS_TRANSACTION PRIMARY KEY (elt_integration_id) NOT ENFORCED
);




CREATE OR REPLACE PROCEDURE CLIENT_REVENUE.USP_SABOS_TRANSACTION_MERGE()
RETURNS STRING
LANGUAGE JAVASCRIPT
EXECUTE AS CALLER
AS 
$$

function fixQuote(sql) { return sql.replace(/'/g, "''") }
//'


var sql_command = 
`
MERGE INTO CLIENT_REVENUE.TRANSACTION tgt
USING (
    SELECT * 
    FROM CLIENT_REVENUE_RAW.VW_SABOS_TRANSACTION
) src
ON (
TRIM(COALESCE(src.elt_integration_id,'N/A')) = TRIM(COALESCE(tgt.elt_integration_id,'N/A'))
)
WHEN MATCHED
AND (TRIM(COALESCE(src.elt_columns_hash,'N/A')) != TRIM(COALESCE(tgt.elt_columns_hash,'N/A')) OR tgt.elt_delete_ind=1)
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  UPDATE
  SET
     tgt.accountnumber = COALESCE(src.accountnumber, '')
    ,tgt.bdid = COALESCE(src.bdid, '')
    ,tgt.bonusgroup = COALESCE(src.bonusgroup, '')
    ,tgt.branchcode = COALESCE(src.branchcode, '')
    ,tgt.businessdevcode = COALESCE(src.businessdevcode, '')
    ,tgt.buysellindicator = COALESCE(src.buysellindicator, '')
    ,tgt.cancelcorrectcode = COALESCE(src.cancelcorrectcode, '')
    ,tgt.cancellationdate = COALESCE(src.cancellationdate, '')
    ,tgt.cancellationreason = COALESCE(src.cancellationreason, '')
    ,tgt.cancelledbytransactionid = COALESCE(src.cancelledbytransactionid, '')
    ,tgt.clearinghouse = COALESCE(src.clearinghouse, '')
    ,tgt.clientssn = COALESCE(src.clientssn, '')
    ,tgt.company = COALESCE(src.company, '')
    ,tgt.cycledate = COALESCE(src.cycledate, '')
    ,tgt.description = COALESCE(src.description, '')
    ,tgt.elt_primary_key = COALESCE(src.elt_primary_key, '')
    ,tgt.file_date = COALESCE(src.file_date, '')
    ,tgt.gdcreceivableamount = COALESCE(src.gdcreceivableamount, '')
    ,tgt.investmentamount = COALESCE(src.investmentamount, '')
    ,tgt.line_number = COALESCE(src.line_number, '')
    ,tgt.originalrepcode = COALESCE(src.originalrepcode, '')
    ,tgt.originaltransactionid = COALESCE(src.originaltransactionid, '')
    ,tgt.productid = COALESCE(src.productid, '')
    ,tgt.repcode = COALESCE(src.repcode, '')
    ,tgt.splittransactionnumber = COALESCE(src.splittransactionnumber, '')
    ,tgt.tradenumber = COALESCE(src.tradenumber, '')
    ,tgt.transactiondate = COALESCE(src.transactiondate, '')
    ,tgt.transactionid = COALESCE(src.transactionid, '')
    ,tgt.transactiontype = COALESCE(src.transactiontype, '')
    ,tgt.elt_execution_date = src.elt_execution_date
    ,tgt.elt_source = src.elt_source
    ,tgt.elt_load_type = src.elt_load_type
    ,tgt.elt_delete_ind = src.elt_delete_ind
    ,tgt.elt_dml_type = src.elt_dml_type
    ,tgt.elt_reception_date = src.elt_reception_date
    ,tgt.elt_process_id = src.elt_process_id
    ,tgt.elt_firm = src.elt_firm
    ,tgt.elt_pipelinekey = src.elt_pipelinekey
    ,tgt.elt_columns_hash = src.elt_columns_hash

WHEN NOT MATCHED
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  INSERT
  (
     elt_integration_id
    ,accountnumber
    ,bdid
    ,bonusgroup
    ,branchcode
    ,businessdevcode
    ,buysellindicator
    ,cancelcorrectcode
    ,cancellationdate
    ,cancellationreason
    ,cancelledbytransactionid
    ,clearinghouse
    ,clientssn
    ,company
    ,cycledate
    ,description
    ,elt_primary_key
    ,file_date
    ,gdcreceivableamount
    ,investmentamount
    ,line_number
    ,originalrepcode
    ,originaltransactionid
    ,productid
    ,repcode
    ,splittransactionnumber
    ,tradenumber
    ,transactiondate
    ,transactionid
    ,transactiontype
    ,elt_execution_date
    ,elt_source
    ,elt_load_type
    ,elt_delete_ind
    ,elt_dml_type
    ,elt_reception_date
    ,elt_process_id
    ,elt_firm
    ,elt_pipelinekey
    ,elt_columns_hash
  )
  VALUES
  (
     src.elt_integration_id
    ,COALESCE(src.accountnumber, '')
    ,COALESCE(src.bdid, '')
    ,COALESCE(src.bonusgroup, '')
    ,COALESCE(src.branchcode, '')
    ,COALESCE(src.businessdevcode, '')
    ,COALESCE(src.buysellindicator, '')
    ,COALESCE(src.cancelcorrectcode, '')
    ,COALESCE(src.cancellationdate, '')
    ,COALESCE(src.cancellationreason, '')
    ,COALESCE(src.cancelledbytransactionid, '')
    ,COALESCE(src.clearinghouse, '')
    ,COALESCE(src.clientssn, '')
    ,COALESCE(src.company, '')
    ,COALESCE(src.cycledate, '')
    ,COALESCE(src.description, '')
    ,COALESCE(src.elt_primary_key, '')
    ,COALESCE(src.file_date, '')
    ,COALESCE(src.gdcreceivableamount, '')
    ,COALESCE(src.investmentamount, '')
    ,COALESCE(src.line_number, '')
    ,COALESCE(src.originalrepcode, '')
    ,COALESCE(src.originaltransactionid, '')
    ,COALESCE(src.productid, '')
    ,COALESCE(src.repcode, '')
    ,COALESCE(src.splittransactionnumber, '')
    ,COALESCE(src.tradenumber, '')
    ,COALESCE(src.transactiondate, '')
    ,COALESCE(src.transactionid, '')
    ,COALESCE(src.transactiontype, '')
    ,src.elt_execution_date
    ,src.elt_source
    ,src.elt_load_type
    ,src.elt_delete_ind
    ,src.elt_dml_type
    ,src.elt_reception_date
    ,src.elt_process_id
    ,src.elt_firm
    ,src.elt_pipelinekey
    ,src.elt_columns_hash
  );
`;

var soft_delete_command = "CALL ELT_STAGE.USP_SOFT_DELETE_RAW('CLIENT_REVENUE_RAW.SABOS_TRANSACTION_VARIANT', 'CLIENT_REVENUE.TRANSACTION');";

var usp_ingestion_command = "CALL ELT_STAGE.USP_INGESTION_RESULT('CLIENT_REVENUE.USP_SABOS_TRANSACTION_MERGE', ARRAY_CONSTRUCT('"+fixQuote(sql_command)+"', '"+fixQuote(soft_delete_command)+"'));";


try {
    execObj = snowflake.execute({sqlText: usp_ingestion_command});
    if (execObj.getRowCount()>0) {
        execObj.next();
        return execObj.getColumnValueAsString(1);
        }
    return "Succeeded.";
    }
catch (err)  {
    return "Failed: " + err;
    }
$$;




CREATE OR REPLACE TASK CLIENT_REVENUE.SABOS_TRANSACTION_MERGE_TASK
WAREHOUSE = DATA_LOAD_WH
SCHEDULE = '1 minute'
WHEN
SYSTEM$STREAM_HAS_DATA('CLIENT_REVENUE_RAW.SABOS_TRANSACTION_VARIANT_STREAM')
AS
    CALL CLIENT_REVENUE.USP_SABOS_TRANSACTION_MERGE();




CREATE OR REPLACE TABLE CLIENT_REVENUE.TRANSACTIONDETAIL
(
   elt_integration_id VARCHAR NOT NULL
  ,amount VARCHAR
  ,bdid VARCHAR
  ,bonusgroup VARCHAR
  ,branchcode VARCHAR
  ,elt_primary_key VARCHAR
  ,file_date VARCHAR
  ,isforfeited VARCHAR
  ,line_number VARCHAR
  ,rate VARCHAR
  ,repcodeid VARCHAR
  ,transactiondetailtype VARCHAR
  ,transactionid VARCHAR
  ,elt_execution_date VARCHAR
  ,elt_source VARCHAR
  ,elt_load_type VARCHAR
  ,elt_delete_ind VARCHAR
  ,elt_dml_type VARCHAR
  ,elt_reception_date VARCHAR
  ,elt_process_id VARCHAR
  ,elt_firm VARCHAR
  ,elt_pipelinekey VARCHAR
  ,elt_columns_hash VARCHAR
  ,CONSTRAINT PK_CLIENT_REVENUE_SABOS_TRANSACTIONDETAIL PRIMARY KEY (elt_integration_id) NOT ENFORCED
);




CREATE OR REPLACE PROCEDURE CLIENT_REVENUE.USP_SABOS_TRANSACTIONDETAIL_MERGE()
RETURNS STRING
LANGUAGE JAVASCRIPT
EXECUTE AS CALLER
AS 
$$

function fixQuote(sql) { return sql.replace(/'/g, "''") }
//'


var sql_command = 
`
MERGE INTO CLIENT_REVENUE.TRANSACTIONDETAIL tgt
USING (
    SELECT * 
    FROM CLIENT_REVENUE_RAW.VW_SABOS_TRANSACTIONDETAIL
) src
ON (
TRIM(COALESCE(src.elt_integration_id,'N/A')) = TRIM(COALESCE(tgt.elt_integration_id,'N/A'))
)
WHEN MATCHED
AND (TRIM(COALESCE(src.elt_columns_hash,'N/A')) != TRIM(COALESCE(tgt.elt_columns_hash,'N/A')) OR tgt.elt_delete_ind=1)
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  UPDATE
  SET
     tgt.amount = COALESCE(src.amount, '')
    ,tgt.bdid = COALESCE(src.bdid, '')
    ,tgt.bonusgroup = COALESCE(src.bonusgroup, '')
    ,tgt.branchcode = COALESCE(src.branchcode, '')
    ,tgt.elt_primary_key = COALESCE(src.elt_primary_key, '')
    ,tgt.file_date = COALESCE(src.file_date, '')
    ,tgt.isforfeited = COALESCE(src.isforfeited, '')
    ,tgt.line_number = COALESCE(src.line_number, '')
    ,tgt.rate = COALESCE(src.rate, '')
    ,tgt.repcodeid = COALESCE(src.repcodeid, '')
    ,tgt.transactiondetailtype = COALESCE(src.transactiondetailtype, '')
    ,tgt.transactionid = COALESCE(src.transactionid, '')
    ,tgt.elt_execution_date = src.elt_execution_date
    ,tgt.elt_source = src.elt_source
    ,tgt.elt_load_type = src.elt_load_type
    ,tgt.elt_delete_ind = src.elt_delete_ind
    ,tgt.elt_dml_type = src.elt_dml_type
    ,tgt.elt_reception_date = src.elt_reception_date
    ,tgt.elt_process_id = src.elt_process_id
    ,tgt.elt_firm = src.elt_firm
    ,tgt.elt_pipelinekey = src.elt_pipelinekey
    ,tgt.elt_columns_hash = src.elt_columns_hash

WHEN NOT MATCHED
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  INSERT
  (
     elt_integration_id
    ,amount
    ,bdid
    ,bonusgroup
    ,branchcode
    ,elt_primary_key
    ,file_date
    ,isforfeited
    ,line_number
    ,rate
    ,repcodeid
    ,transactiondetailtype
    ,transactionid
    ,elt_execution_date
    ,elt_source
    ,elt_load_type
    ,elt_delete_ind
    ,elt_dml_type
    ,elt_reception_date
    ,elt_process_id
    ,elt_firm
    ,elt_pipelinekey
    ,elt_columns_hash
  )
  VALUES
  (
     src.elt_integration_id
    ,COALESCE(src.amount, '')
    ,COALESCE(src.bdid, '')
    ,COALESCE(src.bonusgroup, '')
    ,COALESCE(src.branchcode, '')
    ,COALESCE(src.elt_primary_key, '')
    ,COALESCE(src.file_date, '')
    ,COALESCE(src.isforfeited, '')
    ,COALESCE(src.line_number, '')
    ,COALESCE(src.rate, '')
    ,COALESCE(src.repcodeid, '')
    ,COALESCE(src.transactiondetailtype, '')
    ,COALESCE(src.transactionid, '')
    ,src.elt_execution_date
    ,src.elt_source
    ,src.elt_load_type
    ,src.elt_delete_ind
    ,src.elt_dml_type
    ,src.elt_reception_date
    ,src.elt_process_id
    ,src.elt_firm
    ,src.elt_pipelinekey
    ,src.elt_columns_hash
  );
`;

var soft_delete_command = "CALL ELT_STAGE.USP_SOFT_DELETE_RAW('CLIENT_REVENUE_RAW.SABOS_TRANSACTIONDETAIL_VARIANT', 'CLIENT_REVENUE.TRANSACTIONDETAIL');";

var usp_ingestion_command = "CALL ELT_STAGE.USP_INGESTION_RESULT('CLIENT_REVENUE.USP_SABOS_TRANSACTIONDETAIL_MERGE', ARRAY_CONSTRUCT('"+fixQuote(sql_command)+"', '"+fixQuote(soft_delete_command)+"'));";


try {
    execObj = snowflake.execute({sqlText: usp_ingestion_command});
    if (execObj.getRowCount()>0) {
        execObj.next();
        return execObj.getColumnValueAsString(1);
        }
    return "Succeeded.";
    }
catch (err)  {
    return "Failed: " + err;
    }
$$;




CREATE OR REPLACE TASK CLIENT_REVENUE.SABOS_TRANSACTIONDETAIL_MERGE_TASK
WAREHOUSE = DATA_LOAD_WH
SCHEDULE = '1 minute'
WHEN
SYSTEM$STREAM_HAS_DATA('CLIENT_REVENUE_RAW.SABOS_TRANSACTIONDETAIL_VARIANT_STREAM')
AS
    CALL CLIENT_REVENUE.USP_SABOS_TRANSACTIONDETAIL_MERGE();




CREATE OR REPLACE TABLE CLIENT_REVENUE.TRANSACTIONTYPE
(
   elt_integration_id VARCHAR NOT NULL
  ,bdid VARCHAR
  ,description VARCHAR
  ,elt_primary_key VARCHAR
  ,file_date VARCHAR
  ,line_number VARCHAR
  ,transactiontype VARCHAR
  ,elt_execution_date VARCHAR
  ,elt_source VARCHAR
  ,elt_load_type VARCHAR
  ,elt_delete_ind VARCHAR
  ,elt_dml_type VARCHAR
  ,elt_reception_date VARCHAR
  ,elt_process_id VARCHAR
  ,elt_firm VARCHAR
  ,elt_pipelinekey VARCHAR
  ,elt_columns_hash VARCHAR
  ,CONSTRAINT PK_CLIENT_REVENUE_SABOS_TRANSACTIONTYPE PRIMARY KEY (elt_integration_id) NOT ENFORCED
);




CREATE OR REPLACE PROCEDURE CLIENT_REVENUE.USP_SABOS_TRANSACTIONTYPE_MERGE()
RETURNS STRING
LANGUAGE JAVASCRIPT
EXECUTE AS CALLER
AS 
$$

function fixQuote(sql) { return sql.replace(/'/g, "''") }
//'


var sql_command = 
`
MERGE INTO CLIENT_REVENUE.TRANSACTIONTYPE tgt
USING (
    SELECT * 
    FROM CLIENT_REVENUE_RAW.VW_SABOS_TRANSACTIONTYPE
) src
ON (
TRIM(COALESCE(src.elt_integration_id,'N/A')) = TRIM(COALESCE(tgt.elt_integration_id,'N/A'))
)
WHEN MATCHED
AND (TRIM(COALESCE(src.elt_columns_hash,'N/A')) != TRIM(COALESCE(tgt.elt_columns_hash,'N/A')) OR tgt.elt_delete_ind=1)
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  UPDATE
  SET
     tgt.bdid = COALESCE(src.bdid, '')
    ,tgt.description = COALESCE(src.description, '')
    ,tgt.elt_primary_key = COALESCE(src.elt_primary_key, '')
    ,tgt.file_date = COALESCE(src.file_date, '')
    ,tgt.line_number = COALESCE(src.line_number, '')
    ,tgt.transactiontype = COALESCE(src.transactiontype, '')
    ,tgt.elt_execution_date = src.elt_execution_date
    ,tgt.elt_source = src.elt_source
    ,tgt.elt_load_type = src.elt_load_type
    ,tgt.elt_delete_ind = src.elt_delete_ind
    ,tgt.elt_dml_type = src.elt_dml_type
    ,tgt.elt_reception_date = src.elt_reception_date
    ,tgt.elt_process_id = src.elt_process_id
    ,tgt.elt_firm = src.elt_firm
    ,tgt.elt_pipelinekey = src.elt_pipelinekey
    ,tgt.elt_columns_hash = src.elt_columns_hash

WHEN NOT MATCHED
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  INSERT
  (
     elt_integration_id
    ,bdid
    ,description
    ,elt_primary_key
    ,file_date
    ,line_number
    ,transactiontype
    ,elt_execution_date
    ,elt_source
    ,elt_load_type
    ,elt_delete_ind
    ,elt_dml_type
    ,elt_reception_date
    ,elt_process_id
    ,elt_firm
    ,elt_pipelinekey
    ,elt_columns_hash
  )
  VALUES
  (
     src.elt_integration_id
    ,COALESCE(src.bdid, '')
    ,COALESCE(src.description, '')
    ,COALESCE(src.elt_primary_key, '')
    ,COALESCE(src.file_date, '')
    ,COALESCE(src.line_number, '')
    ,COALESCE(src.transactiontype, '')
    ,src.elt_execution_date
    ,src.elt_source
    ,src.elt_load_type
    ,src.elt_delete_ind
    ,src.elt_dml_type
    ,src.elt_reception_date
    ,src.elt_process_id
    ,src.elt_firm
    ,src.elt_pipelinekey
    ,src.elt_columns_hash
  );
`;

var soft_delete_command = "CALL ELT_STAGE.USP_SOFT_DELETE_RAW('CLIENT_REVENUE_RAW.SABOS_TRANSACTIONTYPE_VARIANT', 'CLIENT_REVENUE.TRANSACTIONTYPE');";

var usp_ingestion_command = "CALL ELT_STAGE.USP_INGESTION_RESULT('CLIENT_REVENUE.USP_SABOS_TRANSACTIONTYPE_MERGE', ARRAY_CONSTRUCT('"+fixQuote(sql_command)+"', '"+fixQuote(soft_delete_command)+"'));";


try {
    execObj = snowflake.execute({sqlText: usp_ingestion_command});
    if (execObj.getRowCount()>0) {
        execObj.next();
        return execObj.getColumnValueAsString(1);
        }
    return "Succeeded.";
    }
catch (err)  {
    return "Failed: " + err;
    }
$$;




CREATE OR REPLACE TASK CLIENT_REVENUE.SABOS_TRANSACTIONTYPE_MERGE_TASK
WAREHOUSE = DATA_LOAD_WH
SCHEDULE = '1 minute'
WHEN
SYSTEM$STREAM_HAS_DATA('CLIENT_REVENUE_RAW.SABOS_TRANSACTIONTYPE_VARIANT_STREAM')
AS
    CALL CLIENT_REVENUE.USP_SABOS_TRANSACTIONTYPE_MERGE();




CREATE OR REPLACE TABLE CLIENT_REVENUE.TRANSACTIONDETAILTYPE
(
   elt_integration_id VARCHAR NOT NULL
  ,bdid VARCHAR
  ,description VARCHAR
  ,elt_primary_key VARCHAR
  ,file_date VARCHAR
  ,line_number VARCHAR
  ,txndetailtype VARCHAR
  ,elt_execution_date VARCHAR
  ,elt_source VARCHAR
  ,elt_load_type VARCHAR
  ,elt_delete_ind VARCHAR
  ,elt_dml_type VARCHAR
  ,elt_reception_date VARCHAR
  ,elt_process_id VARCHAR
  ,elt_firm VARCHAR
  ,elt_pipelinekey VARCHAR
  ,elt_columns_hash VARCHAR
  ,CONSTRAINT PK_CLIENT_REVENUE_SABOS_TRANSACTIONDETAILTYPE PRIMARY KEY (elt_integration_id) NOT ENFORCED
);




CREATE OR REPLACE PROCEDURE CLIENT_REVENUE.USP_SABOS_TRANSACTIONDETAILTYPE_MERGE()
RETURNS STRING
LANGUAGE JAVASCRIPT
EXECUTE AS CALLER
AS 
$$

function fixQuote(sql) { return sql.replace(/'/g, "''") }
//'


var sql_command = 
`
MERGE INTO CLIENT_REVENUE.TRANSACTIONDETAILTYPE tgt
USING (
    SELECT * 
    FROM CLIENT_REVENUE_RAW.VW_SABOS_TRANSACTIONDETAILTYPE
) src
ON (
TRIM(COALESCE(src.elt_integration_id,'N/A')) = TRIM(COALESCE(tgt.elt_integration_id,'N/A'))
)
WHEN MATCHED
AND (TRIM(COALESCE(src.elt_columns_hash,'N/A')) != TRIM(COALESCE(tgt.elt_columns_hash,'N/A')) OR tgt.elt_delete_ind=1)
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  UPDATE
  SET
     tgt.bdid = COALESCE(src.bdid, '')
    ,tgt.description = COALESCE(src.description, '')
    ,tgt.elt_primary_key = COALESCE(src.elt_primary_key, '')
    ,tgt.file_date = COALESCE(src.file_date, '')
    ,tgt.line_number = COALESCE(src.line_number, '')
    ,tgt.txndetailtype = COALESCE(src.txndetailtype, '')
    ,tgt.elt_execution_date = src.elt_execution_date
    ,tgt.elt_source = src.elt_source
    ,tgt.elt_load_type = src.elt_load_type
    ,tgt.elt_delete_ind = src.elt_delete_ind
    ,tgt.elt_dml_type = src.elt_dml_type
    ,tgt.elt_reception_date = src.elt_reception_date
    ,tgt.elt_process_id = src.elt_process_id
    ,tgt.elt_firm = src.elt_firm
    ,tgt.elt_pipelinekey = src.elt_pipelinekey
    ,tgt.elt_columns_hash = src.elt_columns_hash

WHEN NOT MATCHED
AND TRIM(COALESCE(src.elt_integration_id,'N/A')) != 'N/A'
AND src.elt_stream_action = 'INSERT'
THEN
  INSERT
  (
     elt_integration_id
    ,bdid
    ,description
    ,elt_primary_key
    ,file_date
    ,line_number
    ,txndetailtype
    ,elt_execution_date
    ,elt_source
    ,elt_load_type
    ,elt_delete_ind
    ,elt_dml_type
    ,elt_reception_date
    ,elt_process_id
    ,elt_firm
    ,elt_pipelinekey
    ,elt_columns_hash
  )
  VALUES
  (
     src.elt_integration_id
    ,COALESCE(src.bdid, '')
    ,COALESCE(src.description, '')
    ,COALESCE(src.elt_primary_key, '')
    ,COALESCE(src.file_date, '')
    ,COALESCE(src.line_number, '')
    ,COALESCE(src.txndetailtype, '')
    ,src.elt_execution_date
    ,src.elt_source
    ,src.elt_load_type
    ,src.elt_delete_ind
    ,src.elt_dml_type
    ,src.elt_reception_date
    ,src.elt_process_id
    ,src.elt_firm
    ,src.elt_pipelinekey
    ,src.elt_columns_hash
  );
`;

var soft_delete_command = "CALL ELT_STAGE.USP_SOFT_DELETE_RAW('CLIENT_REVENUE_RAW.SABOS_TRANSACTIONDETAILTYPE_VARIANT', 'CLIENT_REVENUE.TRANSACTIONDETAILTYPE');";

var usp_ingestion_command = "CALL ELT_STAGE.USP_INGESTION_RESULT('CLIENT_REVENUE.USP_SABOS_TRANSACTIONDETAILTYPE_MERGE', ARRAY_CONSTRUCT('"+fixQuote(sql_command)+"', '"+fixQuote(soft_delete_command)+"'));";


try {
    execObj = snowflake.execute({sqlText: usp_ingestion_command});
    if (execObj.getRowCount()>0) {
        execObj.next();
        return execObj.getColumnValueAsString(1);
        }
    return "Succeeded.";
    }
catch (err)  {
    return "Failed: " + err;
    }
$$;




CREATE OR REPLACE TASK CLIENT_REVENUE.SABOS_TRANSACTIONDETAILTYPE_MERGE_TASK
WAREHOUSE = DATA_LOAD_WH
SCHEDULE = '1 minute'
WHEN
SYSTEM$STREAM_HAS_DATA('CLIENT_REVENUE_RAW.SABOS_TRANSACTIONDETAILTYPE_VARIANT_STREAM')
AS
    CALL CLIENT_REVENUE.USP_SABOS_TRANSACTIONDETAILTYPE_MERGE();



