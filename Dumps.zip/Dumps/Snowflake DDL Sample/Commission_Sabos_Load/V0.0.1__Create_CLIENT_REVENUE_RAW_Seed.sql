USE SCHEMA CLIENT_REVENUE_RAW;



CREATE OR REPLACE TRANSIENT TABLE CLIENT_REVENUE_RAW.SABOS_ADJUSTMENT_DETAIL_VARIANT
(
  SRC VARIANT
);




CREATE OR REPLACE STREAM CLIENT_REVENUE_RAW.SABOS_ADJUSTMENT_DETAIL_VARIANT_STREAM
ON TABLE CLIENT_REVENUE_RAW.SABOS_ADJUSTMENT_DETAIL_VARIANT APPEND_ONLY = TRUE;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_ADJUSTMENT_DETAIL_VARIANT_STREAM
AS
SELECT
   SRC:"adjustmentdetailtype"::string AS adjustmentdetailtype
  ,SRC:"adjustmentid"::string AS adjustmentid
  ,SRC:"amount"::string AS amount
  ,SRC:"bdid"::string AS bdid
  ,SRC:"bonusgroup"::string AS bonusgroup
  ,SRC:"branchcode"::string AS branchcode
  ,SRC:"elt_primary_key"::string AS elt_primary_key
  ,SRC:"file_date"::string AS file_date
  ,SRC:"line_number"::string AS line_number
  ,SRC:"rate"::string AS rate
  ,SRC:"repcode"::string AS repcode
  ,SRC:"elt_execution_date"::string AS elt_execution_date
  ,SRC:"elt_source"::string AS elt_source
  ,SRC:"elt_load_type"::string AS elt_load_type
  ,SRC:"elt_delete_ind"::string AS elt_delete_ind
  ,SRC:"elt_dml_type"::string AS elt_dml_type
  ,SRC:"elt_reception_date"::string AS elt_reception_date
  ,SRC:"elt_process_id"::string AS elt_process_id
  ,SRC:"elt_firm"::string AS elt_firm
  ,SRC:"elt_pipelinekey"::string AS elt_pipelinekey
  ,METADATA$ACTION AS elt_stream_action
FROM CLIENT_REVENUE_RAW.SABOS_ADJUSTMENT_DETAIL_VARIANT_STREAM;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_ADJUSTMENT_DETAIL
AS
SELECT
   elt_integration_id
  ,adjustmentdetailtype
  ,adjustmentid
  ,amount
  ,bdid
  ,bonusgroup
  ,branchcode
  ,elt_primary_key
  ,file_date
  ,line_number
  ,rate
  ,repcode
  ,elt_execution_date
  ,elt_source
  ,elt_load_type
  ,elt_delete_ind
  ,elt_dml_type
  ,elt_reception_date
  ,elt_process_id
  ,elt_firm
  ,elt_pipelinekey
  ,elt_columns_hash
  ,elt_stream_action
FROM
(
SELECT
   TRIM(CONCAT(COALESCE(src.elt_primary_key,'N/A'))) as elt_integration_id
  ,src.adjustmentdetailtype
  ,src.adjustmentid
  ,src.amount
  ,src.bdid
  ,src.bonusgroup
  ,src.branchcode
  ,src.elt_primary_key
  ,src.file_date
  ,src.line_number
  ,src.rate
  ,src.repcode
  ,src.elt_execution_date
  ,src.elt_source
  ,src.elt_load_type
  ,src.elt_delete_ind
  ,src.elt_dml_type
  ,src.elt_reception_date
  ,src.elt_process_id
  ,src.elt_firm
  ,src.elt_pipelinekey
  ,SHA2(CONCAT(
       COALESCE(src.adjustmentdetailtype,'N/A')
      ,COALESCE(src.adjustmentid,'N/A')
      ,COALESCE(src.amount,'N/A')
      ,COALESCE(src.bdid,'N/A')
      ,COALESCE(src.bonusgroup,'N/A')
      ,COALESCE(src.branchcode,'N/A')
      ,COALESCE(src.file_date,'N/A')
      ,COALESCE(src.line_number,'N/A')
      ,COALESCE(src.rate,'N/A')
      ,COALESCE(src.repcode,'N/A')
      )) AS elt_columns_hash
  ,src.elt_stream_action
  ,ROW_NUMBER() OVER (PARTITION BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action ORDER BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action, src.elt_execution_date DESC) AS top_slice
FROM CLIENT_REVENUE_RAW.VW_SABOS_ADJUSTMENT_DETAIL_VARIANT_STREAM src
)
WHERE top_slice = 1;




CREATE OR REPLACE TRANSIENT TABLE CLIENT_REVENUE_RAW.SABOS_ADJUSTMENT_REASONCODE_VARIANT
(
  SRC VARIANT
);




CREATE OR REPLACE STREAM CLIENT_REVENUE_RAW.SABOS_ADJUSTMENT_REASONCODE_VARIANT_STREAM
ON TABLE CLIENT_REVENUE_RAW.SABOS_ADJUSTMENT_REASONCODE_VARIANT APPEND_ONLY = TRUE;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_ADJUSTMENT_REASONCODE_VARIANT_STREAM
AS
SELECT
   SRC:"bdid"::string AS bdid
  ,SRC:"description"::string AS description
  ,SRC:"elt_primary_key"::string AS elt_primary_key
  ,SRC:"file_date"::string AS file_date
  ,SRC:"isdeferredcomp"::string AS isdeferredcomp
  ,SRC:"istaxable"::string AS istaxable
  ,SRC:"line_number"::string AS line_number
  ,SRC:"reasoncode"::string AS reasoncode
  ,SRC:"elt_execution_date"::string AS elt_execution_date
  ,SRC:"elt_source"::string AS elt_source
  ,SRC:"elt_load_type"::string AS elt_load_type
  ,SRC:"elt_delete_ind"::string AS elt_delete_ind
  ,SRC:"elt_dml_type"::string AS elt_dml_type
  ,SRC:"elt_reception_date"::string AS elt_reception_date
  ,SRC:"elt_process_id"::string AS elt_process_id
  ,SRC:"elt_firm"::string AS elt_firm
  ,SRC:"elt_pipelinekey"::string AS elt_pipelinekey
  ,METADATA$ACTION AS elt_stream_action
FROM CLIENT_REVENUE_RAW.SABOS_ADJUSTMENT_REASONCODE_VARIANT_STREAM;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_ADJUSTMENT_REASONCODE
AS
SELECT
   elt_integration_id
  ,bdid
  ,description
  ,elt_primary_key
  ,file_date
  ,isdeferredcomp
  ,istaxable
  ,line_number
  ,reasoncode
  ,elt_execution_date
  ,elt_source
  ,elt_load_type
  ,elt_delete_ind
  ,elt_dml_type
  ,elt_reception_date
  ,elt_process_id
  ,elt_firm
  ,elt_pipelinekey
  ,elt_columns_hash
  ,elt_stream_action
FROM
(
SELECT
   TRIM(CONCAT(COALESCE(src.elt_primary_key,'N/A'))) as elt_integration_id
  ,src.bdid
  ,src.description
  ,src.elt_primary_key
  ,src.file_date
  ,src.isdeferredcomp
  ,src.istaxable
  ,src.line_number
  ,src.reasoncode
  ,src.elt_execution_date
  ,src.elt_source
  ,src.elt_load_type
  ,src.elt_delete_ind
  ,src.elt_dml_type
  ,src.elt_reception_date
  ,src.elt_process_id
  ,src.elt_firm
  ,src.elt_pipelinekey
  ,SHA2(CONCAT(
       COALESCE(src.bdid,'N/A')
      ,COALESCE(src.description,'N/A')
      ,COALESCE(src.file_date,'N/A')
      ,COALESCE(src.isdeferredcomp,'N/A')
      ,COALESCE(src.istaxable,'N/A')
      ,COALESCE(src.line_number,'N/A')
      ,COALESCE(src.reasoncode,'N/A')
      )) AS elt_columns_hash
  ,src.elt_stream_action
  ,ROW_NUMBER() OVER (PARTITION BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action ORDER BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action, src.elt_execution_date DESC) AS top_slice
FROM CLIENT_REVENUE_RAW.VW_SABOS_ADJUSTMENT_REASONCODE_VARIANT_STREAM src
)
WHERE top_slice = 1;




CREATE OR REPLACE TRANSIENT TABLE CLIENT_REVENUE_RAW.SABOS_ADJUSTMENT_VARIANT
(
  SRC VARIANT
);




CREATE OR REPLACE STREAM CLIENT_REVENUE_RAW.SABOS_ADJUSTMENT_VARIANT_STREAM
ON TABLE CLIENT_REVENUE_RAW.SABOS_ADJUSTMENT_VARIANT APPEND_ONLY = TRUE;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_ADJUSTMENT_VARIANT_STREAM
AS
SELECT
   SRC:"accountnumber"::string AS accountnumber
  ,SRC:"adjustmentamount"::string AS adjustmentamount
  ,SRC:"adjustmentid"::string AS adjustmentid
  ,SRC:"adjustmenttype"::string AS adjustmenttype
  ,SRC:"bdid"::string AS bdid
  ,SRC:"bonusgroup"::string AS bonusgroup
  ,SRC:"branchcode"::string AS branchcode
  ,SRC:"businessdevcode"::string AS businessdevcode
  ,SRC:"buysellindicator"::string AS buysellindicator
  ,SRC:"cancelcorrectcode"::string AS cancelcorrectcode
  ,SRC:"cancellationdate"::string AS cancellationdate
  ,SRC:"cancellationreason"::string AS cancellationreason
  ,SRC:"cancelledbyadjustmentid"::string AS cancelledbyadjustmentid
  ,SRC:"clearinghouse"::string AS clearinghouse
  ,SRC:"clientssn"::string AS clientssn
  ,SRC:"company"::string AS company
  ,SRC:"cycledate"::string AS cycledate
  ,SRC:"description"::string AS description
  ,SRC:"elt_primary_key"::string AS elt_primary_key
  ,SRC:"file_date"::string AS file_date
  ,SRC:"line_number"::string AS line_number
  ,SRC:"originaladjustmentid"::string AS originaladjustmentid
  ,SRC:"originalrepcode"::string AS originalrepcode
  ,SRC:"reasoncode"::string AS reasoncode
  ,SRC:"repcode"::string AS repcode
  ,SRC:"splittransactionnumber"::string AS splittransactionnumber
  ,SRC:"tradenumber"::string AS tradenumber
  ,SRC:"transactiondate"::string AS transactiondate
  ,SRC:"transactionid"::string AS transactionid
  ,SRC:"elt_execution_date"::string AS elt_execution_date
  ,SRC:"elt_source"::string AS elt_source
  ,SRC:"elt_load_type"::string AS elt_load_type
  ,SRC:"elt_delete_ind"::string AS elt_delete_ind
  ,SRC:"elt_dml_type"::string AS elt_dml_type
  ,SRC:"elt_reception_date"::string AS elt_reception_date
  ,SRC:"elt_process_id"::string AS elt_process_id
  ,SRC:"elt_firm"::string AS elt_firm
  ,SRC:"elt_pipelinekey"::string AS elt_pipelinekey
  ,METADATA$ACTION AS elt_stream_action
FROM CLIENT_REVENUE_RAW.SABOS_ADJUSTMENT_VARIANT_STREAM;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_ADJUSTMENT
AS
SELECT
   elt_integration_id
  ,accountnumber
  ,adjustmentamount
  ,adjustmentid
  ,adjustmenttype
  ,bdid
  ,bonusgroup
  ,branchcode
  ,businessdevcode
  ,buysellindicator
  ,cancelcorrectcode
  ,cancellationdate
  ,cancellationreason
  ,cancelledbyadjustmentid
  ,clearinghouse
  ,clientssn
  ,company
  ,cycledate
  ,description
  ,elt_primary_key
  ,file_date
  ,line_number
  ,originaladjustmentid
  ,originalrepcode
  ,reasoncode
  ,repcode
  ,splittransactionnumber
  ,tradenumber
  ,transactiondate
  ,transactionid
  ,elt_execution_date
  ,elt_source
  ,elt_load_type
  ,elt_delete_ind
  ,elt_dml_type
  ,elt_reception_date
  ,elt_process_id
  ,elt_firm
  ,elt_pipelinekey
  ,elt_columns_hash
  ,elt_stream_action
FROM
(
SELECT
   TRIM(CONCAT(COALESCE(src.elt_primary_key,'N/A'))) as elt_integration_id
  ,src.accountnumber
  ,src.adjustmentamount
  ,src.adjustmentid
  ,src.adjustmenttype
  ,src.bdid
  ,src.bonusgroup
  ,src.branchcode
  ,src.businessdevcode
  ,src.buysellindicator
  ,src.cancelcorrectcode
  ,src.cancellationdate
  ,src.cancellationreason
  ,src.cancelledbyadjustmentid
  ,src.clearinghouse
  ,src.clientssn
  ,src.company
  ,src.cycledate
  ,src.description
  ,src.elt_primary_key
  ,src.file_date
  ,src.line_number
  ,src.originaladjustmentid
  ,src.originalrepcode
  ,src.reasoncode
  ,src.repcode
  ,src.splittransactionnumber
  ,src.tradenumber
  ,src.transactiondate
  ,src.transactionid
  ,src.elt_execution_date
  ,src.elt_source
  ,src.elt_load_type
  ,src.elt_delete_ind
  ,src.elt_dml_type
  ,src.elt_reception_date
  ,src.elt_process_id
  ,src.elt_firm
  ,src.elt_pipelinekey
  ,SHA2(CONCAT(
       COALESCE(src.accountnumber,'N/A')
      ,COALESCE(src.adjustmentamount,'N/A')
      ,COALESCE(src.adjustmentid,'N/A')
      ,COALESCE(src.adjustmenttype,'N/A')
      ,COALESCE(src.bdid,'N/A')
      ,COALESCE(src.bonusgroup,'N/A')
      ,COALESCE(src.branchcode,'N/A')
      ,COALESCE(src.businessdevcode,'N/A')
      ,COALESCE(src.buysellindicator,'N/A')
      ,COALESCE(src.cancelcorrectcode,'N/A')
      ,COALESCE(src.cancellationdate,'N/A')
      ,COALESCE(src.cancellationreason,'N/A')
      ,COALESCE(src.cancelledbyadjustmentid,'N/A')
      ,COALESCE(src.clearinghouse,'N/A')
      ,COALESCE(src.clientssn,'N/A')
      ,COALESCE(src.company,'N/A')
      ,COALESCE(src.cycledate,'N/A')
      ,COALESCE(src.description,'N/A')
      ,COALESCE(src.file_date,'N/A')
      ,COALESCE(src.line_number,'N/A')
      ,COALESCE(src.originaladjustmentid,'N/A')
      ,COALESCE(src.originalrepcode,'N/A')
      ,COALESCE(src.reasoncode,'N/A')
      ,COALESCE(src.repcode,'N/A')
      ,COALESCE(src.splittransactionnumber,'N/A')
      ,COALESCE(src.tradenumber,'N/A')
      ,COALESCE(src.transactiondate,'N/A')
      ,COALESCE(src.transactionid,'N/A')
      )) AS elt_columns_hash
  ,src.elt_stream_action
  ,ROW_NUMBER() OVER (PARTITION BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action ORDER BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action, src.elt_execution_date DESC) AS top_slice
FROM CLIENT_REVENUE_RAW.VW_SABOS_ADJUSTMENT_VARIANT_STREAM src
)
WHERE top_slice = 1;




CREATE OR REPLACE TRANSIENT TABLE CLIENT_REVENUE_RAW.SABOS_12B1TRAILS_VARIANT
(
  SRC VARIANT
);




CREATE OR REPLACE STREAM CLIENT_REVENUE_RAW.SABOS_12B1TRAILS_VARIANT_STREAM
ON TABLE CLIENT_REVENUE_RAW.SABOS_12B1TRAILS_VARIANT APPEND_ONLY = TRUE;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_12B1TRAILS_VARIANT_STREAM
AS
SELECT
   SRC:"amount"::string AS amount
  ,SRC:"bdid"::string AS bdid
  ,SRC:"bonusgroup"::string AS bonusgroup
  ,SRC:"branchcode"::string AS branchcode
  ,SRC:"clientaccountnumber"::string AS clientaccountnumber
  ,SRC:"clientname"::string AS clientname
  ,SRC:"cusip"::string AS cusip
  ,SRC:"dcpaid"::string AS dcpaid
  ,SRC:"elt_primary_key"::string AS elt_primary_key
  ,SRC:"file_date"::string AS file_date
  ,SRC:"isbrokerage"::string AS isbrokerage
  ,SRC:"line_number"::string AS line_number
  ,SRC:"productsponsorcode"::string AS productsponsorcode
  ,SRC:"repcode"::string AS repcode
  ,SRC:"sourcetransactionnumber"::string AS sourcetransactionnumber
  ,SRC:"statementdate"::string AS statementdate
  ,SRC:"transactiondate"::string AS transactiondate
  ,SRC:"transactiontype"::string AS transactiontype
  ,SRC:"elt_execution_date"::string AS elt_execution_date
  ,SRC:"elt_source"::string AS elt_source
  ,SRC:"elt_load_type"::string AS elt_load_type
  ,SRC:"elt_delete_ind"::string AS elt_delete_ind
  ,SRC:"elt_dml_type"::string AS elt_dml_type
  ,SRC:"elt_reception_date"::string AS elt_reception_date
  ,SRC:"elt_process_id"::string AS elt_process_id
  ,SRC:"elt_firm"::string AS elt_firm
  ,SRC:"elt_pipelinekey"::string AS elt_pipelinekey
  ,METADATA$ACTION AS elt_stream_action
FROM CLIENT_REVENUE_RAW.SABOS_12B1TRAILS_VARIANT_STREAM;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_12B1TRAILS
AS
SELECT
   elt_integration_id
  ,amount
  ,bdid
  ,bonusgroup
  ,branchcode
  ,clientaccountnumber
  ,clientname
  ,cusip
  ,dcpaid
  ,elt_primary_key
  ,file_date
  ,isbrokerage
  ,line_number
  ,productsponsorcode
  ,repcode
  ,sourcetransactionnumber
  ,statementdate
  ,transactiondate
  ,transactiontype
  ,elt_execution_date
  ,elt_source
  ,elt_load_type
  ,elt_delete_ind
  ,elt_dml_type
  ,elt_reception_date
  ,elt_process_id
  ,elt_firm
  ,elt_pipelinekey
  ,elt_columns_hash
  ,elt_stream_action
FROM
(
SELECT
   TRIM(CONCAT(COALESCE(src.elt_primary_key,'N/A'))) as elt_integration_id
  ,src.amount
  ,src.bdid
  ,src.bonusgroup
  ,src.branchcode
  ,src.clientaccountnumber
  ,src.clientname
  ,src.cusip
  ,src.dcpaid
  ,src.elt_primary_key
  ,src.file_date
  ,src.isbrokerage
  ,src.line_number
  ,src.productsponsorcode
  ,src.repcode
  ,src.sourcetransactionnumber
  ,src.statementdate
  ,src.transactiondate
  ,src.transactiontype
  ,src.elt_execution_date
  ,src.elt_source
  ,src.elt_load_type
  ,src.elt_delete_ind
  ,src.elt_dml_type
  ,src.elt_reception_date
  ,src.elt_process_id
  ,src.elt_firm
  ,src.elt_pipelinekey
  ,SHA2(CONCAT(
       COALESCE(src.amount,'N/A')
      ,COALESCE(src.bdid,'N/A')
      ,COALESCE(src.bonusgroup,'N/A')
      ,COALESCE(src.branchcode,'N/A')
      ,COALESCE(src.clientaccountnumber,'N/A')
      ,COALESCE(src.clientname,'N/A')
      ,COALESCE(src.cusip,'N/A')
      ,COALESCE(src.dcpaid,'N/A')
      ,COALESCE(src.file_date,'N/A')
      ,COALESCE(src.isbrokerage,'N/A')
      ,COALESCE(src.line_number,'N/A')
      ,COALESCE(src.productsponsorcode,'N/A')
      ,COALESCE(src.repcode,'N/A')
      ,COALESCE(src.sourcetransactionnumber,'N/A')
      ,COALESCE(src.statementdate,'N/A')
      ,COALESCE(src.transactiondate,'N/A')
      ,COALESCE(src.transactiontype,'N/A')
      )) AS elt_columns_hash
  ,src.elt_stream_action
  ,ROW_NUMBER() OVER (PARTITION BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action ORDER BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action, src.elt_execution_date DESC) AS top_slice
FROM CLIENT_REVENUE_RAW.VW_SABOS_12B1TRAILS_VARIANT_STREAM src
)
WHERE top_slice = 1;




CREATE OR REPLACE TRANSIENT TABLE CLIENT_REVENUE_RAW.SABOS_GROUPREPCODE_VARIANT
(
  SRC VARIANT
);




CREATE OR REPLACE STREAM CLIENT_REVENUE_RAW.SABOS_GROUPREPCODE_VARIANT_STREAM
ON TABLE CLIENT_REVENUE_RAW.SABOS_GROUPREPCODE_VARIANT APPEND_ONLY = TRUE;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_GROUPREPCODE_VARIANT_STREAM
AS
SELECT
   SRC:"bdid"::string AS bdid
  ,SRC:"elt_primary_key"::string AS elt_primary_key
  ,SRC:"file_date"::string AS file_date
  ,SRC:"groupid"::string AS groupid
  ,SRC:"groupname"::string AS groupname
  ,SRC:"line_number"::string AS line_number
  ,SRC:"productcategory"::string AS productcategory
  ,SRC:"repcode"::string AS repcode
  ,SRC:"splitpercent"::string AS splitpercent
  ,SRC:"elt_execution_date"::string AS elt_execution_date
  ,SRC:"elt_source"::string AS elt_source
  ,SRC:"elt_load_type"::string AS elt_load_type
  ,SRC:"elt_delete_ind"::string AS elt_delete_ind
  ,SRC:"elt_dml_type"::string AS elt_dml_type
  ,SRC:"elt_reception_date"::string AS elt_reception_date
  ,SRC:"elt_process_id"::string AS elt_process_id
  ,SRC:"elt_firm"::string AS elt_firm
  ,SRC:"elt_pipelinekey"::string AS elt_pipelinekey
  ,METADATA$ACTION AS elt_stream_action
FROM CLIENT_REVENUE_RAW.SABOS_GROUPREPCODE_VARIANT_STREAM;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_GROUPREPCODE
AS
SELECT
   elt_integration_id
  ,bdid
  ,elt_primary_key
  ,file_date
  ,groupid
  ,groupname
  ,line_number
  ,productcategory
  ,repcode
  ,splitpercent
  ,elt_execution_date
  ,elt_source
  ,elt_load_type
  ,elt_delete_ind
  ,elt_dml_type
  ,elt_reception_date
  ,elt_process_id
  ,elt_firm
  ,elt_pipelinekey
  ,elt_columns_hash
  ,elt_stream_action
FROM
(
SELECT
   TRIM(CONCAT(COALESCE(src.elt_primary_key,'N/A'))) as elt_integration_id
  ,src.bdid
  ,src.elt_primary_key
  ,src.file_date
  ,src.groupid
  ,src.groupname
  ,src.line_number
  ,src.productcategory
  ,src.repcode
  ,src.splitpercent
  ,src.elt_execution_date
  ,src.elt_source
  ,src.elt_load_type
  ,src.elt_delete_ind
  ,src.elt_dml_type
  ,src.elt_reception_date
  ,src.elt_process_id
  ,src.elt_firm
  ,src.elt_pipelinekey
  ,SHA2(CONCAT(
       COALESCE(src.bdid,'N/A')
      ,COALESCE(src.file_date,'N/A')
      ,COALESCE(src.groupid,'N/A')
      ,COALESCE(src.groupname,'N/A')
      ,COALESCE(src.line_number,'N/A')
      ,COALESCE(src.productcategory,'N/A')
      ,COALESCE(src.repcode,'N/A')
      ,COALESCE(src.splitpercent,'N/A')
      )) AS elt_columns_hash
  ,src.elt_stream_action
  ,ROW_NUMBER() OVER (PARTITION BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action ORDER BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action, src.elt_execution_date DESC) AS top_slice
FROM CLIENT_REVENUE_RAW.VW_SABOS_GROUPREPCODE_VARIANT_STREAM src
)
WHERE top_slice = 1;




CREATE OR REPLACE TRANSIENT TABLE CLIENT_REVENUE_RAW.SABOS_REPHIERARCHYTREE_VARIANT
(
  SRC VARIANT
);




CREATE OR REPLACE STREAM CLIENT_REVENUE_RAW.SABOS_REPHIERARCHYTREE_VARIANT_STREAM
ON TABLE CLIENT_REVENUE_RAW.SABOS_REPHIERARCHYTREE_VARIANT APPEND_ONLY = TRUE;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_REPHIERARCHYTREE_VARIANT_STREAM
AS
SELECT
   SRC:"bdid"::string AS bdid
  ,SRC:"elt_primary_key"::string AS elt_primary_key
  ,SRC:"file_date"::string AS file_date
  ,SRC:"level1brachid"::string AS level1brachid
  ,SRC:"level1rep"::string AS level1rep
  ,SRC:"level2branchid"::string AS level2branchid
  ,SRC:"level2rep"::string AS level2rep
  ,SRC:"level3branchid"::string AS level3branchid
  ,SRC:"level3rep"::string AS level3rep
  ,SRC:"line_number"::string AS line_number
  ,SRC:"repbranchid"::string AS repbranchid
  ,SRC:"repcode"::string AS repcode
  ,SRC:"statementdate"::string AS statementdate
  ,SRC:"elt_execution_date"::string AS elt_execution_date
  ,SRC:"elt_source"::string AS elt_source
  ,SRC:"elt_load_type"::string AS elt_load_type
  ,SRC:"elt_delete_ind"::string AS elt_delete_ind
  ,SRC:"elt_dml_type"::string AS elt_dml_type
  ,SRC:"elt_reception_date"::string AS elt_reception_date
  ,SRC:"elt_process_id"::string AS elt_process_id
  ,SRC:"elt_firm"::string AS elt_firm
  ,SRC:"elt_pipelinekey"::string AS elt_pipelinekey
  ,METADATA$ACTION AS elt_stream_action
FROM CLIENT_REVENUE_RAW.SABOS_REPHIERARCHYTREE_VARIANT_STREAM;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_REPHIERARCHYTREE
AS
SELECT
   elt_integration_id
  ,bdid
  ,elt_primary_key
  ,file_date
  ,level1brachid
  ,level1rep
  ,level2branchid
  ,level2rep
  ,level3branchid
  ,level3rep
  ,line_number
  ,repbranchid
  ,repcode
  ,statementdate
  ,elt_execution_date
  ,elt_source
  ,elt_load_type
  ,elt_delete_ind
  ,elt_dml_type
  ,elt_reception_date
  ,elt_process_id
  ,elt_firm
  ,elt_pipelinekey
  ,elt_columns_hash
  ,elt_stream_action
FROM
(
SELECT
   TRIM(CONCAT(COALESCE(src.elt_primary_key,'N/A'))) as elt_integration_id
  ,src.bdid
  ,src.elt_primary_key
  ,src.file_date
  ,src.level1brachid
  ,src.level1rep
  ,src.level2branchid
  ,src.level2rep
  ,src.level3branchid
  ,src.level3rep
  ,src.line_number
  ,src.repbranchid
  ,src.repcode
  ,src.statementdate
  ,src.elt_execution_date
  ,src.elt_source
  ,src.elt_load_type
  ,src.elt_delete_ind
  ,src.elt_dml_type
  ,src.elt_reception_date
  ,src.elt_process_id
  ,src.elt_firm
  ,src.elt_pipelinekey
  ,SHA2(CONCAT(
       COALESCE(src.bdid,'N/A')
      ,COALESCE(src.file_date,'N/A')
      ,COALESCE(src.level1brachid,'N/A')
      ,COALESCE(src.level1rep,'N/A')
      ,COALESCE(src.level2branchid,'N/A')
      ,COALESCE(src.level2rep,'N/A')
      ,COALESCE(src.level3branchid,'N/A')
      ,COALESCE(src.level3rep,'N/A')
      ,COALESCE(src.line_number,'N/A')
      ,COALESCE(src.repbranchid,'N/A')
      ,COALESCE(src.repcode,'N/A')
      ,COALESCE(src.statementdate,'N/A')
      )) AS elt_columns_hash
  ,src.elt_stream_action
  ,ROW_NUMBER() OVER (PARTITION BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action ORDER BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action, src.elt_execution_date DESC) AS top_slice
FROM CLIENT_REVENUE_RAW.VW_SABOS_REPHIERARCHYTREE_VARIANT_STREAM src
)
WHERE top_slice = 1;




CREATE OR REPLACE TRANSIENT TABLE CLIENT_REVENUE_RAW.SABOS_PRODUCTCATEGORY_VARIANT
(
  SRC VARIANT
);




CREATE OR REPLACE STREAM CLIENT_REVENUE_RAW.SABOS_PRODUCTCATEGORY_VARIANT_STREAM
ON TABLE CLIENT_REVENUE_RAW.SABOS_PRODUCTCATEGORY_VARIANT APPEND_ONLY = TRUE;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_PRODUCTCATEGORY_VARIANT_STREAM
AS
SELECT
   SRC:"bdid"::string AS bdid
  ,SRC:"category"::string AS category
  ,SRC:"description"::string AS description
  ,SRC:"elt_primary_key"::string AS elt_primary_key
  ,SRC:"file_date"::string AS file_date
  ,SRC:"group"::string AS "group"
  ,SRC:"line_number"::string AS line_number
  ,SRC:"elt_execution_date"::string AS elt_execution_date
  ,SRC:"elt_source"::string AS elt_source
  ,SRC:"elt_load_type"::string AS elt_load_type
  ,SRC:"elt_delete_ind"::string AS elt_delete_ind
  ,SRC:"elt_dml_type"::string AS elt_dml_type
  ,SRC:"elt_reception_date"::string AS elt_reception_date
  ,SRC:"elt_process_id"::string AS elt_process_id
  ,SRC:"elt_firm"::string AS elt_firm
  ,SRC:"elt_pipelinekey"::string AS elt_pipelinekey
  ,METADATA$ACTION AS elt_stream_action
FROM CLIENT_REVENUE_RAW.SABOS_PRODUCTCATEGORY_VARIANT_STREAM;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_PRODUCTCATEGORY
AS
SELECT
   elt_integration_id
  ,bdid
  ,category
  ,description
  ,elt_primary_key
  ,file_date
  ,"group"
  ,line_number
  ,elt_execution_date
  ,elt_source
  ,elt_load_type
  ,elt_delete_ind
  ,elt_dml_type
  ,elt_reception_date
  ,elt_process_id
  ,elt_firm
  ,elt_pipelinekey
  ,elt_columns_hash
  ,elt_stream_action
FROM
(
SELECT
   TRIM(CONCAT(COALESCE(src.elt_primary_key,'N/A'))) as elt_integration_id
  ,src.bdid
  ,src.category
  ,src.description
  ,src.elt_primary_key
  ,src.file_date
  ,src."group"
  ,src.line_number
  ,src.elt_execution_date
  ,src.elt_source
  ,src.elt_load_type
  ,src.elt_delete_ind
  ,src.elt_dml_type
  ,src.elt_reception_date
  ,src.elt_process_id
  ,src.elt_firm
  ,src.elt_pipelinekey
  ,SHA2(CONCAT(
       COALESCE(src.bdid,'N/A')
      ,COALESCE(src.category,'N/A')
      ,COALESCE(src.description,'N/A')
      ,COALESCE(src.file_date,'N/A')
      ,COALESCE(src."group",'N/A')
      ,COALESCE(src.line_number,'N/A')
      )) AS elt_columns_hash
  ,src.elt_stream_action
  ,ROW_NUMBER() OVER (PARTITION BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action ORDER BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action, src.elt_execution_date DESC) AS top_slice
FROM CLIENT_REVENUE_RAW.VW_SABOS_PRODUCTCATEGORY_VARIANT_STREAM src
)
WHERE top_slice = 1;




CREATE OR REPLACE TRANSIENT TABLE CLIENT_REVENUE_RAW.SABOS_PRODUCTGROUP_VARIANT
(
  SRC VARIANT
);




CREATE OR REPLACE STREAM CLIENT_REVENUE_RAW.SABOS_PRODUCTGROUP_VARIANT_STREAM
ON TABLE CLIENT_REVENUE_RAW.SABOS_PRODUCTGROUP_VARIANT APPEND_ONLY = TRUE;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_PRODUCTGROUP_VARIANT_STREAM
AS
SELECT
   SRC:"bdid"::string AS bdid
  ,SRC:"description"::string AS description
  ,SRC:"elt_primary_key"::string AS elt_primary_key
  ,SRC:"file_date"::string AS file_date
  ,SRC:"group"::string AS "group"
  ,SRC:"line_number"::string AS line_number
  ,SRC:"elt_execution_date"::string AS elt_execution_date
  ,SRC:"elt_source"::string AS elt_source
  ,SRC:"elt_load_type"::string AS elt_load_type
  ,SRC:"elt_delete_ind"::string AS elt_delete_ind
  ,SRC:"elt_dml_type"::string AS elt_dml_type
  ,SRC:"elt_reception_date"::string AS elt_reception_date
  ,SRC:"elt_process_id"::string AS elt_process_id
  ,SRC:"elt_firm"::string AS elt_firm
  ,SRC:"elt_pipelinekey"::string AS elt_pipelinekey
  ,METADATA$ACTION AS elt_stream_action
FROM CLIENT_REVENUE_RAW.SABOS_PRODUCTGROUP_VARIANT_STREAM;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_PRODUCTGROUP
AS
SELECT
   elt_integration_id
  ,bdid
  ,description
  ,elt_primary_key
  ,file_date
  ,"group"
  ,line_number
  ,elt_execution_date
  ,elt_source
  ,elt_load_type
  ,elt_delete_ind
  ,elt_dml_type
  ,elt_reception_date
  ,elt_process_id
  ,elt_firm
  ,elt_pipelinekey
  ,elt_columns_hash
  ,elt_stream_action
FROM
(
SELECT
   TRIM(CONCAT(COALESCE(src.elt_primary_key,'N/A'))) as elt_integration_id
  ,src.bdid
  ,src.description
  ,src.elt_primary_key
  ,src.file_date
  ,src."group"
  ,src.line_number
  ,src.elt_execution_date
  ,src.elt_source
  ,src.elt_load_type
  ,src.elt_delete_ind
  ,src.elt_dml_type
  ,src.elt_reception_date
  ,src.elt_process_id
  ,src.elt_firm
  ,src.elt_pipelinekey
  ,SHA2(CONCAT(
       COALESCE(src.bdid,'N/A')
      ,COALESCE(src.description,'N/A')
      ,COALESCE(src.file_date,'N/A')
      ,COALESCE(src."group",'N/A')
      ,COALESCE(src.line_number,'N/A')
      )) AS elt_columns_hash
  ,src.elt_stream_action
  ,ROW_NUMBER() OVER (PARTITION BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action ORDER BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action, src.elt_execution_date DESC) AS top_slice
FROM CLIENT_REVENUE_RAW.VW_SABOS_PRODUCTGROUP_VARIANT_STREAM src
)
WHERE top_slice = 1;




CREATE OR REPLACE TRANSIENT TABLE CLIENT_REVENUE_RAW.SABOS_PRODUCTLICENSE_VARIANT
(
  SRC VARIANT
);




CREATE OR REPLACE STREAM CLIENT_REVENUE_RAW.SABOS_PRODUCTLICENSE_VARIANT_STREAM
ON TABLE CLIENT_REVENUE_RAW.SABOS_PRODUCTLICENSE_VARIANT APPEND_ONLY = TRUE;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_PRODUCTLICENSE_VARIANT_STREAM
AS
SELECT
   SRC:"bdid"::string AS bdid
  ,SRC:"elt_primary_key"::string AS elt_primary_key
  ,SRC:"file_date"::string AS file_date
  ,SRC:"license"::string AS license
  ,SRC:"line_number"::string AS line_number
  ,SRC:"productid"::string AS productid
  ,SRC:"elt_execution_date"::string AS elt_execution_date
  ,SRC:"elt_source"::string AS elt_source
  ,SRC:"elt_load_type"::string AS elt_load_type
  ,SRC:"elt_delete_ind"::string AS elt_delete_ind
  ,SRC:"elt_dml_type"::string AS elt_dml_type
  ,SRC:"elt_reception_date"::string AS elt_reception_date
  ,SRC:"elt_process_id"::string AS elt_process_id
  ,SRC:"elt_firm"::string AS elt_firm
  ,SRC:"elt_pipelinekey"::string AS elt_pipelinekey
  ,METADATA$ACTION AS elt_stream_action
FROM CLIENT_REVENUE_RAW.SABOS_PRODUCTLICENSE_VARIANT_STREAM;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_PRODUCTLICENSE
AS
SELECT
   elt_integration_id
  ,bdid
  ,elt_primary_key
  ,file_date
  ,license
  ,line_number
  ,productid
  ,elt_execution_date
  ,elt_source
  ,elt_load_type
  ,elt_delete_ind
  ,elt_dml_type
  ,elt_reception_date
  ,elt_process_id
  ,elt_firm
  ,elt_pipelinekey
  ,elt_columns_hash
  ,elt_stream_action
FROM
(
SELECT
   TRIM(CONCAT(COALESCE(src.elt_primary_key,'N/A'))) as elt_integration_id
  ,src.bdid
  ,src.elt_primary_key
  ,src.file_date
  ,src.license
  ,src.line_number
  ,src.productid
  ,src.elt_execution_date
  ,src.elt_source
  ,src.elt_load_type
  ,src.elt_delete_ind
  ,src.elt_dml_type
  ,src.elt_reception_date
  ,src.elt_process_id
  ,src.elt_firm
  ,src.elt_pipelinekey
  ,SHA2(CONCAT(
       COALESCE(src.bdid,'N/A')
      ,COALESCE(src.file_date,'N/A')
      ,COALESCE(src.license,'N/A')
      ,COALESCE(src.line_number,'N/A')
      ,COALESCE(src.productid,'N/A')
      )) AS elt_columns_hash
  ,src.elt_stream_action
  ,ROW_NUMBER() OVER (PARTITION BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action ORDER BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action, src.elt_execution_date DESC) AS top_slice
FROM CLIENT_REVENUE_RAW.VW_SABOS_PRODUCTLICENSE_VARIANT_STREAM src
)
WHERE top_slice = 1;




CREATE OR REPLACE TRANSIENT TABLE CLIENT_REVENUE_RAW.SABOS_PRODUCT_VARIANT
(
  SRC VARIANT
);




CREATE OR REPLACE STREAM CLIENT_REVENUE_RAW.SABOS_PRODUCT_VARIANT_STREAM
ON TABLE CLIENT_REVENUE_RAW.SABOS_PRODUCT_VARIANT APPEND_ONLY = TRUE;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_PRODUCT_VARIANT_STREAM
AS
SELECT
   SRC:"bdid"::string AS bdid
  ,SRC:"classcode"::string AS classcode
  ,SRC:"closedate"::string AS closedate
  ,SRC:"cusip"::string AS cusip
  ,SRC:"elt_primary_key"::string AS elt_primary_key
  ,SRC:"file_date"::string AS file_date
  ,SRC:"isoffshore"::string AS isoffshore
  ,SRC:"isproprietary"::string AS isproprietary
  ,SRC:"isrestricted"::string AS isrestricted
  ,SRC:"line_number"::string AS line_number
  ,SRC:"opendate"::string AS opendate
  ,SRC:"productcategory"::string AS productcategory
  ,SRC:"productcode"::string AS productcode
  ,SRC:"productid"::string AS productid
  ,SRC:"productname"::string AS productname
  ,SRC:"ratingcode"::string AS ratingcode
  ,SRC:"sponsorcode"::string AS sponsorcode
  ,SRC:"status"::string AS status
  ,SRC:"symbol"::string AS symbol
  ,SRC:"elt_execution_date"::string AS elt_execution_date
  ,SRC:"elt_source"::string AS elt_source
  ,SRC:"elt_load_type"::string AS elt_load_type
  ,SRC:"elt_delete_ind"::string AS elt_delete_ind
  ,SRC:"elt_dml_type"::string AS elt_dml_type
  ,SRC:"elt_reception_date"::string AS elt_reception_date
  ,SRC:"elt_process_id"::string AS elt_process_id
  ,SRC:"elt_firm"::string AS elt_firm
  ,SRC:"elt_pipelinekey"::string AS elt_pipelinekey
  ,METADATA$ACTION AS elt_stream_action
FROM CLIENT_REVENUE_RAW.SABOS_PRODUCT_VARIANT_STREAM;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_PRODUCT
AS
SELECT
   elt_integration_id
  ,bdid
  ,classcode
  ,closedate
  ,cusip
  ,elt_primary_key
  ,file_date
  ,isoffshore
  ,isproprietary
  ,isrestricted
  ,line_number
  ,opendate
  ,productcategory
  ,productcode
  ,productid
  ,productname
  ,ratingcode
  ,sponsorcode
  ,status
  ,symbol
  ,elt_execution_date
  ,elt_source
  ,elt_load_type
  ,elt_delete_ind
  ,elt_dml_type
  ,elt_reception_date
  ,elt_process_id
  ,elt_firm
  ,elt_pipelinekey
  ,elt_columns_hash
  ,elt_stream_action
FROM
(
SELECT
   TRIM(CONCAT(COALESCE(src.elt_primary_key,'N/A'))) as elt_integration_id
  ,src.bdid
  ,src.classcode
  ,src.closedate
  ,src.cusip
  ,src.elt_primary_key
  ,src.file_date
  ,src.isoffshore
  ,src.isproprietary
  ,src.isrestricted
  ,src.line_number
  ,src.opendate
  ,src.productcategory
  ,src.productcode
  ,src.productid
  ,src.productname
  ,src.ratingcode
  ,src.sponsorcode
  ,src.status
  ,src.symbol
  ,src.elt_execution_date
  ,src.elt_source
  ,src.elt_load_type
  ,src.elt_delete_ind
  ,src.elt_dml_type
  ,src.elt_reception_date
  ,src.elt_process_id
  ,src.elt_firm
  ,src.elt_pipelinekey
  ,SHA2(CONCAT(
       COALESCE(src.bdid,'N/A')
      ,COALESCE(src.classcode,'N/A')
      ,COALESCE(src.closedate,'N/A')
      ,COALESCE(src.cusip,'N/A')
      ,COALESCE(src.file_date,'N/A')
      ,COALESCE(src.isoffshore,'N/A')
      ,COALESCE(src.isproprietary,'N/A')
      ,COALESCE(src.isrestricted,'N/A')
      ,COALESCE(src.line_number,'N/A')
      ,COALESCE(src.opendate,'N/A')
      ,COALESCE(src.productcategory,'N/A')
      ,COALESCE(src.productcode,'N/A')
      ,COALESCE(src.productid,'N/A')
      ,COALESCE(src.productname,'N/A')
      ,COALESCE(src.ratingcode,'N/A')
      ,COALESCE(src.sponsorcode,'N/A')
      ,COALESCE(src.status,'N/A')
      ,COALESCE(src.symbol,'N/A')
      )) AS elt_columns_hash
  ,src.elt_stream_action
  ,ROW_NUMBER() OVER (PARTITION BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action ORDER BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action, src.elt_execution_date DESC) AS top_slice
FROM CLIENT_REVENUE_RAW.VW_SABOS_PRODUCT_VARIANT_STREAM src
)
WHERE top_slice = 1;




CREATE OR REPLACE TRANSIENT TABLE CLIENT_REVENUE_RAW.SABOS_RATINGCODE_VARIANT
(
  SRC VARIANT
);




CREATE OR REPLACE STREAM CLIENT_REVENUE_RAW.SABOS_RATINGCODE_VARIANT_STREAM
ON TABLE CLIENT_REVENUE_RAW.SABOS_RATINGCODE_VARIANT APPEND_ONLY = TRUE;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_RATINGCODE_VARIANT_STREAM
AS
SELECT
   SRC:"bdid"::string AS bdid
  ,SRC:"code"::string AS code
  ,SRC:"description"::string AS description
  ,SRC:"elt_primary_key"::string AS elt_primary_key
  ,SRC:"file_date"::string AS file_date
  ,SRC:"line_number"::string AS line_number
  ,SRC:"elt_execution_date"::string AS elt_execution_date
  ,SRC:"elt_source"::string AS elt_source
  ,SRC:"elt_load_type"::string AS elt_load_type
  ,SRC:"elt_delete_ind"::string AS elt_delete_ind
  ,SRC:"elt_dml_type"::string AS elt_dml_type
  ,SRC:"elt_reception_date"::string AS elt_reception_date
  ,SRC:"elt_process_id"::string AS elt_process_id
  ,SRC:"elt_firm"::string AS elt_firm
  ,SRC:"elt_pipelinekey"::string AS elt_pipelinekey
  ,METADATA$ACTION AS elt_stream_action
FROM CLIENT_REVENUE_RAW.SABOS_RATINGCODE_VARIANT_STREAM;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_RATINGCODE
AS
SELECT
   elt_integration_id
  ,bdid
  ,code
  ,description
  ,elt_primary_key
  ,file_date
  ,line_number
  ,elt_execution_date
  ,elt_source
  ,elt_load_type
  ,elt_delete_ind
  ,elt_dml_type
  ,elt_reception_date
  ,elt_process_id
  ,elt_firm
  ,elt_pipelinekey
  ,elt_columns_hash
  ,elt_stream_action
FROM
(
SELECT
   TRIM(CONCAT(COALESCE(src.elt_primary_key,'N/A'))) as elt_integration_id
  ,src.bdid
  ,src.code
  ,src.description
  ,src.elt_primary_key
  ,src.file_date
  ,src.line_number
  ,src.elt_execution_date
  ,src.elt_source
  ,src.elt_load_type
  ,src.elt_delete_ind
  ,src.elt_dml_type
  ,src.elt_reception_date
  ,src.elt_process_id
  ,src.elt_firm
  ,src.elt_pipelinekey
  ,SHA2(CONCAT(
       COALESCE(src.bdid,'N/A')
      ,COALESCE(src.code,'N/A')
      ,COALESCE(src.description,'N/A')
      ,COALESCE(src.file_date,'N/A')
      ,COALESCE(src.line_number,'N/A')
      )) AS elt_columns_hash
  ,src.elt_stream_action
  ,ROW_NUMBER() OVER (PARTITION BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action ORDER BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action, src.elt_execution_date DESC) AS top_slice
FROM CLIENT_REVENUE_RAW.VW_SABOS_RATINGCODE_VARIANT_STREAM src
)
WHERE top_slice = 1;




CREATE OR REPLACE TRANSIENT TABLE CLIENT_REVENUE_RAW.SABOS_REPHIERARCHY_VARIANT
(
  SRC VARIANT
);




CREATE OR REPLACE STREAM CLIENT_REVENUE_RAW.SABOS_REPHIERARCHY_VARIANT_STREAM
ON TABLE CLIENT_REVENUE_RAW.SABOS_REPHIERARCHY_VARIANT APPEND_ONLY = TRUE;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_REPHIERARCHY_VARIANT_STREAM
AS
SELECT
   SRC:"agency"::string AS agency
  ,SRC:"bdid"::string AS bdid
  ,SRC:"branchid"::string AS branchid
  ,SRC:"cycledate"::string AS cycledate
  ,SRC:"elt_primary_key"::string AS elt_primary_key
  ,SRC:"file_date"::string AS file_date
  ,SRC:"hierachyrep"::string AS hierachyrep
  ,SRC:"line_number"::string AS line_number
  ,SRC:"repcode"::string AS repcode
  ,SRC:"rephierachylevl"::string AS rephierachylevl
  ,SRC:"elt_execution_date"::string AS elt_execution_date
  ,SRC:"elt_source"::string AS elt_source
  ,SRC:"elt_load_type"::string AS elt_load_type
  ,SRC:"elt_delete_ind"::string AS elt_delete_ind
  ,SRC:"elt_dml_type"::string AS elt_dml_type
  ,SRC:"elt_reception_date"::string AS elt_reception_date
  ,SRC:"elt_process_id"::string AS elt_process_id
  ,SRC:"elt_firm"::string AS elt_firm
  ,SRC:"elt_pipelinekey"::string AS elt_pipelinekey
  ,METADATA$ACTION AS elt_stream_action
FROM CLIENT_REVENUE_RAW.SABOS_REPHIERARCHY_VARIANT_STREAM;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_REPHIERARCHY
AS
SELECT
   elt_integration_id
  ,agency
  ,bdid
  ,branchid
  ,cycledate
  ,elt_primary_key
  ,file_date
  ,hierachyrep
  ,line_number
  ,repcode
  ,rephierachylevl
  ,elt_execution_date
  ,elt_source
  ,elt_load_type
  ,elt_delete_ind
  ,elt_dml_type
  ,elt_reception_date
  ,elt_process_id
  ,elt_firm
  ,elt_pipelinekey
  ,elt_columns_hash
  ,elt_stream_action
FROM
(
SELECT
   TRIM(CONCAT(COALESCE(src.elt_primary_key,'N/A'))) as elt_integration_id
  ,src.agency
  ,src.bdid
  ,src.branchid
  ,src.cycledate
  ,src.elt_primary_key
  ,src.file_date
  ,src.hierachyrep
  ,src.line_number
  ,src.repcode
  ,src.rephierachylevl
  ,src.elt_execution_date
  ,src.elt_source
  ,src.elt_load_type
  ,src.elt_delete_ind
  ,src.elt_dml_type
  ,src.elt_reception_date
  ,src.elt_process_id
  ,src.elt_firm
  ,src.elt_pipelinekey
  ,SHA2(CONCAT(
       COALESCE(src.agency,'N/A')
      ,COALESCE(src.bdid,'N/A')
      ,COALESCE(src.branchid,'N/A')
      ,COALESCE(src.cycledate,'N/A')
      ,COALESCE(src.file_date,'N/A')
      ,COALESCE(src.hierachyrep,'N/A')
      ,COALESCE(src.line_number,'N/A')
      ,COALESCE(src.repcode,'N/A')
      ,COALESCE(src.rephierachylevl,'N/A')
      )) AS elt_columns_hash
  ,src.elt_stream_action
  ,ROW_NUMBER() OVER (PARTITION BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action ORDER BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action, src.elt_execution_date DESC) AS top_slice
FROM CLIENT_REVENUE_RAW.VW_SABOS_REPHIERARCHY_VARIANT_STREAM src
)
WHERE top_slice = 1;




CREATE OR REPLACE TRANSIENT TABLE CLIENT_REVENUE_RAW.SABOS_REPHISTORY_VARIANT
(
  SRC VARIANT
);




CREATE OR REPLACE STREAM CLIENT_REVENUE_RAW.SABOS_REPHISTORY_VARIANT_STREAM
ON TABLE CLIENT_REVENUE_RAW.SABOS_REPHISTORY_VARIANT APPEND_ONLY = TRUE;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_REPHISTORY_VARIANT_STREAM
AS
SELECT
   SRC:"1099earnings"::string AS "1099earnings"
  ,SRC:"1099flag"::string AS "1099flag"
  ,SRC:"bankaccountnumber"::string AS bankaccountnumber
  ,SRC:"bankaccounttype"::string AS bankaccounttype
  ,SRC:"bdid"::string AS bdid
  ,SRC:"branchid"::string AS branchid
  ,SRC:"closingbalance"::string AS closingbalance
  ,SRC:"companyid"::string AS companyid
  ,SRC:"debitamount"::string AS debitamount
  ,SRC:"debitdate"::string AS debitdate
  ,SRC:"deferredcompensation"::string AS deferredcompensation
  ,SRC:"elt_primary_key"::string AS elt_primary_key
  ,SRC:"file_date"::string AS file_date
  ,SRC:"holdindicator"::string AS holdindicator
  ,SRC:"holdreason"::string AS holdreason
  ,SRC:"lastamountinsurance"::string AS lastamountinsurance
  ,SRC:"lastamountsecurity"::string AS lastamountsecurity
  ,SRC:"lastchecknumber"::string AS lastchecknumber
  ,SRC:"lastpaiddate"::string AS lastpaiddate
  ,SRC:"level1ytdproduction"::string AS level1ytdproduction
  ,SRC:"level2ytdproduction"::string AS level2ytdproduction
  ,SRC:"level3ytdproduction"::string AS level3ytdproduction
  ,SRC:"line_number"::string AS line_number
  ,SRC:"openingbalance"::string AS openingbalance
  ,SRC:"paymenttype"::string AS paymenttype
  ,SRC:"recognitionprogram"::string AS recognitionprogram
  ,SRC:"recognitionstatus"::string AS recognitionstatus
  ,SRC:"repcode"::string AS repcode
  ,SRC:"repstatus"::string AS repstatus
  ,SRC:"statementdate"::string AS statementdate
  ,SRC:"elt_execution_date"::string AS elt_execution_date
  ,SRC:"elt_source"::string AS elt_source
  ,SRC:"elt_load_type"::string AS elt_load_type
  ,SRC:"elt_delete_ind"::string AS elt_delete_ind
  ,SRC:"elt_dml_type"::string AS elt_dml_type
  ,SRC:"elt_reception_date"::string AS elt_reception_date
  ,SRC:"elt_process_id"::string AS elt_process_id
  ,SRC:"elt_firm"::string AS elt_firm
  ,SRC:"elt_pipelinekey"::string AS elt_pipelinekey
  ,METADATA$ACTION AS elt_stream_action
FROM CLIENT_REVENUE_RAW.SABOS_REPHISTORY_VARIANT_STREAM;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_REPHISTORY
AS
SELECT
   elt_integration_id
  ,"1099earnings"
  ,"1099flag"
  ,bankaccountnumber
  ,bankaccounttype
  ,bdid
  ,branchid
  ,closingbalance
  ,companyid
  ,debitamount
  ,debitdate
  ,deferredcompensation
  ,elt_primary_key
  ,file_date
  ,holdindicator
  ,holdreason
  ,lastamountinsurance
  ,lastamountsecurity
  ,lastchecknumber
  ,lastpaiddate
  ,level1ytdproduction
  ,level2ytdproduction
  ,level3ytdproduction
  ,line_number
  ,openingbalance
  ,paymenttype
  ,recognitionprogram
  ,recognitionstatus
  ,repcode
  ,repstatus
  ,statementdate
  ,elt_execution_date
  ,elt_source
  ,elt_load_type
  ,elt_delete_ind
  ,elt_dml_type
  ,elt_reception_date
  ,elt_process_id
  ,elt_firm
  ,elt_pipelinekey
  ,elt_columns_hash
  ,elt_stream_action
FROM
(
SELECT
   TRIM(CONCAT(COALESCE(src.elt_primary_key,'N/A'))) as elt_integration_id
  ,src."1099earnings"
  ,src."1099flag"
  ,src.bankaccountnumber
  ,src.bankaccounttype
  ,src.bdid
  ,src.branchid
  ,src.closingbalance
  ,src.companyid
  ,src.debitamount
  ,src.debitdate
  ,src.deferredcompensation
  ,src.elt_primary_key
  ,src.file_date
  ,src.holdindicator
  ,src.holdreason
  ,src.lastamountinsurance
  ,src.lastamountsecurity
  ,src.lastchecknumber
  ,src.lastpaiddate
  ,src.level1ytdproduction
  ,src.level2ytdproduction
  ,src.level3ytdproduction
  ,src.line_number
  ,src.openingbalance
  ,src.paymenttype
  ,src.recognitionprogram
  ,src.recognitionstatus
  ,src.repcode
  ,src.repstatus
  ,src.statementdate
  ,src.elt_execution_date
  ,src.elt_source
  ,src.elt_load_type
  ,src.elt_delete_ind
  ,src.elt_dml_type
  ,src.elt_reception_date
  ,src.elt_process_id
  ,src.elt_firm
  ,src.elt_pipelinekey
  ,SHA2(CONCAT(
       COALESCE(src."1099earnings",'N/A')
      ,COALESCE(src."1099flag",'N/A')
      ,COALESCE(src.bankaccountnumber,'N/A')
      ,COALESCE(src.bankaccounttype,'N/A')
      ,COALESCE(src.bdid,'N/A')
      ,COALESCE(src.branchid,'N/A')
      ,COALESCE(src.closingbalance,'N/A')
      ,COALESCE(src.companyid,'N/A')
      ,COALESCE(src.debitamount,'N/A')
      ,COALESCE(src.debitdate,'N/A')
      ,COALESCE(src.deferredcompensation,'N/A')
      ,COALESCE(src.file_date,'N/A')
      ,COALESCE(src.holdindicator,'N/A')
      ,COALESCE(src.holdreason,'N/A')
      ,COALESCE(src.lastamountinsurance,'N/A')
      ,COALESCE(src.lastamountsecurity,'N/A')
      ,COALESCE(src.lastchecknumber,'N/A')
      ,COALESCE(src.lastpaiddate,'N/A')
      ,COALESCE(src.level1ytdproduction,'N/A')
      ,COALESCE(src.level2ytdproduction,'N/A')
      ,COALESCE(src.level3ytdproduction,'N/A')
      ,COALESCE(src.line_number,'N/A')
      ,COALESCE(src.openingbalance,'N/A')
      ,COALESCE(src.paymenttype,'N/A')
      ,COALESCE(src.recognitionprogram,'N/A')
      ,COALESCE(src.recognitionstatus,'N/A')
      ,COALESCE(src.repcode,'N/A')
      ,COALESCE(src.repstatus,'N/A')
      ,COALESCE(src.statementdate,'N/A')
      )) AS elt_columns_hash
  ,src.elt_stream_action
  ,ROW_NUMBER() OVER (PARTITION BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action ORDER BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action, src.elt_execution_date DESC) AS top_slice
FROM CLIENT_REVENUE_RAW.VW_SABOS_REPHISTORY_VARIANT_STREAM src
)
WHERE top_slice = 1;




CREATE OR REPLACE TRANSIENT TABLE CLIENT_REVENUE_RAW.SABOS_REPNAME_VARIANT
(
  SRC VARIANT
);




CREATE OR REPLACE STREAM CLIENT_REVENUE_RAW.SABOS_REPNAME_VARIANT_STREAM
ON TABLE CLIENT_REVENUE_RAW.SABOS_REPNAME_VARIANT APPEND_ONLY = TRUE;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_REPNAME_VARIANT_STREAM
AS
SELECT
   SRC:"bdid"::string AS bdid
  ,SRC:"crdnumber"::string AS crdnumber
  ,SRC:"elt_primary_key"::string AS elt_primary_key
  ,SRC:"file_date"::string AS file_date
  ,SRC:"firstname"::string AS firstname
  ,SRC:"lastname"::string AS lastname
  ,SRC:"line_number"::string AS line_number
  ,SRC:"middlename"::string AS middlename
  ,SRC:"repcode"::string AS repcode
  ,SRC:"repfullname"::string AS repfullname
  ,SRC:"src_data_bdid"::string AS src_data_bdid
  ,SRC:"ssn"::string AS ssn
  ,SRC:"elt_execution_date"::string AS elt_execution_date
  ,SRC:"elt_source"::string AS elt_source
  ,SRC:"elt_load_type"::string AS elt_load_type
  ,SRC:"elt_delete_ind"::string AS elt_delete_ind
  ,SRC:"elt_dml_type"::string AS elt_dml_type
  ,SRC:"elt_reception_date"::string AS elt_reception_date
  ,SRC:"elt_process_id"::string AS elt_process_id
  ,SRC:"elt_firm"::string AS elt_firm
  ,SRC:"elt_pipelinekey"::string AS elt_pipelinekey
  ,METADATA$ACTION AS elt_stream_action
FROM CLIENT_REVENUE_RAW.SABOS_REPNAME_VARIANT_STREAM;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_REPNAME
AS
SELECT
   elt_integration_id
  ,bdid
  ,crdnumber
  ,elt_primary_key
  ,file_date
  ,firstname
  ,lastname
  ,line_number
  ,middlename
  ,repcode
  ,repfullname
  ,src_data_bdid
  ,ssn
  ,elt_execution_date
  ,elt_source
  ,elt_load_type
  ,elt_delete_ind
  ,elt_dml_type
  ,elt_reception_date
  ,elt_process_id
  ,elt_firm
  ,elt_pipelinekey
  ,elt_columns_hash
  ,elt_stream_action
FROM
(
SELECT
   TRIM(CONCAT(COALESCE(src.elt_primary_key,'N/A'))) as elt_integration_id
  ,src.bdid
  ,src.crdnumber
  ,src.elt_primary_key
  ,src.file_date
  ,src.firstname
  ,src.lastname
  ,src.line_number
  ,src.middlename
  ,src.repcode
  ,src.repfullname
  ,src.src_data_bdid
  ,src.ssn
  ,src.elt_execution_date
  ,src.elt_source
  ,src.elt_load_type
  ,src.elt_delete_ind
  ,src.elt_dml_type
  ,src.elt_reception_date
  ,src.elt_process_id
  ,src.elt_firm
  ,src.elt_pipelinekey
  ,SHA2(CONCAT(
       COALESCE(src.bdid,'N/A')
      ,COALESCE(src.crdnumber,'N/A')
      ,COALESCE(src.file_date,'N/A')
      ,COALESCE(src.firstname,'N/A')
      ,COALESCE(src.lastname,'N/A')
      ,COALESCE(src.line_number,'N/A')
      ,COALESCE(src.middlename,'N/A')
      ,COALESCE(src.repcode,'N/A')
      ,COALESCE(src.repfullname,'N/A')
      ,COALESCE(src.src_data_bdid,'N/A')
      ,COALESCE(src.ssn,'N/A')
      )) AS elt_columns_hash
  ,src.elt_stream_action
  ,ROW_NUMBER() OVER (PARTITION BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action ORDER BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action, src.elt_execution_date DESC) AS top_slice
FROM CLIENT_REVENUE_RAW.VW_SABOS_REPNAME_VARIANT_STREAM src
)
WHERE top_slice = 1;




CREATE OR REPLACE TRANSIENT TABLE CLIENT_REVENUE_RAW.SABOS_REVENUEPERIODSTAGE_VARIANT
(
  SRC VARIANT
);




CREATE OR REPLACE STREAM CLIENT_REVENUE_RAW.SABOS_REVENUEPERIODSTAGE_VARIANT_STREAM
ON TABLE CLIENT_REVENUE_RAW.SABOS_REVENUEPERIODSTAGE_VARIANT APPEND_ONLY = TRUE;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_REVENUEPERIODSTAGE_VARIANT_STREAM
AS
SELECT
   SRC:"bdid"::string AS bdid
  ,SRC:"cycledate"::string AS cycledate
  ,SRC:"cyclenumber"::string AS cyclenumber
  ,SRC:"elt_primary_key"::string AS elt_primary_key
  ,SRC:"file_date"::string AS file_date
  ,SRC:"line_number"::string AS line_number
  ,SRC:"paiddate"::string AS paiddate
  ,SRC:"paidfromdate"::string AS paidfromdate
  ,SRC:"paidthrudate"::string AS paidthrudate
  ,SRC:"elt_execution_date"::string AS elt_execution_date
  ,SRC:"elt_source"::string AS elt_source
  ,SRC:"elt_load_type"::string AS elt_load_type
  ,SRC:"elt_delete_ind"::string AS elt_delete_ind
  ,SRC:"elt_dml_type"::string AS elt_dml_type
  ,SRC:"elt_reception_date"::string AS elt_reception_date
  ,SRC:"elt_process_id"::string AS elt_process_id
  ,SRC:"elt_firm"::string AS elt_firm
  ,SRC:"elt_pipelinekey"::string AS elt_pipelinekey
  ,METADATA$ACTION AS elt_stream_action
FROM CLIENT_REVENUE_RAW.SABOS_REVENUEPERIODSTAGE_VARIANT_STREAM;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_REVENUEPERIODSTAGE
AS
SELECT
   elt_integration_id
  ,bdid
  ,cycledate
  ,cyclenumber
  ,elt_primary_key
  ,file_date
  ,line_number
  ,paiddate
  ,paidfromdate
  ,paidthrudate
  ,elt_execution_date
  ,elt_source
  ,elt_load_type
  ,elt_delete_ind
  ,elt_dml_type
  ,elt_reception_date
  ,elt_process_id
  ,elt_firm
  ,elt_pipelinekey
  ,elt_columns_hash
  ,elt_stream_action
FROM
(
SELECT
   TRIM(CONCAT(COALESCE(src.elt_primary_key,'N/A'))) as elt_integration_id
  ,src.bdid
  ,src.cycledate
  ,src.cyclenumber
  ,src.elt_primary_key
  ,src.file_date
  ,src.line_number
  ,src.paiddate
  ,src.paidfromdate
  ,src.paidthrudate
  ,src.elt_execution_date
  ,src.elt_source
  ,src.elt_load_type
  ,src.elt_delete_ind
  ,src.elt_dml_type
  ,src.elt_reception_date
  ,src.elt_process_id
  ,src.elt_firm
  ,src.elt_pipelinekey
  ,SHA2(CONCAT(
       COALESCE(src.bdid,'N/A')
      ,COALESCE(src.cycledate,'N/A')
      ,COALESCE(src.cyclenumber,'N/A')
      ,COALESCE(src.file_date,'N/A')
      ,COALESCE(src.line_number,'N/A')
      ,COALESCE(src.paiddate,'N/A')
      ,COALESCE(src.paidfromdate,'N/A')
      ,COALESCE(src.paidthrudate,'N/A')
      )) AS elt_columns_hash
  ,src.elt_stream_action
  ,ROW_NUMBER() OVER (PARTITION BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action ORDER BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action, src.elt_execution_date DESC) AS top_slice
FROM CLIENT_REVENUE_RAW.VW_SABOS_REVENUEPERIODSTAGE_VARIANT_STREAM src
)
WHERE top_slice = 1;




CREATE OR REPLACE TRANSIENT TABLE CLIENT_REVENUE_RAW.SABOS_SPONSORELITE_VARIANT
(
  SRC VARIANT
);




CREATE OR REPLACE STREAM CLIENT_REVENUE_RAW.SABOS_SPONSORELITE_VARIANT_STREAM
ON TABLE CLIENT_REVENUE_RAW.SABOS_SPONSORELITE_VARIANT APPEND_ONLY = TRUE;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_SPONSORELITE_VARIANT_STREAM
AS
SELECT
   SRC:"bdid"::string AS bdid
  ,SRC:"effectiveenddate"::string AS effectiveenddate
  ,SRC:"effectivestartdate"::string AS effectivestartdate
  ,SRC:"elitecode"::string AS elitecode
  ,SRC:"elt_primary_key"::string AS elt_primary_key
  ,SRC:"file_date"::string AS file_date
  ,SRC:"line_number"::string AS line_number
  ,SRC:"sponsorcode"::string AS sponsorcode
  ,SRC:"elt_execution_date"::string AS elt_execution_date
  ,SRC:"elt_source"::string AS elt_source
  ,SRC:"elt_load_type"::string AS elt_load_type
  ,SRC:"elt_delete_ind"::string AS elt_delete_ind
  ,SRC:"elt_dml_type"::string AS elt_dml_type
  ,SRC:"elt_reception_date"::string AS elt_reception_date
  ,SRC:"elt_process_id"::string AS elt_process_id
  ,SRC:"elt_firm"::string AS elt_firm
  ,SRC:"elt_pipelinekey"::string AS elt_pipelinekey
  ,METADATA$ACTION AS elt_stream_action
FROM CLIENT_REVENUE_RAW.SABOS_SPONSORELITE_VARIANT_STREAM;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_SPONSORELITE
AS
SELECT
   elt_integration_id
  ,bdid
  ,effectiveenddate
  ,effectivestartdate
  ,elitecode
  ,elt_primary_key
  ,file_date
  ,line_number
  ,sponsorcode
  ,elt_execution_date
  ,elt_source
  ,elt_load_type
  ,elt_delete_ind
  ,elt_dml_type
  ,elt_reception_date
  ,elt_process_id
  ,elt_firm
  ,elt_pipelinekey
  ,elt_columns_hash
  ,elt_stream_action
FROM
(
SELECT
   TRIM(CONCAT(COALESCE(src.elt_primary_key,'N/A'))) as elt_integration_id
  ,src.bdid
  ,src.effectiveenddate
  ,src.effectivestartdate
  ,src.elitecode
  ,src.elt_primary_key
  ,src.file_date
  ,src.line_number
  ,src.sponsorcode
  ,src.elt_execution_date
  ,src.elt_source
  ,src.elt_load_type
  ,src.elt_delete_ind
  ,src.elt_dml_type
  ,src.elt_reception_date
  ,src.elt_process_id
  ,src.elt_firm
  ,src.elt_pipelinekey
  ,SHA2(CONCAT(
       COALESCE(src.bdid,'N/A')
      ,COALESCE(src.effectiveenddate,'N/A')
      ,COALESCE(src.effectivestartdate,'N/A')
      ,COALESCE(src.elitecode,'N/A')
      ,COALESCE(src.file_date,'N/A')
      ,COALESCE(src.line_number,'N/A')
      ,COALESCE(src.sponsorcode,'N/A')
      )) AS elt_columns_hash
  ,src.elt_stream_action
  ,ROW_NUMBER() OVER (PARTITION BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action ORDER BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action, src.elt_execution_date DESC) AS top_slice
FROM CLIENT_REVENUE_RAW.VW_SABOS_SPONSORELITE_VARIANT_STREAM src
)
WHERE top_slice = 1;




CREATE OR REPLACE TRANSIENT TABLE CLIENT_REVENUE_RAW.SABOS_SPONSOR_VARIANT
(
  SRC VARIANT
);




CREATE OR REPLACE STREAM CLIENT_REVENUE_RAW.SABOS_SPONSOR_VARIANT_STREAM
ON TABLE CLIENT_REVENUE_RAW.SABOS_SPONSOR_VARIANT APPEND_ONLY = TRUE;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_SPONSOR_VARIANT_STREAM
AS
SELECT
   SRC:"address1"::string AS address1
  ,SRC:"address2"::string AS address2
  ,SRC:"bdid"::string AS bdid
  ,SRC:"city"::string AS city
  ,SRC:"contactname"::string AS contactname
  ,SRC:"elt_primary_key"::string AS elt_primary_key
  ,SRC:"email"::string AS email
  ,SRC:"file_date"::string AS file_date
  ,SRC:"line_number"::string AS line_number
  ,SRC:"name"::string AS name
  ,SRC:"phone"::string AS phone
  ,SRC:"sponsorcode"::string AS sponsorcode
  ,SRC:"state"::string AS state
  ,SRC:"zip"::string AS zip
  ,SRC:"elt_execution_date"::string AS elt_execution_date
  ,SRC:"elt_source"::string AS elt_source
  ,SRC:"elt_load_type"::string AS elt_load_type
  ,SRC:"elt_delete_ind"::string AS elt_delete_ind
  ,SRC:"elt_dml_type"::string AS elt_dml_type
  ,SRC:"elt_reception_date"::string AS elt_reception_date
  ,SRC:"elt_process_id"::string AS elt_process_id
  ,SRC:"elt_firm"::string AS elt_firm
  ,SRC:"elt_pipelinekey"::string AS elt_pipelinekey
  ,METADATA$ACTION AS elt_stream_action
FROM CLIENT_REVENUE_RAW.SABOS_SPONSOR_VARIANT_STREAM;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_SPONSOR
AS
SELECT
   elt_integration_id
  ,address1
  ,address2
  ,bdid
  ,city
  ,contactname
  ,elt_primary_key
  ,email
  ,file_date
  ,line_number
  ,name
  ,phone
  ,sponsorcode
  ,state
  ,zip
  ,elt_execution_date
  ,elt_source
  ,elt_load_type
  ,elt_delete_ind
  ,elt_dml_type
  ,elt_reception_date
  ,elt_process_id
  ,elt_firm
  ,elt_pipelinekey
  ,elt_columns_hash
  ,elt_stream_action
FROM
(
SELECT
   TRIM(CONCAT(COALESCE(src.elt_primary_key,'N/A'))) as elt_integration_id
  ,src.address1
  ,src.address2
  ,src.bdid
  ,src.city
  ,src.contactname
  ,src.elt_primary_key
  ,src.email
  ,src.file_date
  ,src.line_number
  ,src.name
  ,src.phone
  ,src.sponsorcode
  ,src.state
  ,src.zip
  ,src.elt_execution_date
  ,src.elt_source
  ,src.elt_load_type
  ,src.elt_delete_ind
  ,src.elt_dml_type
  ,src.elt_reception_date
  ,src.elt_process_id
  ,src.elt_firm
  ,src.elt_pipelinekey
  ,SHA2(CONCAT(
       COALESCE(src.address1,'N/A')
      ,COALESCE(src.address2,'N/A')
      ,COALESCE(src.bdid,'N/A')
      ,COALESCE(src.city,'N/A')
      ,COALESCE(src.contactname,'N/A')
      ,COALESCE(src.email,'N/A')
      ,COALESCE(src.file_date,'N/A')
      ,COALESCE(src.line_number,'N/A')
      ,COALESCE(src.name,'N/A')
      ,COALESCE(src.phone,'N/A')
      ,COALESCE(src.sponsorcode,'N/A')
      ,COALESCE(src.state,'N/A')
      ,COALESCE(src.zip,'N/A')
      )) AS elt_columns_hash
  ,src.elt_stream_action
  ,ROW_NUMBER() OVER (PARTITION BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action ORDER BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action, src.elt_execution_date DESC) AS top_slice
FROM CLIENT_REVENUE_RAW.VW_SABOS_SPONSOR_VARIANT_STREAM src
)
WHERE top_slice = 1;




CREATE OR REPLACE TRANSIENT TABLE CLIENT_REVENUE_RAW.SABOS_TOTALS_VARIANT
(
  SRC VARIANT
);




CREATE OR REPLACE STREAM CLIENT_REVENUE_RAW.SABOS_TOTALS_VARIANT_STREAM
ON TABLE CLIENT_REVENUE_RAW.SABOS_TOTALS_VARIANT APPEND_ONLY = TRUE;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_TOTALS_VARIANT_STREAM
AS
SELECT
   SRC:"bdid"::string AS bdid
  ,SRC:"elt_primary_key"::string AS elt_primary_key
  ,SRC:"file_date"::string AS file_date
  ,SRC:"line_number"::string AS line_number
  ,SRC:"statementdate"::string AS statementdate
  ,SRC:"totaladj"::string AS totaladj
  ,SRC:"totaladjdtl"::string AS totaladjdtl
  ,SRC:"totaldebit"::string AS totaldebit
  ,SRC:"totalinsurance"::string AS totalinsurance
  ,SRC:"totalrep_1099"::string AS totalrep_1099
  ,SRC:"totalrepbeginbal"::string AS totalrepbeginbal
  ,SRC:"totalrependbal"::string AS totalrependbal
  ,SRC:"totalsecurity"::string AS totalsecurity
  ,SRC:"totaltxndtl"::string AS totaltxndtl
  ,SRC:"totaltxngdc"::string AS totaltxngdc
  ,SRC:"totaltxngdcratec"::string AS totaltxngdcratec
  ,SRC:"totaltxninvest"::string AS totaltxninvest
  ,SRC:"elt_execution_date"::string AS elt_execution_date
  ,SRC:"elt_source"::string AS elt_source
  ,SRC:"elt_load_type"::string AS elt_load_type
  ,SRC:"elt_delete_ind"::string AS elt_delete_ind
  ,SRC:"elt_dml_type"::string AS elt_dml_type
  ,SRC:"elt_reception_date"::string AS elt_reception_date
  ,SRC:"elt_process_id"::string AS elt_process_id
  ,SRC:"elt_firm"::string AS elt_firm
  ,SRC:"elt_pipelinekey"::string AS elt_pipelinekey
  ,METADATA$ACTION AS elt_stream_action
FROM CLIENT_REVENUE_RAW.SABOS_TOTALS_VARIANT_STREAM;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_TOTALS
AS
SELECT
   elt_integration_id
  ,bdid
  ,elt_primary_key
  ,file_date
  ,line_number
  ,statementdate
  ,totaladj
  ,totaladjdtl
  ,totaldebit
  ,totalinsurance
  ,totalrep_1099
  ,totalrepbeginbal
  ,totalrependbal
  ,totalsecurity
  ,totaltxndtl
  ,totaltxngdc
  ,totaltxngdcratec
  ,totaltxninvest
  ,elt_execution_date
  ,elt_source
  ,elt_load_type
  ,elt_delete_ind
  ,elt_dml_type
  ,elt_reception_date
  ,elt_process_id
  ,elt_firm
  ,elt_pipelinekey
  ,elt_columns_hash
  ,elt_stream_action
FROM
(
SELECT
   TRIM(CONCAT(COALESCE(src.elt_primary_key,'N/A'))) as elt_integration_id
  ,src.bdid
  ,src.elt_primary_key
  ,src.file_date
  ,src.line_number
  ,src.statementdate
  ,src.totaladj
  ,src.totaladjdtl
  ,src.totaldebit
  ,src.totalinsurance
  ,src.totalrep_1099
  ,src.totalrepbeginbal
  ,src.totalrependbal
  ,src.totalsecurity
  ,src.totaltxndtl
  ,src.totaltxngdc
  ,src.totaltxngdcratec
  ,src.totaltxninvest
  ,src.elt_execution_date
  ,src.elt_source
  ,src.elt_load_type
  ,src.elt_delete_ind
  ,src.elt_dml_type
  ,src.elt_reception_date
  ,src.elt_process_id
  ,src.elt_firm
  ,src.elt_pipelinekey
  ,SHA2(CONCAT(
       COALESCE(src.bdid,'N/A')
      ,COALESCE(src.file_date,'N/A')
      ,COALESCE(src.line_number,'N/A')
      ,COALESCE(src.statementdate,'N/A')
      ,COALESCE(src.totaladj,'N/A')
      ,COALESCE(src.totaladjdtl,'N/A')
      ,COALESCE(src.totaldebit,'N/A')
      ,COALESCE(src.totalinsurance,'N/A')
      ,COALESCE(src.totalrep_1099,'N/A')
      ,COALESCE(src.totalrepbeginbal,'N/A')
      ,COALESCE(src.totalrependbal,'N/A')
      ,COALESCE(src.totalsecurity,'N/A')
      ,COALESCE(src.totaltxndtl,'N/A')
      ,COALESCE(src.totaltxngdc,'N/A')
      ,COALESCE(src.totaltxngdcratec,'N/A')
      ,COALESCE(src.totaltxninvest,'N/A')
      )) AS elt_columns_hash
  ,src.elt_stream_action
  ,ROW_NUMBER() OVER (PARTITION BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action ORDER BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action, src.elt_execution_date DESC) AS top_slice
FROM CLIENT_REVENUE_RAW.VW_SABOS_TOTALS_VARIANT_STREAM src
)
WHERE top_slice = 1;




CREATE OR REPLACE TRANSIENT TABLE CLIENT_REVENUE_RAW.SABOS_TRANSACTION_VARIANT
(
  SRC VARIANT
);




CREATE OR REPLACE STREAM CLIENT_REVENUE_RAW.SABOS_TRANSACTION_VARIANT_STREAM
ON TABLE CLIENT_REVENUE_RAW.SABOS_TRANSACTION_VARIANT APPEND_ONLY = TRUE;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_TRANSACTION_VARIANT_STREAM
AS
SELECT
   SRC:"accountnumber"::string AS accountnumber
  ,SRC:"bdid"::string AS bdid
  ,SRC:"bonusgroup"::string AS bonusgroup
  ,SRC:"branchcode"::string AS branchcode
  ,SRC:"businessdevcode"::string AS businessdevcode
  ,SRC:"buysellindicator"::string AS buysellindicator
  ,SRC:"cancelcorrectcode"::string AS cancelcorrectcode
  ,SRC:"cancellationdate"::string AS cancellationdate
  ,SRC:"cancellationreason"::string AS cancellationreason
  ,SRC:"cancelledbytransactionid"::string AS cancelledbytransactionid
  ,SRC:"clearinghouse"::string AS clearinghouse
  ,SRC:"clientssn"::string AS clientssn
  ,SRC:"company"::string AS company
  ,SRC:"cycledate"::string AS cycledate
  ,SRC:"description"::string AS description
  ,SRC:"elt_primary_key"::string AS elt_primary_key
  ,SRC:"file_date"::string AS file_date
  ,SRC:"gdcreceivableamount"::string AS gdcreceivableamount
  ,SRC:"investmentamount"::string AS investmentamount
  ,SRC:"line_number"::string AS line_number
  ,SRC:"originalrepcode"::string AS originalrepcode
  ,SRC:"originaltransactionid"::string AS originaltransactionid
  ,SRC:"productid"::string AS productid
  ,SRC:"repcode"::string AS repcode
  ,SRC:"splittransactionnumber"::string AS splittransactionnumber
  ,SRC:"tradenumber"::string AS tradenumber
  ,SRC:"transactiondate"::string AS transactiondate
  ,SRC:"transactionid"::string AS transactionid
  ,SRC:"transactiontype"::string AS transactiontype
  ,SRC:"elt_execution_date"::string AS elt_execution_date
  ,SRC:"elt_source"::string AS elt_source
  ,SRC:"elt_load_type"::string AS elt_load_type
  ,SRC:"elt_delete_ind"::string AS elt_delete_ind
  ,SRC:"elt_dml_type"::string AS elt_dml_type
  ,SRC:"elt_reception_date"::string AS elt_reception_date
  ,SRC:"elt_process_id"::string AS elt_process_id
  ,SRC:"elt_firm"::string AS elt_firm
  ,SRC:"elt_pipelinekey"::string AS elt_pipelinekey
  ,METADATA$ACTION AS elt_stream_action
FROM CLIENT_REVENUE_RAW.SABOS_TRANSACTION_VARIANT_STREAM;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_TRANSACTION
AS
SELECT
   elt_integration_id
  ,accountnumber
  ,bdid
  ,bonusgroup
  ,branchcode
  ,businessdevcode
  ,buysellindicator
  ,cancelcorrectcode
  ,cancellationdate
  ,cancellationreason
  ,cancelledbytransactionid
  ,clearinghouse
  ,clientssn
  ,company
  ,cycledate
  ,description
  ,elt_primary_key
  ,file_date
  ,gdcreceivableamount
  ,investmentamount
  ,line_number
  ,originalrepcode
  ,originaltransactionid
  ,productid
  ,repcode
  ,splittransactionnumber
  ,tradenumber
  ,transactiondate
  ,transactionid
  ,transactiontype
  ,elt_execution_date
  ,elt_source
  ,elt_load_type
  ,elt_delete_ind
  ,elt_dml_type
  ,elt_reception_date
  ,elt_process_id
  ,elt_firm
  ,elt_pipelinekey
  ,elt_columns_hash
  ,elt_stream_action
FROM
(
SELECT
   TRIM(CONCAT(COALESCE(src.elt_primary_key,'N/A'))) as elt_integration_id
  ,src.accountnumber
  ,src.bdid
  ,src.bonusgroup
  ,src.branchcode
  ,src.businessdevcode
  ,src.buysellindicator
  ,src.cancelcorrectcode
  ,src.cancellationdate
  ,src.cancellationreason
  ,src.cancelledbytransactionid
  ,src.clearinghouse
  ,src.clientssn
  ,src.company
  ,src.cycledate
  ,src.description
  ,src.elt_primary_key
  ,src.file_date
  ,src.gdcreceivableamount
  ,src.investmentamount
  ,src.line_number
  ,src.originalrepcode
  ,src.originaltransactionid
  ,src.productid
  ,src.repcode
  ,src.splittransactionnumber
  ,src.tradenumber
  ,src.transactiondate
  ,src.transactionid
  ,src.transactiontype
  ,src.elt_execution_date
  ,src.elt_source
  ,src.elt_load_type
  ,src.elt_delete_ind
  ,src.elt_dml_type
  ,src.elt_reception_date
  ,src.elt_process_id
  ,src.elt_firm
  ,src.elt_pipelinekey
  ,SHA2(CONCAT(
       COALESCE(src.accountnumber,'N/A')
      ,COALESCE(src.bdid,'N/A')
      ,COALESCE(src.bonusgroup,'N/A')
      ,COALESCE(src.branchcode,'N/A')
      ,COALESCE(src.businessdevcode,'N/A')
      ,COALESCE(src.buysellindicator,'N/A')
      ,COALESCE(src.cancelcorrectcode,'N/A')
      ,COALESCE(src.cancellationdate,'N/A')
      ,COALESCE(src.cancellationreason,'N/A')
      ,COALESCE(src.cancelledbytransactionid,'N/A')
      ,COALESCE(src.clearinghouse,'N/A')
      ,COALESCE(src.clientssn,'N/A')
      ,COALESCE(src.company,'N/A')
      ,COALESCE(src.cycledate,'N/A')
      ,COALESCE(src.description,'N/A')
      ,COALESCE(src.file_date,'N/A')
      ,COALESCE(src.gdcreceivableamount,'N/A')
      ,COALESCE(src.investmentamount,'N/A')
      ,COALESCE(src.line_number,'N/A')
      ,COALESCE(src.originalrepcode,'N/A')
      ,COALESCE(src.originaltransactionid,'N/A')
      ,COALESCE(src.productid,'N/A')
      ,COALESCE(src.repcode,'N/A')
      ,COALESCE(src.splittransactionnumber,'N/A')
      ,COALESCE(src.tradenumber,'N/A')
      ,COALESCE(src.transactiondate,'N/A')
      ,COALESCE(src.transactionid,'N/A')
      ,COALESCE(src.transactiontype,'N/A')
      )) AS elt_columns_hash
  ,src.elt_stream_action
  ,ROW_NUMBER() OVER (PARTITION BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action ORDER BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action, src.elt_execution_date DESC) AS top_slice
FROM CLIENT_REVENUE_RAW.VW_SABOS_TRANSACTION_VARIANT_STREAM src
)
WHERE top_slice = 1;




CREATE OR REPLACE TRANSIENT TABLE CLIENT_REVENUE_RAW.SABOS_TRANSACTIONDETAIL_VARIANT
(
  SRC VARIANT
);




CREATE OR REPLACE STREAM CLIENT_REVENUE_RAW.SABOS_TRANSACTIONDETAIL_VARIANT_STREAM
ON TABLE CLIENT_REVENUE_RAW.SABOS_TRANSACTIONDETAIL_VARIANT APPEND_ONLY = TRUE;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_TRANSACTIONDETAIL_VARIANT_STREAM
AS
SELECT
   SRC:"amount"::string AS amount
  ,SRC:"bdid"::string AS bdid
  ,SRC:"bonusgroup"::string AS bonusgroup
  ,SRC:"branchcode"::string AS branchcode
  ,SRC:"elt_primary_key"::string AS elt_primary_key
  ,SRC:"file_date"::string AS file_date
  ,SRC:"isforfeited"::string AS isforfeited
  ,SRC:"line_number"::string AS line_number
  ,SRC:"rate"::string AS rate
  ,SRC:"repcodeid"::string AS repcodeid
  ,SRC:"transactiondetailtype"::string AS transactiondetailtype
  ,SRC:"transactionid"::string AS transactionid
  ,SRC:"elt_execution_date"::string AS elt_execution_date
  ,SRC:"elt_source"::string AS elt_source
  ,SRC:"elt_load_type"::string AS elt_load_type
  ,SRC:"elt_delete_ind"::string AS elt_delete_ind
  ,SRC:"elt_dml_type"::string AS elt_dml_type
  ,SRC:"elt_reception_date"::string AS elt_reception_date
  ,SRC:"elt_process_id"::string AS elt_process_id
  ,SRC:"elt_firm"::string AS elt_firm
  ,SRC:"elt_pipelinekey"::string AS elt_pipelinekey
  ,METADATA$ACTION AS elt_stream_action
FROM CLIENT_REVENUE_RAW.SABOS_TRANSACTIONDETAIL_VARIANT_STREAM;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_TRANSACTIONDETAIL
AS
SELECT
   elt_integration_id
  ,amount
  ,bdid
  ,bonusgroup
  ,branchcode
  ,elt_primary_key
  ,file_date
  ,isforfeited
  ,line_number
  ,rate
  ,repcodeid
  ,transactiondetailtype
  ,transactionid
  ,elt_execution_date
  ,elt_source
  ,elt_load_type
  ,elt_delete_ind
  ,elt_dml_type
  ,elt_reception_date
  ,elt_process_id
  ,elt_firm
  ,elt_pipelinekey
  ,elt_columns_hash
  ,elt_stream_action
FROM
(
SELECT
   TRIM(CONCAT(COALESCE(src.elt_primary_key,'N/A'))) as elt_integration_id
  ,src.amount
  ,src.bdid
  ,src.bonusgroup
  ,src.branchcode
  ,src.elt_primary_key
  ,src.file_date
  ,src.isforfeited
  ,src.line_number
  ,src.rate
  ,src.repcodeid
  ,src.transactiondetailtype
  ,src.transactionid
  ,src.elt_execution_date
  ,src.elt_source
  ,src.elt_load_type
  ,src.elt_delete_ind
  ,src.elt_dml_type
  ,src.elt_reception_date
  ,src.elt_process_id
  ,src.elt_firm
  ,src.elt_pipelinekey
  ,SHA2(CONCAT(
       COALESCE(src.amount,'N/A')
      ,COALESCE(src.bdid,'N/A')
      ,COALESCE(src.bonusgroup,'N/A')
      ,COALESCE(src.branchcode,'N/A')
      ,COALESCE(src.file_date,'N/A')
      ,COALESCE(src.isforfeited,'N/A')
      ,COALESCE(src.line_number,'N/A')
      ,COALESCE(src.rate,'N/A')
      ,COALESCE(src.repcodeid,'N/A')
      ,COALESCE(src.transactiondetailtype,'N/A')
      ,COALESCE(src.transactionid,'N/A')
      )) AS elt_columns_hash
  ,src.elt_stream_action
  ,ROW_NUMBER() OVER (PARTITION BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action ORDER BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action, src.elt_execution_date DESC) AS top_slice
FROM CLIENT_REVENUE_RAW.VW_SABOS_TRANSACTIONDETAIL_VARIANT_STREAM src
)
WHERE top_slice = 1;




CREATE OR REPLACE TRANSIENT TABLE CLIENT_REVENUE_RAW.SABOS_TRANSACTIONTYPE_VARIANT
(
  SRC VARIANT
);




CREATE OR REPLACE STREAM CLIENT_REVENUE_RAW.SABOS_TRANSACTIONTYPE_VARIANT_STREAM
ON TABLE CLIENT_REVENUE_RAW.SABOS_TRANSACTIONTYPE_VARIANT APPEND_ONLY = TRUE;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_TRANSACTIONTYPE_VARIANT_STREAM
AS
SELECT
   SRC:"bdid"::string AS bdid
  ,SRC:"description"::string AS description
  ,SRC:"elt_primary_key"::string AS elt_primary_key
  ,SRC:"file_date"::string AS file_date
  ,SRC:"line_number"::string AS line_number
  ,SRC:"transactiontype"::string AS transactiontype
  ,SRC:"elt_execution_date"::string AS elt_execution_date
  ,SRC:"elt_source"::string AS elt_source
  ,SRC:"elt_load_type"::string AS elt_load_type
  ,SRC:"elt_delete_ind"::string AS elt_delete_ind
  ,SRC:"elt_dml_type"::string AS elt_dml_type
  ,SRC:"elt_reception_date"::string AS elt_reception_date
  ,SRC:"elt_process_id"::string AS elt_process_id
  ,SRC:"elt_firm"::string AS elt_firm
  ,SRC:"elt_pipelinekey"::string AS elt_pipelinekey
  ,METADATA$ACTION AS elt_stream_action
FROM CLIENT_REVENUE_RAW.SABOS_TRANSACTIONTYPE_VARIANT_STREAM;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_TRANSACTIONTYPE
AS
SELECT
   elt_integration_id
  ,bdid
  ,description
  ,elt_primary_key
  ,file_date
  ,line_number
  ,transactiontype
  ,elt_execution_date
  ,elt_source
  ,elt_load_type
  ,elt_delete_ind
  ,elt_dml_type
  ,elt_reception_date
  ,elt_process_id
  ,elt_firm
  ,elt_pipelinekey
  ,elt_columns_hash
  ,elt_stream_action
FROM
(
SELECT
   TRIM(CONCAT(COALESCE(src.elt_primary_key,'N/A'))) as elt_integration_id
  ,src.bdid
  ,src.description
  ,src.elt_primary_key
  ,src.file_date
  ,src.line_number
  ,src.transactiontype
  ,src.elt_execution_date
  ,src.elt_source
  ,src.elt_load_type
  ,src.elt_delete_ind
  ,src.elt_dml_type
  ,src.elt_reception_date
  ,src.elt_process_id
  ,src.elt_firm
  ,src.elt_pipelinekey
  ,SHA2(CONCAT(
       COALESCE(src.bdid,'N/A')
      ,COALESCE(src.description,'N/A')
      ,COALESCE(src.file_date,'N/A')
      ,COALESCE(src.line_number,'N/A')
      ,COALESCE(src.transactiontype,'N/A')
      )) AS elt_columns_hash
  ,src.elt_stream_action
  ,ROW_NUMBER() OVER (PARTITION BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action ORDER BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action, src.elt_execution_date DESC) AS top_slice
FROM CLIENT_REVENUE_RAW.VW_SABOS_TRANSACTIONTYPE_VARIANT_STREAM src
)
WHERE top_slice = 1;




CREATE OR REPLACE TRANSIENT TABLE CLIENT_REVENUE_RAW.SABOS_TRANSACTIONDETAILTYPE_VARIANT
(
  SRC VARIANT
);




CREATE OR REPLACE STREAM CLIENT_REVENUE_RAW.SABOS_TRANSACTIONDETAILTYPE_VARIANT_STREAM
ON TABLE CLIENT_REVENUE_RAW.SABOS_TRANSACTIONDETAILTYPE_VARIANT APPEND_ONLY = TRUE;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_TRANSACTIONDETAILTYPE_VARIANT_STREAM
AS
SELECT
   SRC:"bdid"::string AS bdid
  ,SRC:"description"::string AS description
  ,SRC:"elt_primary_key"::string AS elt_primary_key
  ,SRC:"file_date"::string AS file_date
  ,SRC:"line_number"::string AS line_number
  ,SRC:"txndetailtype"::string AS txndetailtype
  ,SRC:"elt_execution_date"::string AS elt_execution_date
  ,SRC:"elt_source"::string AS elt_source
  ,SRC:"elt_load_type"::string AS elt_load_type
  ,SRC:"elt_delete_ind"::string AS elt_delete_ind
  ,SRC:"elt_dml_type"::string AS elt_dml_type
  ,SRC:"elt_reception_date"::string AS elt_reception_date
  ,SRC:"elt_process_id"::string AS elt_process_id
  ,SRC:"elt_firm"::string AS elt_firm
  ,SRC:"elt_pipelinekey"::string AS elt_pipelinekey
  ,METADATA$ACTION AS elt_stream_action
FROM CLIENT_REVENUE_RAW.SABOS_TRANSACTIONDETAILTYPE_VARIANT_STREAM;




CREATE OR REPLACE VIEW CLIENT_REVENUE_RAW.VW_SABOS_TRANSACTIONDETAILTYPE
AS
SELECT
   elt_integration_id
  ,bdid
  ,description
  ,elt_primary_key
  ,file_date
  ,line_number
  ,txndetailtype
  ,elt_execution_date
  ,elt_source
  ,elt_load_type
  ,elt_delete_ind
  ,elt_dml_type
  ,elt_reception_date
  ,elt_process_id
  ,elt_firm
  ,elt_pipelinekey
  ,elt_columns_hash
  ,elt_stream_action
FROM
(
SELECT
   TRIM(CONCAT(COALESCE(src.elt_primary_key,'N/A'))) as elt_integration_id
  ,src.bdid
  ,src.description
  ,src.elt_primary_key
  ,src.file_date
  ,src.line_number
  ,src.txndetailtype
  ,src.elt_execution_date
  ,src.elt_source
  ,src.elt_load_type
  ,src.elt_delete_ind
  ,src.elt_dml_type
  ,src.elt_reception_date
  ,src.elt_process_id
  ,src.elt_firm
  ,src.elt_pipelinekey
  ,SHA2(CONCAT(
       COALESCE(src.bdid,'N/A')
      ,COALESCE(src.description,'N/A')
      ,COALESCE(src.file_date,'N/A')
      ,COALESCE(src.line_number,'N/A')
      ,COALESCE(src.txndetailtype,'N/A')
      )) AS elt_columns_hash
  ,src.elt_stream_action
  ,ROW_NUMBER() OVER (PARTITION BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action ORDER BY COALESCE(src.elt_primary_key,'N/A'), src.elt_stream_action, src.elt_execution_date DESC) AS top_slice
FROM CLIENT_REVENUE_RAW.VW_SABOS_TRANSACTIONDETAILTYPE_VARIANT_STREAM src
)
WHERE top_slice = 1;



